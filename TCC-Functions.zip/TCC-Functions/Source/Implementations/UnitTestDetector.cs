using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Implementations
{
    [ExcludeFromCodeCoverage]
    public static class UnitTestDetector
    {
        private static bool? _overrideValue;

        public static bool IsInUnitTest
        {
            get
            {
                // If an override value is set, return that
                if (_overrideValue.HasValue) return _overrideValue.Value;

                // Default behavior to detect unit test execution
                string testAssemblyName = "nunit.framework";
                return AppDomain.CurrentDomain.GetAssemblies()
                    .Any(a => a.FullName.StartsWith(testAssemblyName, StringComparison.OrdinalIgnoreCase));
            }
        }

        // Method to set the override value
        public static void SetOverrideValue(bool? overrideValue)
        {
            _overrideValue = overrideValue;
        }
    }
}
