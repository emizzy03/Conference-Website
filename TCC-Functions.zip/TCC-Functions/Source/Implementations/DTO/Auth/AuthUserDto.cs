using System.Diagnostics.CodeAnalysis;
using TCC.Functions.Model.Auth;

namespace TCC.Functions.Implementations.DTO.Auth;
[ExcludeFromCodeCoverage]
public class AuthUserDto
{
    public Guid Id { get; set; }

    public required string FirstName { get; set; }

    public required string LastName { get; set; }

    public string DisplayName
    {
        get
        {
            return $"{FirstName} {LastName}";
        }
    }
    public required string Email { get; set; }
    public string PictureLink { get; set; } = null!;
    public bool IsExistingUser { get; set; } = false;
    public List<Roles> RolesList { get; set; } = null!;
}