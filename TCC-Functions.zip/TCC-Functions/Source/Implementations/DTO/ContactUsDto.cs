﻿
using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Implementations.DTO
{
    [ExcludeFromCodeCoverage]
    public class ContactUsDto
    {
        public string Name { get; set; } = string.Empty;
        public string? Organization { get; set; }
        public string? Role { get; set; }
        public string EmailAddress { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
    }
}
