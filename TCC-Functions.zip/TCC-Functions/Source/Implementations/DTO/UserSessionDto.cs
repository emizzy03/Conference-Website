using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Implementations.DTO;

[ExcludeFromCodeCoverage]
public class UserSessionDto
{
    public Guid Id { get; set; }
    public required string Title { get; set; }
    public required string Description { get; set; }
    public bool IsKeynote { get; set; }
    public string VideoLink { get; set; } = null!;
    public bool IsSelected { get; set; }
    public bool IsWorkshop { get; set; }
    public Guid EventId { get; set; }
    public string VideoThumbnail { get; set; } = null!;
    public Enum SessionEventStatus { get; set; }
}