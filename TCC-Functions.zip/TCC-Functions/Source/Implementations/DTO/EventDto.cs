using System.Diagnostics.CodeAnalysis;
using TCC.Functions.Model;

namespace TCC.Functions.Implementations.DTO;

[ExcludeFromCodeCoverage]
public class EventDto
{
    public Guid Id { get; set; }

    public string Name { get; set; } = null!;

    public DateTime StartDate { get; set; } 

    public DateTime EndDate { get; set; } 

    public EventStatus Status { get; set; }

    public string Address1 { get; set; } = null!;

    public string Address2 { get; set; } = null!;

    public string City { get; set; } = null!;

    public string State { get; set; } = null!;

    public string Zip { get; set; } = null!;

    public string LocationDescription { get; set; } = null!;

    public bool KeynoteSelected { get; set; }

    public bool CallForSpeakerOpen { get; set; }

    public bool IsWorkshopSessionAllowed { get; set; }

    public bool SessionsSelected { get; set;}

    public int Year { get; set;}
    public List<SessionDto> Sessions { get; set; } = null!;
    public List<Staff> Staff { get; set; } = null!;
}