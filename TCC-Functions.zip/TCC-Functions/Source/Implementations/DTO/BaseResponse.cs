using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Implementations.DTO;

[ExcludeFromCodeCoverage]
public class BaseResponse
{
    public string Message { get; set; } = string.Empty;
}