using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Implementations.DTO;

[ExcludeFromCodeCoverage]
public class UpdateEventDto
{
    [Required]
    public Guid Id { get; set; }
}