using System.Diagnostics.CodeAnalysis;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Net.Http.Headers;
using System.Security;
using System.Text;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Model.Auth;
using HttpRequestData = Microsoft.Azure.Functions.Worker.Http.HttpRequestData;

namespace TCC.Functions.Implementations.Auth;
[ExcludeFromCodeCoverage]
// To-Do: Need to write unit tests for these!
public class AuthenticationBase
{
    public IHttpService _httpService;
    public IAzureADService _azureAdService;
    public IAuthUserService _authUserService;
    private HttpRequestData _req = null!;
    private string _token = string.Empty;
    public ADUser _adUser = null!;

    public void SetHttpRequestData(HttpRequestData req)
    {
        _req = req;
    }

    public async Task<bool> Roles(string[] roles)
    {
        return await Roles(_req, roles);
    }

    public async Task<bool> Roles(HttpRequestData req, string[] roles)
    {
        _req = req;
        return await RoleValidation(roles);
    }

    public async Task<bool> RoleValidation(string[] roles)
    {
        if (UnitTestDetector.IsInUnitTest)
            return true;

        if (!_req.Headers.Contains("Authorization"))
        {
            throw new SecurityException("Missing Authorization header.");
        }
        var isUserAuthenticated = await IsAuthenticated();
        if (!isUserAuthenticated)
            throw new SecurityException("Invalid User.");
        var systemReslt = await _authUserService.IsUserInRole(_adUser.Id, roles);
        if (!systemReslt)
            throw new SecurityException("User is not in role.");
        return true;
    }

    private async Task<bool> IsAuthenticated()
    {
        var authHeader = _req.Headers.GetValues("Authorization").First();
        var accessToken = GetHeaderAccessToken(authHeader);
        if (!CheckTokenIsValid(accessToken))
            throw new SecurityException($"Token is invalid. {accessToken}");
        var claimsPrincipal = ReadHeaderJwt(accessToken);
        if(claimsPrincipal==null)
            throw new SecurityException("Claims principal is null.");
        await AcquireToken();
        _adUser = await GetAdUser(claimsPrincipal.Payload.Sub);
        if(_adUser==null)
            throw new SecurityException("AD User is null.");
        return true;
    }
    public static bool CheckTokenIsValid(string access_token)
    {
        var tenantName = Environment.GetEnvironmentVariable("TenantName") ?? string.Empty;
        var b2CFlow = Environment.GetEnvironmentVariable("B2CFlow") ?? string.Empty;
        var clientId = Environment.GetEnvironmentVariable("ClientId") ?? string.Empty;
        string stsDiscoveryEndpoint =
            $"https://{tenantName}.b2clogin.com/{tenantName}.onmicrosoft.com/v2.0/.well-known/openid-configuration?p={b2CFlow}";

        var configManager = new ConfigurationManager<OpenIdConnectConfiguration>(stsDiscoveryEndpoint, 
                                    new OpenIdConnectConfigurationRetriever()); //1. need the 'new OpenIdConnect...'  
        OpenIdConnectConfiguration config = configManager.GetConfigurationAsync().Result;

        TokenValidationParameters validationParameters = new TokenValidationParameters
        {
            ValidateAudience = true,
            ValidateIssuer = true,
            ValidateIssuerSigningKey = true,
            ValidateLifetime = true,
            RequireSignedTokens = true,
            ClockSkew = TimeSpan.Zero,
            ValidAudience = clientId,
            IssuerSigningKeys = config.SigningKeys,
            ValidIssuer = config.Issuer
        };

        JwtSecurityTokenHandler tokendHandler = new JwtSecurityTokenHandler();
        SecurityToken jwt;
        var validatedToken = (SecurityToken)new JwtSecurityToken();

        try
        {
            var result = tokendHandler.ValidateToken(access_token, validationParameters, out jwt);
            var dataToValidate = jwt as JwtSecurityToken;

            return true;

        }
        catch (Exception ex)
        {
            string m = ex.Message;
            Console.WriteLine("FormatException: " + m);
            return false;
        }   
    }
    private string GetHeaderAccessToken(string authorizationHeader)
    {
        string[] parts = authorizationHeader?.ToString().Split(null) ?? new string[0];
        if (parts.Length == 2 && parts[0].Equals("Bearer"))
            return parts[1];
        throw new SecurityException($"Missing Access Token: {authorizationHeader}");
    }
    public JwtSecurityToken ReadHeaderJwt(string accessToken)
    {
        var handler = new JwtSecurityTokenHandler();
        var token = handler.ReadJwtToken(accessToken);
        if(token.Payload==null || token.Payload.Sub==null)
        {
            throw new SecurityException("Missing payload or sub in JWT token.");
        }

        return token;
    }

    private async Task AcquireToken()
    {
        var response = await _azureAdService.GetAuthTokenFromMicrosoftAsync();
        if(response["access_token"]!=null)
            SetAuthToken(response["access_token"]!.ToString());
    }
    private void SetAuthToken(string token)
    {
        _token = token;
        Dictionary<string, string> httpHeader = new Dictionary<string, string>();
        httpHeader.Add("Authorization", $"Bearer {token}");
        _httpService.SetDefaultHeaders(httpHeader);
    }
    private async Task<ADUser> GetAdUser(string userId)
    {  
        if(string.IsNullOrEmpty(_token))
            await AcquireToken();
        _httpService.SetMediaType("application/json");
        var graphUri = $"https://graph.microsoft.com/v1.0/users/{userId}";
        var response = await _httpService.GetJsonRequest(graphUri);
        if (response == null) 
            throw new ArgumentException("Get user department response errored/returned null.");
        return JsonConvert.DeserializeObject<ADUser>(response.ToString());
    }
    //TODO: MIN-make sure tenant id is known.
    //Rate litmit ids & IP addresses
}