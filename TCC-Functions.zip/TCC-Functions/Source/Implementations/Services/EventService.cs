﻿using Microsoft.Extensions.Logging;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Interfaces;
using TCC.Functions.Model;

namespace TCC.Functions.Implementations.Services
{
    public class EventService : IEventService
    {
        private readonly ILogger<EventService> _logger;
        private readonly IStorageService _storageService;

        public EventService(ILogger<EventService> logger, IStorageService storageService)
        {
            _logger = logger;
            _storageService = storageService;
        }

        public async Task SaveEvent(EventDto eventDto, Guid eventId, string operationPerformed)
        {
            var savedEvent = new Event
            {
                Id = eventId,
                Name = eventDto.Name,
                StartDate = eventDto.StartDate,
                EndDate = eventDto.EndDate,
                Status = eventDto.Status,
                Address1 = eventDto.Address1,
                Address2 = eventDto.Address2,
                City = eventDto.City,
                State = eventDto.State,
                Zip = eventDto.Zip,
                LocationDescription = eventDto.LocationDescription,
                KeynoteSelected = eventDto.KeynoteSelected,
                SessionsSelected = eventDto.SessionsSelected,
                CallForSpeakerOpen = eventDto.CallForSpeakerOpen,
                IsWorkshopSessionAllowed = eventDto.IsWorkshopSessionAllowed,
                Year = eventDto.Year,
            };
            _logger.LogInformation($"Starting to save data for Event with ID: {eventId}");

            try
            {
                // Write event data to the JSON file
                string eventPath = $"events/{eventId}/{eventId}.json";
                await _storageService.WriteObjectToBlobContent("public", eventPath, savedEvent);

                _logger.LogInformation($"Successfully {operationPerformed} event data for event with ID: {eventId}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Failed to store event data for event with ID: {eventId}");
                throw;
            }
        }
    }
}

