﻿using Microsoft.Extensions.Logging;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Interfaces;
using TCC.Functions.Model;
using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;


namespace TCC.Functions.Implementations.Services
{
    public class UserService : IUserService
    {
        private readonly ILogger<UserService> _logger;
        private readonly IStorageService _storageService;
        private readonly IPublicDataService _publicDataService;
        private readonly UrlValidator urlValidator;

        public UserService(IStorageService storageService, ILogger<UserService> logger, IPublicDataService publicDataService, IHttpWebRequestService httpWebRequestService)
        {
            _storageService = storageService;
            _logger = logger;
            _publicDataService = publicDataService;
            urlValidator = new UrlValidator(httpWebRequestService);
        }
        public async Task<User> GetUser(string userId)
        {
            _logger.LogInformation("Aquiring User Data from Storage");
            try
            {
                string path = "users/" + userId.ToString() + "/" + userId.ToString() + ".json";
                var result = await _storageService.GetDataFromStorage("public", path);
                User currentUser = JsonConvert.DeserializeObject<User>(result);

                return currentUser;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting User information from Storage");
                throw;
            }
        }

        public async Task<List<UserSocialMedia>> GetUserSocialMedia(string userId)
        {
            _logger.LogInformation("Aquiring User Social Media Data from Storage");
            try
            {
                string path = "users/" + userId.ToString() + "/socialmedia/" + userId.ToString() + ".json";
                bool exist = await _storageService.BlobExists("public", path);
                if (exist)
                {
                    var result = await _storageService.GetDataFromStorage("public", path);

                    List<UserSocialMedia> userSocialMediasList = JsonConvert.DeserializeObject<List<UserSocialMedia>>(result);
                    return userSocialMediasList;
                }
                else
                {
                    return new List<UserSocialMedia>();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting Use Social Media information from Storage");
                throw;
            }
        }

        public async Task<UserDTO> GetUserDTO(string userId)
        {
            try
            {
                User currentUser = await GetUser(userId);
                List<UserSocialMedia> userSocialMedias = await GetUserSocialMedia(userId);
                List<SocialMediaPlatform> socialMediaPlatforms = await _publicDataService.GetSocialMediaPlatforms();

                var userDTO = (new UserDTO
                {
                    Id = currentUser.Id,
                    FirstName = currentUser.FirstName,
                    LastName = currentUser.LastName,
                    Email = currentUser.Email,
                    Biography = currentUser.Biography,
                    PictureLink = currentUser.PictureLink,
                    PresentationSessions = currentUser.PresentationSessions,
                    SocialMediaLinks = (from us in userSocialMedias
                                        join sm in socialMediaPlatforms
                                        on us.SocialMediaPlatformId equals sm.Id
                                        where
                                        currentUser.Id == us.UserId
                                        select new UserSocialMediaDTO
                                        {
                                            UserSocialMediaId = us.Id,
                                            SocialMediaPlatformId = us.SocialMediaPlatformId,
                                            UserId = us.UserId,
                                            SocialMediaLink = us.Link
                                        }).ToList()
                });

                _logger.LogInformation("Created UserDTO");

                return userDTO;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting UserDTO information from Storage");
                throw;
            }
        }

        public async Task SaveUser(UserDTO userDTO, Guid userId, string operationPerformed)
        {
           
          
            var user = new User
            {
                Id = userId,
                FirstName = userDTO.FirstName,
                LastName = userDTO.LastName,
                Email = userDTO.Email,
                Biography = userDTO.Biography,
                PictureLink = (string.IsNullOrEmpty(userDTO.PictureLink) || !urlValidator.UrlIsValid(userDTO.PictureLink, _logger)) ? "https://creazilla-store.fra1.digitaloceanspaces.com/icons/3220761/user-circle-icon-md.png" : userDTO.PictureLink,
                PresentationSessions = userDTO.PresentationSessions,
            };

            _logger.LogInformation($"Starting to save data for User with ID: {userId}");

            try
            {
                // Write user data to the JSON file
                string userPath = $"users/{userId}/{userId}.json";
                await _storageService.WriteObjectToBlobContent("public", userPath, user);

                _logger.LogInformation($"Successfully {operationPerformed} user data for User with ID: {userId}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Failed to store user data for User with ID: {userId}");
                throw;
            }
        }

        public async Task SaveUserSocialMedia(IEnumerable<UserSocialMediaDTO> socialMediaDTOs, Guid userId, string operationPerformed)
        {
            List<UserSocialMedia> userSocialMedias = (socialMediaDTOs ?? new List<UserSocialMediaDTO>())
            .Select(media => new UserSocialMedia
            {
                Id = media.UserSocialMediaId != Guid.Empty ? media.UserSocialMediaId : Guid.NewGuid(),
                SocialMediaPlatformId = media.SocialMediaPlatformId,
                Link = media.SocialMediaLink,
                UserId = userId,
            })
            .ToList();

            _logger.LogInformation($"Starting to save data for User with ID: {userId}");

            try
            {
                // Write user social media data to the JSON file    
                await _storageService.WriteObjectToBlobContent("public", $"users/{userId}/socialmedia/{userId}.json", userSocialMedias);
                _logger.LogInformation($"Successfully {operationPerformed} social media data for User with ID: {userId}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Failed to store social media data for User with ID: {userId}");
                throw;
            }

        }

        //Delete user social media
        public async Task DeleteUserSocialMedia(string socialMediaPath)
        {
            await _storageService.DeleteFileByPath("public", socialMediaPath);
            _logger.LogInformation($"Deleted social media data for User.");
        }

        //Update User Sessions 

        public async Task UpdateUserSessions(SessionDto sessionDto, Guid sessionsId, string operationPerformed)
        {
            try
            {
                var session = MapSession(sessionsId, sessionDto);

                _logger.LogInformation($"Starting to save session data for Session with ID: {sessionsId}");

                //Get User and Event from database
                User currentUser = await GetUser(session.UserId.ToString());
                var eventDataJson = await _storageService.GetDataFromStorage("public", $"events/{session.EventId}/{session.EventId}.json");
                var currentEvent = JsonConvert.DeserializeObject<Event>(eventDataJson);

                //Session Path
                string sessionPath = $"events/{session.EventId}/sessions/{session.Id}.json";

                if (operationPerformed == "NewUserSession" && ((!currentEvent.IsWorkshopSessionAllowed && !session.IsWorkshop) ||
                   (currentEvent.IsWorkshopSessionAllowed && (session.IsWorkshop || !session.IsWorkshop))))
                {
                    await _storageService.WriteObjectToBlobContent("public", sessionPath, session);
                    _logger.LogInformation($"Successfully created session data for session with ID: {sessionsId}");

                    currentUser.PresentationSessions ??= new List<Guid>();
                    currentUser.PresentationSessions.Add(sessionsId);
                    // Update currentUser in Azure Storage
                    await _storageService.WriteObjectToBlobContent("public", $"users/{currentUser.Id}/{currentUser.Id}.json", currentUser);

                    _logger.LogInformation($"Successfully added user session id to user's session list");
                }
                else if (operationPerformed == "UpdateUserSession" && currentUser.PresentationSessions.Contains(sessionsId))
                {
                    await _storageService.WriteObjectToBlobContent("public", sessionPath, session);
                    _logger.LogInformation($"Successfully saved user session data for session with ID: {sessionsId}");
                }
                else
                {
                    throw new InvalidOperationException("Invalid operation performed");
                }
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, $"Failed to store session data for Session with ID: {sessionsId}");
                throw;
            }

            catch (Exception ex)
            {
                _logger.LogError(ex, $"Failed to store User session data for Session with ID: {sessionsId}");
                throw;
            }

        }

        public async Task RemoveSession(SessionDto sessionToRemove)
        {
            _logger.LogInformation("Attempting to remove the Session");

            try
            {
                var sessionData = await _storageService.GetDataFromStorage("public", $"events/{sessionToRemove.EventId.ToString()}/sessions/{sessionToRemove.Id.ToString()}.json");
                var session = JsonConvert.DeserializeObject<Session>(sessionData);

                if (sessionToRemove.UserId == session.UserId)
                {
                    // List all blobs in the "public" container
                    var blobs = _storageService.GetBlobs("public");

                    // Filter for session files
                    var sessionFiles = blobs.Where(b => b.StartsWith("events") && b.Contains("/sessions") && b.Contains($"{sessionToRemove.Id.ToString()}.json")).ToList();

                    await RemoveSessionFromUser(sessionToRemove);

                    for (int i = 0; i < sessionFiles.Count; i++)
                    {
                        try
                        {
                            await _storageService.DeleteFileByPath("public", sessionFiles[i]);
                            _logger.LogInformation($"Removed file at path: {sessionFiles[i]}");
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(ex, $"Error removing file at: {sessionFiles[i]}");
                            throw;
                        }
                    }
                    _logger.LogInformation("Completed removal of User Session");

                }
                else
                {
                    _logger.LogError($"User {sessionToRemove.UserId} does not match {session.UserId}");
                }
            } catch (Exception ex) 
            {
                _logger.LogError(ex, "Error Acquiring User Sessions Data from Storage");
                throw;
            }
        }

            public async Task RemoveSessionFromUser(SessionDto sessionToRemove)
        {
            _logger.LogInformation($"Starting removal of session: {sessionToRemove.Id}");

            try
            {
                // Fetch data for the user
                var userDataJson = await _storageService.GetDataFromStorage("public", $"users/{sessionToRemove.UserId.ToString()}/{sessionToRemove.UserId.ToString()}.json");
                var userData = JsonConvert.DeserializeObject<User>(userDataJson);

                for (int k = 0; k < userData.PresentationSessions.Count; k++)
                {
                    if (userData.PresentationSessions[k].Equals(sessionToRemove.Id))
                    {
                        userData.PresentationSessions.RemoveAt(k);

                        try
                        {
                            var updatedJson = JsonConvert.SerializeObject(userData);
                            await _storageService.WriteBlobContent("public", $"users/{sessionToRemove.UserId}/{sessionToRemove.UserId}.json", updatedJson);
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(ex, "Error removing session from user in blob");
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing user data ");
                throw;
            }

            _logger.LogInformation("Completed removal of session from user.");

        }


        public async Task<List<UserSessionDto>> GetUserSessions(List<string> sessions, Guid userId)
        {
            _logger.LogInformation("Acquiring User Sessions Data from Storage");
            try
            {
                List<UserSessionDto> sessionsList = [];
                var userResult = await _storageService.GetDataFromStorage("public", "users/" + userId.ToString() + "/" + userId.ToString() + ".json"); //Gets passed in user
                User currentUser = JsonConvert.DeserializeObject<User>(userResult);
                if (currentUser is null)
                    throw new Exception("User not found");

                var sessionFileNames = sessions.Where(sf => currentUser.PresentationSessions.Contains(new Guid(sf.Split("/").Last().Replace(".json", "")))).ToList();
                foreach (var f in sessionFileNames)
                {
                    var sessionResult = await _storageService.GetDataFromStorage("public", f);
                    var session = JsonConvert.DeserializeObject<Session?>(sessionResult);
                    if (session != null)
                    {
                        sessionsList.Add(MapUserSession(session));
                    }
                }

                List<Guid> eventIds = [];
                List<Event> events = new List<Event>();
                for (int i = 0; i < sessionsList.Count; i++)
                {
                    Guid eventId = sessionsList[i].EventId;
                    var sessionEventResult = await _storageService.GetDataFromStorage("public", "events/" + eventId.ToString() + "/" + eventId.ToString() + ".json");
                    Event sessionEvent = JsonConvert.DeserializeObject<Event>(sessionEventResult);
                    eventIds.Add(sessionEvent.Id);
                    events.Add(sessionEvent);

                    sessionsList[i].SessionEventStatus = sessionEvent.Status;
                }


                    _logger.LogInformation($"Acquired {sessionsList.Count} sessions from Storage");
                sessionsList = sessionsList.OrderBy(s => s.Title).ToList();
                return sessionsList;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error Acquiring User Sessions Data from Storage");
                throw;
            }
        }

        [ExcludeFromCodeCoverage]
        private Session MapSession(Guid sessionsId, SessionDto sessionDto)
        {
            var session = new Session
            {
                Id = sessionsId,
                Title = sessionDto.Title,
                Description = sessionDto.Description,
                UserId = sessionDto.UserId,
                IsKeynote = sessionDto.IsKeynote,
                VideoLink = sessionDto.VideoLink,
                IsSelected = sessionDto.IsSelected,
                IsWorkshop = sessionDto.IsWorkshop,
                EventId = sessionDto.EventId,
                VideoThumbnail = sessionDto.VideoThumbnail,
            };
            return session;
        }

        [ExcludeFromCodeCoverage]
        private UserSessionDto MapUserSession(Session s)
        {
            var userSessionDto = new UserSessionDto
            {
                Id = s.Id,
                Title = s.Title,
                Description = s.Description,
                EventId = s.EventId,
                IsKeynote = s.IsKeynote,
                IsSelected = s.IsSelected,
                IsWorkshop = s.IsWorkshop,
                VideoLink = s.VideoLink,
                VideoThumbnail = s.VideoThumbnail
            };
            return userSessionDto;
        }
    }
}