﻿using System.Diagnostics.CodeAnalysis;
using System.Diagnostics;
using System.Net;
using Microsoft.Extensions.Logging;
using TCC.Functions.Interfaces;
using TCC.Functions.Functions.User;
using Grpc.Core;
using Azure;
using Serilog.Core;
using TCC.Functions.Model;
namespace TCC.Functions.Implementations.Services
{

    /// <summary>
    /// This method will check a url to see that it does not return server or protocol errors
    /// </summary>
    /// <param name="url">The path to check</param>
    /// <returns></returns>
    /// Ticket Issue: https://github.com/orgs/TechnologyCodeCamp/projects/2/views/1?pane=issue&itemId=54165624
    ///The link is an ticket issue to: Add Unit Tests for URLValidator Class
    /// removed static
    public class UrlValidator
    {

        private IHttpWebRequestService _httpWebRequestService;
        public UrlValidator(IHttpWebRequestService httpWebRequestService)
        {
            _httpWebRequestService = httpWebRequestService;
        }


        public bool UrlIsValid(string url, ILogger _logger)
        {
            try
            {


                // Later in your code, you can now safely call
                var response = _httpWebRequestService.GetURLResponse(url);
                int statusCode = (int)response.StatusCode;

                if (statusCode < 400 && statusCode >= 100) // Good requests 
                {
                    return true;
                }
                else if (statusCode >= 500 && statusCode <= 510) // Server Errors
                {
                    Debug.WriteLine(string.Format("The remote server has thrown an internal error. Url is not valid: {0}", url));
                    return false;
                }

            }
            catch (WebException ex)
            {
                if (ex.Status == WebExceptionStatus.ProtocolError) //400 errors
                {
                    return false;
                }
                else if (ex.Status == WebExceptionStatus.Timeout)
                {
                    _logger.LogError(string.Format("Timeout status [{0}] returned for url: {1}", ex.Status, url), ex);
                    return false;
                }
                else
                {
                    _logger.LogWarning(string.Format("Unhandled status [{0}] returned for url: {1}", ex.Status, url), ex);
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(string.Format("Could not test url {0}.", url), ex);
            }
            return false;
        }

    }
}
