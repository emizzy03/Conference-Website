using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using TCC.Functions.Implementations.DTO.Auth;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Model;
using TCC.Functions.Model.Auth;

namespace TCC.Functions.Implementations.Services.Auth;
[ExcludeFromCodeCoverage]
public class AuthUserService:IAuthUserService
{
    private readonly ILogger<AuthUserService> _logger;
    private readonly IStorageService _storageService;
    private List<string> _userFileNames = [];
    private List<UserRoles> _userRoles = [];
    public AuthUserService(IStorageService storageService, ILogger<AuthUserService> logger)
    {
        _storageService = storageService;
        _logger = logger;
    }
    public async Task<bool> IsUserInRole(Guid userId, string[] roles)
    {
        var userString = await GetUserById(userId);
        if(userString!=string.Empty)
            JsonConvert.DeserializeObject<User>(userString);
        _userRoles = await GetUserRoles();
        var userRoles = GetUserRolesByUserId(userId);
        if (userRoles == null)
            await AddNewUserToRoles(userId);
        return await CheckIfUserIsInRole(userId, roles);
    }
    
    public async Task<string> GetUserById(Guid userId)
    {
        _logger.LogInformation("Getting User by Id from Storage");
        try
        {
            return await _storageService.GetDataFromStorage("public", $"users/{userId}/{userId}.json");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting user by Id from Storage");
            return string.Empty;
        }
    }

    public List<Roles> GetUserRolesByUserId(Guid userId)
    {
        var userRoles = _userRoles.Where(x => x.UserId == userId).FirstOrDefault();
        return userRoles?.UserRolesList;
    }

    public async Task<bool> CheckIfUserIsInRole(Guid userId, string[] roles)
    {
        var userRoles = _userRoles.Where(x => x.UserId == userId).FirstOrDefault();
        foreach(var userRole in userRoles.UserRolesList)
        {
            if(roles.Contains(userRole.ToString()))
                return true;
        }
        return false;
    }

    public async Task<AuthUserDto> GetUserProfile(ADUser user)
    {
        AuthUserDto authUserDto = new AuthUserDto
        {
            FirstName = null,
            LastName = null,
            Email = null
        };
        var storedUser = await GetUserById(user.Id);
        if(storedUser!=string.Empty)
        {
            var userDto = JsonConvert.DeserializeObject<User>(storedUser);
            authUserDto.Id = userDto.Id;
            authUserDto.FirstName = userDto.FirstName;
            authUserDto.LastName = userDto.LastName;
            authUserDto.Email = userDto.Email;
            authUserDto.PictureLink = userDto.PictureLink;
            authUserDto.IsExistingUser = true;
        }
        authUserDto.RolesList = GetUserRolesByUserId(user.Id);
        return authUserDto;
    }
    public async Task<List<UserRoles>> GetUserRoles()
    {
        _logger.LogInformation("Getting User by Id from Storage");
        try
        {
            var result = await _storageService.GetDataFromStorage("public", "userroles/userroles.json");
            return JsonConvert.DeserializeObject<List<UserRoles>>(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting user by Id from Storage");
            throw;
        }
    }
    public async Task AddNewUserToRoles(Guid userId)
    {
        try
        {
            var defaultRole =Environment.GetEnvironmentVariable("DefaultRole") ?? string.Empty;
            var userRole = (Roles)Enum.Parse(typeof(Roles), defaultRole);
            var newUserRole = new UserRoles
            {
                Id = Guid.NewGuid(),
                UserId = userId,
                UserRolesList = [userRole]
            };
            _userRoles.Add(newUserRole);
            await _storageService.WriteBlobContent("public", "userroles/userroles.json", 
                JsonConvert.SerializeObject(_userRoles));
        }
        catch (Exception e)
        {
            _logger.LogError(e, "Error adding new user to roles");
            throw;
        }
    }
}