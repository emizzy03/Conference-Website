using System.Text;
using Newtonsoft.Json.Linq;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;

namespace TCC.Functions.Implementations.Services.Auth;

public class AzureADService:IAzureADService
{
    private readonly IHttpService _httpService;

    public AzureADService(IHttpService httpService)
    {
        _httpService = httpService;
    }

    public async Task<JObject> GetAuthTokenFromMicrosoftAsync()
    {
        var tenantId = Environment.GetEnvironmentVariable("TenantId") ?? string.Empty;
        var clientId = Environment.GetEnvironmentVariable("ClientId") ?? string.Empty;
        var clientSecret = Environment.GetEnvironmentVariable("ClientSecret") ?? string.Empty;
        var authApi = $"https://login.microsoft.com/{tenantId}/oauth2/token";

        var body =
            $"grant_type=client_credentials&client_id={clientId}&client_secret={clientSecret}&resource=https://graph.microsoft.com/";
        var content = new StringContent(body, Encoding.UTF8, "application/x-www-form-urlencoded");

        var response = await _httpService.PostStringContentRequest(authApi, content, string.Empty);

        if (response == null || response["access_token"] == null)
            throw new Exception("Authentication Token is null");
        return response;
    }
}