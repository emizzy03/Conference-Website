﻿using Microsoft.Extensions.Logging;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Interfaces;
using TCC.Functions.Model;

namespace TCC.Functions.Implementations.Services
{
    public class ContactUsService : IContactUsService
    {
        private readonly ILogger<ContactUsService> _logger;
        private readonly IStorageService _service;
        public ContactUsService(IStorageService service, ILogger<ContactUsService> logger)
        {
            _service = service;
            _logger = logger;

        }
     
        public async Task ProcessContactUsData(ContactUsDto message)
        {
            ContactUs contactUsData = new ContactUs()
            {
                EmailAddress = message.EmailAddress,
                Id = Guid.NewGuid(),
                Organization = message.Organization,
                Role = message.Role,
                Message = message.Message,
                Name = message.Name
            };

            // Serialize the ContactUs object to a JSON string
            _logger.LogInformation($"Successfully stored contact data for Id: {contactUsData.Id}");
            try
            {
                string data = System.Text.Json.JsonSerializer.Serialize(contactUsData);

                // The path for the file should be in the "messages" folder, and the file name is the Id from the ContactUs object
                string path = $"messages/{contactUsData.Id}.json";

                await _service.WriteBlobContent("public", path, data);
            }
            catch (Exception ex)
            {   
                _logger.LogError(ex, $"Failed to store contact data for Id: {contactUsData.Id}");
                throw;
            }
        }
    }
}
