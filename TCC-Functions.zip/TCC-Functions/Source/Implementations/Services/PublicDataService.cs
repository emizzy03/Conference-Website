using System.Diagnostics;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using TCC.Functions.Extensions;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Interfaces;
using TCC.Functions.Model;

namespace TCC.Functions.Implementations.Services;

public class PublicDataService:IPublicDataService
{
    private readonly ILogger<PublicDataService> _logger;
    private readonly IStorageService _storageService;
    private List<string> _eventFileNames = [];
    private List<string> _userFileNames = [];
    private List<string> _sessionFileNames = [];
    private List<string> _staff = [];
    private readonly UrlValidator urlValidator;
    public PublicDataService(IStorageService storageService, ILogger<PublicDataService> logger, IHttpWebRequestService httpWebRequestService)
    {
        _storageService = storageService;
        _logger = logger;
        urlValidator = new UrlValidator(httpWebRequestService);
    }
    
    public void GetBlobItems()
    {
        _logger.LogInformation("Getting items in the blob container");
        try
        {
            var result = _storageService.GetBlobs("public");
            _userFileNames = result.Where(r => 
                r.StartsWith("users") && r.EndsWith(".json") && !r.Contains("socialmedia")
                ).Select(r => r).ToList();
            _sessionFileNames = result.Where(r => r.Contains("/sessions") && r.EndsWith(".json")).Select(r => r)
                .ToList();
            _staff = result.Where(r => r.Contains("/staff") && r.EndsWith(".json")).Select(r => r)
                .ToList();
            _eventFileNames = result
                .Where(r => r.StartsWith("events")
                              && r.EndsWith(".json")
                              && r.Split("/").Length == 3)
                .Select(r => r)
                .ToList();
            _logger.LogInformation(
                $"Blob Items found: {_userFileNames.Count} users, {_sessionFileNames.Count} sessions, {_eventFileNames.Count} events");
        }
        catch (ArgumentNullException ex)
        {
            _logger.LogError(ex, $"GetBlobs returned Null or Empty for container: public");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting items from blob container: public");
            throw;
        }
    }
    public async Task<string> GetPrivacy()
    {
        _logger.LogInformation("Getting Privacy Policy from Storage");
        try
        {
            var result = await _storageService.GetDataFromStorage("public", "privacy.json");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting privacy policy from Storage");
            throw;
        }
    }

    public async Task<string> GetCodeOfConduct()
    {
        _logger.LogInformation("Getting Code Of Conduct from Storage");
        try
        {
            var result = await _storageService.GetDataFromStorage("public", "codeofconduct.json");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting Code Of Conduct from Storage");
            throw;
        }
    }

    public async Task<List<SessionDto>> GetSessionsByEventId(List<string> sessionFileNames, Guid eventId)
    {
        _logger.LogInformation("Acquiring Sessions Data from Storage");
        try
        {
            List<SessionDto> sessions = [];
            foreach (var u in sessionFileNames)
            {
                if (!u.Contains(eventId.ToString())) continue;
                var result = await _storageService.GetDataFromStorage("public", u);
                var session = JsonConvert.DeserializeObject<Session?>(result);
                if (session != null) sessions.Add(MapSession(session));
            }
            return sessions;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error Acquiring Sessions Data from Storage");
            throw;
        }
    }
    [ExcludeFromCodeCoverage] // To-Do: Ticket #131
    public async Task<List<string>> GetSessionFileNames()
    {
        _logger.LogInformation("Acquiring Sessions Data from Storage");
        try
        {
            return _sessionFileNames;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error Acquiring Sessions Data from Storage");
            throw;
        }
    }

    public async Task<List<Staff>> GetStaffByEventId(List<string> staffFileNames, Guid eventId)
    {
        _logger.LogInformation("Acquiring Staff Data from Storage");
        try
        {
            var staffList = new List<Staff>();
            foreach(var u in staffFileNames)
            {
                if (!u.Contains(eventId.ToString())) continue;
                var result = await _storageService.GetDataFromStorage("public", u);
                var staff = JsonConvert.DeserializeObject<Staff?>(result);
                if (staff != null) staffList.Add(staff);
            }
            return staffList;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error Acquiring Staff Data from Storage");
            throw;
        }
    }

    public async Task CreateSpeakersList()
    {
        _logger.LogInformation("Creating Speakers Data from Storage");
        try
        {
            List<User> usersList = [];
            var events = await GetEvents(true);
            foreach(var u in _userFileNames)
            {
                _logger.LogInformation($"Reading Data for {u} user from Storage at: {u}");
                var result = await _storageService.GetDataFromStorage("public", u);
                if (string.IsNullOrEmpty(result))
                {
                    _logger.LogWarning($"User {u} is null or empty.");
                    continue;
                }

                var user = JsonConvert.DeserializeObject<User>(result);
                if (user is { PresentationSessions.Count: > 0 }||
                    events.Any(e => e.Staff.Any(s => s.UserId == user.Id)))
                {
                    user.Email = string.Empty;
                    user.PictureLink=(string.IsNullOrEmpty(user.PictureLink) || !urlValidator.UrlIsValid(user.PictureLink, _logger)) ? "https://creazilla-store.fra1.digitaloceanspaces.com/icons/3220761/user-circle-icon-md.png":user.PictureLink;
                    usersList.Add(user);
                }
            }
            if (usersList.Count > 0)
            {
                await _storageService.WriteObjectToBlobContent("web", "cdn-data/publicprofiles.json", usersList);
                _logger.LogInformation($"Finished Creating Speakers Data from Storage with {usersList.Count} speakers");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating speakers in Storage");
            throw;
        }
    }
    
    public async Task CreateConferenceInfo()
    {
        _logger.LogInformation("Creating ConferenceInfo from Storage");
        try
        {
            var conferenceInfoDto = await GetConferenceInfo();

            await _storageService.WriteObjectToBlobContent("web", "cdn-data/conferenceinfo.json", conferenceInfoDto);
            _logger.LogInformation("Finished creating ConferenceInfo into Storage");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating ConferenceInfo from Storage");
            throw;
        }
    }

    public async Task<ConferenceInfoDto> GetConferenceInfo()
    {
        _logger.LogInformation("Getting ConferenceInfo from Storage");
        try
        {
            var confInfoString = await _storageService.GetDataFromStorage("public", "conferenceinfo.json");
            var confInfo = JsonConvert.DeserializeObject<ConferenceInfo>(confInfoString);

            if (confInfo is null)
                throw new Exception("ConferenceInfo not found");
            var conferenceInfoDto = await MapConferenceInfo(confInfo);
            var events = await GetEvents();
            conferenceInfoDto.CurrentEventId =
                events.Where(e => e.Status == EventStatus.Active).Select(e => e.Id).FirstOrDefault();

            _logger.LogInformation("Finished getting ConferenceInfo from Storage");
            return conferenceInfoDto;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting ConferenceInfo from Storage");
            throw;
        }
    }

    public async Task CreateEvents()
    {
        _logger.LogInformation("Creating Events from Storage");
        try
        {
            List<EventDto> eventsList = await GetEvents(true);
            foreach(var e in eventsList)
            {
                await _storageService.WriteObjectToBlobContent("web", $"cdn-data/events/{e.Id}.json", e);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating events from Storage");
            throw;
        }
    }

    public async Task CreateEventById(Guid eventId)
    {
        _logger.LogInformation("Creating Event from Storage");
        try
        {
            var eventDto = (await GetEvents(true)).FirstOrDefault(e => e.Id == eventId);
            if (eventDto == null)
            {
                throw new Exception("Event not found");
            }
            await _storageService.WriteObjectToBlobContent("web", $"cdn-data/events/{eventDto.Id}.json", eventDto);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating event from Storage");
            throw;
        }
    }
    [ExcludeFromCodeCoverage]
    private async Task<ConferenceInfoDto> MapConferenceInfo(ConferenceInfo conferenceInfo)
    {
        var conferenceInfoDto = new ConferenceInfoDto
        {
            Id = conferenceInfo.Id,
            Name = conferenceInfo.Name,
            Address1 = conferenceInfo.Address1,
            Address2 = conferenceInfo.Address2,
            City = conferenceInfo.City,
            State = conferenceInfo.State,
            Zip = conferenceInfo.Zip,
            Email = conferenceInfo.Email,
            Description = conferenceInfo.Description,
            Phone = conferenceInfo.Phone,
            Image = conferenceInfo.Image,
            MissionStatement = conferenceInfo.MissionStatement,
            LocationHeader = conferenceInfo.LocationHeader,
            MiscInfo = conferenceInfo.MiscInfo,
            StaffDescription = conferenceInfo.StaffDescription,
            Privacy = await GetPrivacy(),
            CoC = await GetCodeOfConduct(),
        };
        return conferenceInfoDto;
    }
    [ExcludeFromCodeCoverage]
    private EventDto MapEvent(Event e)
    {
        var eventDto = new EventDto
        {
            Id = e.Id,
            Name = e.Name,
            StartDate = e.StartDate,
            EndDate = e.EndDate,
            Status = e.Status,
            Address1 = e.Address1,
            Address2 = e.Address2,
            City = e.City,
            State = e.State,
            Zip = e.Zip,
            LocationDescription = e.LocationDescription,
            KeynoteSelected = e.KeynoteSelected,
            CallForSpeakerOpen = e.CallForSpeakerOpen,
            IsWorkshopSessionAllowed = e.IsWorkshopSessionAllowed,
            SessionsSelected = e.SessionsSelected,
            Year = e.Year,
            Sessions = [],
        };
        return eventDto;
    }
    [ExcludeFromCodeCoverage]
    private SessionDto MapSession(Session s)
    {
        var sessionDto = new SessionDto
        {
            Id = s.Id,
            Title = s.Title,
            Description = s.Description,
            UserId = s.UserId,
            EventId = s.EventId,
            IsKeynote = s.IsKeynote,
            IsSelected = s.IsSelected,
            IsWorkshop = s.IsWorkshop,
            VideoLink = s.VideoLink,
            VideoThumbnail = s.VideoThumbnail
        };
        return sessionDto;
    }
    public async Task<List<EventDto>> GetEvents(bool includeSessions = false)
    {
        _logger.LogInformation("Acquiring list of events from Storage");
        try
        {
            List<EventDto> eventsList = [];
            foreach (var e in _eventFileNames)
            {
                var eventString = await _storageService.GetDataFromStorage("public", e);
                var eventObj = JsonConvert.DeserializeObject<Event>(eventString);
                if(eventObj is null)
                    continue;
                var eventDto = MapEvent(eventObj);
                if (includeSessions)
                {
                    eventDto.Sessions = await GetSessionsByEventId(_sessionFileNames, eventDto.Id);
                    eventDto.Staff = await GetStaffByEventId(_staff, eventDto.Id);
                }
                eventsList.Add(eventDto);
            }
            _logger.LogInformation($"Acquired {eventsList.Count} events from Storage");
            return eventsList;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting speakers from Storage");
            throw;
        }
    }

    

    public async Task<List<SocialMediaPlatform>> GetSocialMediaPlatforms()
    {
        _logger.LogInformation("Getting Social Media Platforms from Storage");
        try
        {
            bool exist = await _storageService.BlobExists("public", "socialmediaplatforms/socialmediaplatforms.json");
            if (exist)
            {
                var result = await _storageService.GetDataFromStorage("public", "socialmediaplatforms/socialmediaplatforms.json");
                List<SocialMediaPlatform> socialMediaPatformsList = JsonConvert.DeserializeObject<List<SocialMediaPlatform>>(result);
                return socialMediaPatformsList;
            } else
            {
                return new List<SocialMediaPlatform>();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting Social Media Platforms from Storage");
            throw;
        }
    }
}