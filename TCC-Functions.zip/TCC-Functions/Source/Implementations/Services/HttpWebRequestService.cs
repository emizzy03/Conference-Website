﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using Microsoft.Extensions.Logging;
using TCC.Functions.Interfaces;
using TCC.Functions.Model;

namespace TCC.Functions.Implementations.Services
{
    [ExcludeFromCodeCoverage]
    public class HttpWebRequestService : IHttpWebRequestService
    {
        private readonly ILogger<HttpWebRequestService> _logger;

        public HttpWebRequestService(ILogger<HttpWebRequestService> logger)
        {
            _logger = logger;
        }

        public WebRequestResponse GetURLResponse(string url)
        {
            if (string.IsNullOrEmpty(url))
            {
                throw new ArgumentException("URL cannot be null or empty.", nameof(url));
            }

            try
            {
                var request = (HttpWebRequest)WebRequest.Create(url);
                request.Timeout = 5000; // Set the timeout to 5 seconds to keep the user from waiting too long for the page to load
                request.Method = "HEAD"; // Get only the header information -- no need to download any content

                using (HttpWebResponse standardResponse = (HttpWebResponse)request.GetResponse())
                {
                    return CreateMyWebResponse(standardResponse);
                }
            }
            catch (WebException ex)
            {
                _logger.LogError($"WebException occurred: {ex.Message}, \n\tLink: {url}", ex);
                if (ex.Response is HttpWebResponse httpResponse)
                {
                    return CreateMyWebResponse(httpResponse);
                }   
                
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception occurred: {ex.Message}", ex);
               
            }
            return null;

        }

        private WebRequestResponse CreateMyWebResponse(HttpWebResponse response)
        {
            return new WebRequestResponse
            {
                StatusCode = response.StatusCode,
            };
        }
    }
}
