using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using TCC.Functions.Interfaces;
using TCC.Functions.Model.Exceptions;

namespace TCC.Functions.Implementations.Services;

[ExcludeFromCodeCoverage]
public class HttpService : IHttpService
{
    private Uri? _baseAddress;
    private Dictionary<string, string>? _httpHeadersDictionary;
    private string _mediaTypeContent = "application/json";

    public Task<HttpResponseMessage> PostJsonRequest(Uri uri, JToken request)
    {
        var client = CreateClient();
        var requestMessage = new HttpRequestMessage(HttpMethod.Post, uri);
        var requestAsString = request.ToString();
        requestMessage.Content = new StringContent(requestAsString);
        requestMessage.Content.Headers.ContentType = new MediaTypeHeaderValue(_mediaTypeContent);
        return client.SendAsync(requestMessage);
    }

    public async Task<JObject?> GetJsonRequest(string uriString)
    {
        var client = CreateClient();
        var uri = GenerateEndpointUri(uriString);
        var message = new HttpRequestMessage(HttpMethod.Get, uri);
        message.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue(_mediaTypeContent));
        var response = await client.SendAsync(message);

        if (response.StatusCode == HttpStatusCode.OK)
        {
            var value = await response.Content.ReadAsStringAsync();
            var jsonObject = JsonConvert.DeserializeObject<JObject>(value);
            return jsonObject;
        }

        if (response.StatusCode == HttpStatusCode.NotFound)
            throw new ItemNotFoundException(new
            {
                uri
            });

        throw new HttpServiceException(new
        {
            response.StatusCode,
            message = await response.Content.ReadAsStringAsync()
        });
    }

    public async Task<JObject?> PostFormRequest(string uriString, MultipartFormDataContent form)
    {
        var client = CreateClient();
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("multipart/form-data"));
        var uri = GenerateEndpointUri(uriString);
        var requestMessage = new HttpRequestMessage(HttpMethod.Post, uri);
        requestMessage.Content = form;
        var response = await client.SendAsync(requestMessage);
        if (response.StatusCode is HttpStatusCode.OK or HttpStatusCode.Created)
        {
            var value = await response.Content.ReadAsStringAsync();
            var jsonObject = JsonConvert.DeserializeObject<JObject>(value);

            return jsonObject;
        }

        if (response.StatusCode == HttpStatusCode.NotFound)
            throw new ItemNotFoundException(new
            {
                uri
            });

        throw new HttpServiceException(new
        {
            response.StatusCode,
            message = await response.Content.ReadAsStringAsync()
        });
    }

    public async Task<JObject?> PostStringContentRequest(string uriString, StringContent content)
    {
        return await PostStringContentRequest(uriString, content, _mediaTypeContent);
    }

    public async Task<JObject?> PostStringContentRequest(string uriString, StringContent content, string contentType)
    {
        var client = CreateClient();
        var uri = GenerateEndpointUri(uriString);
        var requestMessage = new HttpRequestMessage(HttpMethod.Post, uri);
        requestMessage.Content = content;
        _mediaTypeContent = contentType;
        if (!string.IsNullOrEmpty(_mediaTypeContent))
            requestMessage.Content.Headers.ContentType = new MediaTypeHeaderValue(_mediaTypeContent);

        var response = await client.SendAsync(requestMessage);
        if (response.StatusCode == HttpStatusCode.OK)
        {
            var value = await response.Content.ReadAsStringAsync();
            var jsonObject = JsonConvert.DeserializeObject<JObject>(value);

            return jsonObject;
        }

        if (response.StatusCode == HttpStatusCode.NotFound)
            throw new ItemNotFoundException(new
            {
                uri
            });

        throw new HttpServiceException(new
        {
            response.StatusCode,
            message = await response.Content.ReadAsStringAsync()
        });
    }

    public async Task<JObject?> DeleteJsonRequest(string uriString)
    {
        var client = CreateClient();
        var uri = GenerateEndpointUri(uriString);
        var message = new HttpRequestMessage(HttpMethod.Delete, uri);
        message.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue(_mediaTypeContent));
        var response = await client.SendAsync(message);

        if (response.StatusCode == HttpStatusCode.OK)
        {
            var value = await response.Content.ReadAsStringAsync();
            var jsonObject = JsonConvert.DeserializeObject<JObject>(value);

            return jsonObject;
        }

        if (response.StatusCode == HttpStatusCode.NotFound)
            throw new ItemNotFoundException(new
            {
                uri
            });

        throw new HttpServiceException(new
        {
            response.StatusCode,
            message = await response.Content.ReadAsStringAsync()
        });
    }

    public void SetBaseAddress(Uri baseAddress)
    {
        _baseAddress = baseAddress;
    }

    public void SetDefaultHeaders(Dictionary<string, string> httpHeader)
    {
        _httpHeadersDictionary = httpHeader;
    }

    public void SetMediaType(string mediaType)
    {
        _mediaTypeContent = mediaType;
    }

    private HttpClient CreateClient()
    {
        var client = _baseAddress == null
            ? new HttpClient()
            : new HttpClient { BaseAddress = _baseAddress };
        if (_httpHeadersDictionary != null && _httpHeadersDictionary.Count > 0)
            AddHttpDefaultHeaders(ref client);
        return client;
    }

    private void AddHttpDefaultHeaders(ref HttpClient client)
    {
        if (_httpHeadersDictionary == null)
            return;
        foreach (var header in _httpHeadersDictionary) client.DefaultRequestHeaders.Add(header.Key, header.Value);
    }

    private Uri GenerateEndpointUri(string uri)
    {
        return _baseAddress == null ? new Uri(uri) : new Uri(_baseAddress.AbsoluteUri + uri);
    }
}