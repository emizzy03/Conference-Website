﻿using Azure.Storage.Blobs;
using Microsoft.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using Azure.Storage.Blobs.Models;
using Newtonsoft.Json;
using TCC.Functions.Interfaces;
using Azure;

namespace TCC.Functions.Implementations.Services;

[ExcludeFromCodeCoverage]
public class StorageService : IStorageService
{
    private readonly ILogger<StorageService> _logger;
    private readonly string _connectionString;
    public StorageService(ILogger<StorageService> logger)
    {
        _connectionString = Environment.GetEnvironmentVariable("AzureStorageConnectionString") ?? string.Empty;
        _logger = logger;
    }

    public async Task<byte[]> GetBlobContent(string container, string path)
    {
        _logger.LogInformation($"Grabbing Blob Content from container: {@container} path: {@path}");
        try
        {
            var containerClient = new BlobContainerClient(_connectionString, container);
            var blobClient = containerClient.GetBlobClient(path);
            var memoryStream = new MemoryStream();

            await blobClient.DownloadToAsync(memoryStream);
            var content = memoryStream.ToArray();
            return content;
        }
        catch (FormatException ex)
        {
            _logger.LogError(ex, $"FormatException: Error getting Blob Content from container: {@container} path: {@path}");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Exception: Error getting Blob Content from container: {@container} path: {@path}");
            throw;
        }
    }

    public async Task DeleteFolderByPath(string containerName, string folderPath)
    {
        try
        {
            BlobContainerClient containerClient = new BlobContainerClient(_connectionString, containerName);

            if (!folderPath.EndsWith("/"))
            {
                folderPath += "/";
            }

            await foreach (var blobItem in containerClient.GetBlobsAsync(prefix: folderPath))
            {
                BlobClient blobClient = containerClient.GetBlobClient(blobItem.Name);
                await blobClient.DeleteIfExistsAsync();
                _logger.LogInformation($"Blob '{blobItem.Name}' deleted successfully.");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Exception: Error deleting blobs at path: {folderPath}");
            throw;
        }
    }

    public async Task<string> GetDataFromStorage(string container, string path)
    {
        _logger.LogInformation($"Retrieving Info from " + path);
        try
        {
            var byteArray = await GetBlobContent(container, path);
            var result = Encoding.UTF8.GetString(byteArray);
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Grabbing Blob Content from container: {@container} path: {@path}");
            throw;
        }
    }

    public async Task WriteObjectToBlobContent(string container, string path, object data)
    {
        var stringData = JsonConvert.SerializeObject(data);
        await WriteBlobContent(container, path, stringData);
    }

    public async Task WriteBlobContent(string container, string path, string data)
    {
        try
        {
            BlobContainerClient blobContainer = new BlobContainerClient(_connectionString, container);
            //blobContainer.Create();

            BlobClient blob = blobContainer.GetBlobClient(path);

            var content = Encoding.UTF8.GetBytes(data);

            using var ms = new MemoryStream(content);
            await blob.UploadAsync(ms, overwrite: true); // "true" overwrites the blob if it exists
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Exception: Error writing to container: {@container} path: {@path}");
            throw;
        }
    }
    public List<string> GetBlobs(string container)
    {
        _logger.LogInformation("Getting blobs from:{Container}", container);
        try
        {
            var containerClient = new BlobContainerClient(_connectionString, container);
            var blobs = containerClient.GetBlobs(BlobTraits.Metadata);
            return blobs.ToList().Select(b => b.Name).ToList();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error Getting blobs from:{Container}",
                container);
            throw;
        }
    }
    public async Task<bool> BlobExists(string container, string path)
    {
        try
        {
            var containerClient = new BlobContainerClient(_connectionString, container);
            var blobClient = containerClient.GetBlobClient(path);
            return await blobClient.ExistsAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error checking if blob exists in container: {Container}", container);
            throw;
        }
    }
    public async Task DeleteFileByPath(string containerName, string path)
    {
        try
        {
            BlobContainerClient containerClient = new BlobContainerClient(_connectionString, containerName);

            BlobClient blobClient = containerClient.GetBlobClient(path);

            bool isDeleted = await blobClient.DeleteIfExistsAsync();

            if (isDeleted)
            {
                _logger.LogInformation($"Blob '{path}' deleted successfully.");
            }
            else
            {
                _logger.LogInformation($"Unable to delete blob '{path}'");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Exception: Error deleting blob at path: {path}");
            throw;
        }
    }

}