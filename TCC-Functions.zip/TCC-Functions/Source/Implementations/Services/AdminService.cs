﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Interfaces;
using TCC.Functions.Model;

namespace TCC.Functions.Implementations.Services
{
    public class AdminService : IAdminService
    {
        private readonly ILogger<AdminService> _logger;
        private readonly IStorageService _storageService;
        private readonly IPublicDataService _publicDataService;
        private Guid SocialMediaId;

        public AdminService(ILogger<AdminService> logger, IStorageService storageService, IPublicDataService publicDataService)
        {
            _logger = logger;
            _storageService = storageService;
            _publicDataService = publicDataService;
        }

        public async Task SaveCodeOfConduct(string content)
        {
            _logger.LogInformation("overwritten the codeOfConduct.json file");
            try
            {
                await _storageService.WriteBlobContent("public", "codeofconduct.json", content);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error writing code of conduct content to blob");
                throw;
            }
        }
        public async Task SaveConference(ConferenceInfoDto conference)
        {
            ConferenceInfo conferenceInfo = new ConferenceInfo()
            {
                Id = conference.Id,
                Name = conference.Name,
                Address1 = conference.Address1,
                Address2 = conference.Address2,
                City = conference.City,
                State = conference.State,
                Zip = conference.Zip,
                Email = conference.Email,
                Description = conference.Description,
                Phone = conference.Phone,
                Image = conference.Image,
                MissionStatement = conference.MissionStatement,
                LocationHeader = conference.LocationHeader,
                MiscInfo = conference.MiscInfo,
                StaffDescription = conference.StaffDescription,
            };

            _logger.LogInformation($"Successfully stored data for conference Info.");
            try
            {
                string path = $"conferenceinfo.json";

                await _storageService.WriteObjectToBlobContent("public", path, conferenceInfo);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Failed to store data for conference Info.");
                throw;
            }
        }


        public async Task SavePrivacy(string content)
        {
            _logger.LogInformation("Attempting overwritten the privacy.json file");
            try
            {
                await _storageService.WriteBlobContent("public", "privacy.json", content);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error writing privacy content to blob");
                throw;
            }
        }

        public async Task RemoveEvent(EventDto eventToRemove)
        {
            _logger.LogInformation("Attempting to remove the Event");

            var path = $"events/{eventToRemove.Id}/";
            var sessionfolder = _storageService.GetBlobs(path);

            try
            {
                foreach (var blob in sessionfolder)
                {
                    if (blob.Contains("sessions"))
                    {
                        await RemoveSessionsFromUser(eventToRemove);
                    }
                    await _storageService.DeleteFolderByPath("public", path);

                }
                _logger.LogInformation($"Removed file at path: {path}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error removing file at: {path}");


                throw;
            }

            _logger.LogInformation("Completed removal of Event");
        }

        public async Task SaveSocialMediaPlatforms(List<SocialMediaPlatform> socialMediaPlatforms)
        {
            _logger.LogInformation("Attempting to update the Social Media Platforms");
            List<SocialMediaPlatform> resultSocialMediaPlatforms = new List<SocialMediaPlatform>();
            for (int i = 0; i < socialMediaPlatforms.Count; i++)
            {
                SocialMediaId = socialMediaPlatforms[i].Id != Guid.Empty ? socialMediaPlatforms[i].Id : Guid.NewGuid();
                SocialMediaPlatform socialMediaPlatform = new SocialMediaPlatform()
                {
                    Id = SocialMediaId,
                    Icon = socialMediaPlatforms[i].Icon,
                    Name = socialMediaPlatforms[i].Name,
                };
                resultSocialMediaPlatforms.Add(socialMediaPlatform);
            }
            try
            {
                string content = JsonConvert.SerializeObject(resultSocialMediaPlatforms);
                await _storageService.WriteBlobContent("public", "socialmediaplatforms/socialmediaplatforms.json", content);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error writing social media platforms content to blob");
                throw;
            }
        }

        public async Task RemoveSocialMediaPlatform(SocialMediaPlatform socialMediaPlatform)
        {
            _logger.LogInformation("Attempting to remove the Social Media Platforms");

            List<SocialMediaPlatform> socialMediaPlatforms = await _publicDataService.GetSocialMediaPlatforms();

            await RemoveEntireSocialMediaPlatformObject(socialMediaPlatform);

            //We remove the passed in socialMediaPlatform from the UI

            for (int i = 0; i < socialMediaPlatforms.Count; i++)
            {
                if (socialMediaPlatforms[i].Id == socialMediaPlatform.Id)
                {
                    socialMediaPlatforms.RemoveAt(i);
                }
            }
            try
            {
                string content = JsonConvert.SerializeObject(socialMediaPlatforms);
                await _storageService.WriteBlobContent("public", "socialmediaplatforms/socialmediaplatforms.json", content);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing social media platform in blob");
                throw;
            }
        }

        private async Task RemoveEntireSocialMediaPlatformObject(SocialMediaPlatform platformToRemove)
        {
            _logger.LogInformation($"Starting removal of social media platform: {platformToRemove.Name}");

            // List all blobs in the "public" container
            var blobs = _storageService.GetBlobs("public");

            // Filter for user social media data files
            var userSocialMediaFiles = blobs.Where(b => b.StartsWith("users") && b.Contains("/socialmedia")).ToList();

            for (int i = 0; i < userSocialMediaFiles.Count; i++)
            {
                _logger.LogInformation($"Processing social media data for: {userSocialMediaFiles[i]}");

                try
                {
                    // Fetch social media data for the user
                    var socialMediaDataJson = await _storageService.GetDataFromStorage("public", userSocialMediaFiles[i]);
                    var socialMediaLinks = JsonConvert.DeserializeObject<List<UserSocialMedia>>(socialMediaDataJson);

                    for (int j = 0; j < socialMediaLinks.Count; j++)
                    {
                        if (socialMediaLinks[j].SocialMediaPlatformId.Equals(platformToRemove.Id))
                        {
                            socialMediaLinks.RemoveAt(j);
                            if (socialMediaLinks.Count == 0)
                            {
                                await _storageService.DeleteFileByPath("public", userSocialMediaFiles[i]);
                            }
                        }
                    }
                    bool blobexist = await _storageService.BlobExists("public", userSocialMediaFiles[i]);
                    try
                    {
                        if (blobexist)
                        {
                            var updatedJson = JsonConvert.SerializeObject(socialMediaLinks);
                            await _storageService.WriteBlobContent("public", userSocialMediaFiles[i], updatedJson);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Error removing user social media platform in blob");
                        throw;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, $"Error processing social media data for user file: {userSocialMediaFiles[i]}");
                }

            }
            _logger.LogInformation("Completed removal of social media platform.");
           }

        public async Task RemoveSessionsFromUser(EventDto eventtoCheck)
        {
            try
            {
                var path = $"public/events/{eventtoCheck.Id}/sessions/";
                var pathfolder = _storageService.GetBlobs(path);

                // Extract session IDs from folder names using LINQ

                var sessionIdsToRemove = pathfolder
                   .Where(folderName => folderName.EndsWith(".json"))
                   .Select(async folderName =>
                   {
                       var fileName = Path.GetFileNameWithoutExtension(folderName);
                       if (Guid.TryParse(fileName, out var sessionId))
                       {
                           return sessionId;
                       }
                       return Guid.Empty;
                   });
                    var sessionIds = await Task.WhenAll(sessionIdsToRemove);
                    var sessionIdsToRemoveIds = sessionIds
                    .Where(sessionId => sessionId != Guid.Empty)
                    .ToList();

                var userFiles = _storageService.GetBlobs("public");
                var userTasks = userFiles
                    .Where(file => file.StartsWith("users/") && file.EndsWith(".json"))
                   .Select(async file =>
                   {
                       var userJson = await _storageService.GetDataFromStorage("public", file);
                       if (!string.IsNullOrEmpty(userJson))
                       {
                           var userObject = JsonConvert.DeserializeObject<UserDTO>(userJson);
                           if (userObject != null && userObject.PresentationSessions != null)
                           {
                               var originalCount = userObject.PresentationSessions.Count;
                               userObject.PresentationSessions.RemoveAll(id => sessionIdsToRemoveIds.Contains(id));

                               // If changes were made, write back the updated user data
                               if (userObject.PresentationSessions.Count != originalCount)
                               {
                                   await _storageService.WriteObjectToBlobContent("public", file, JsonConvert.SerializeObject(userObject));
                               }
                           }
                       }
                   });



                await Task.WhenAll(userTasks);

                _logger.LogInformation("Completed removal of session(s) from users.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing session then events");
                throw;
            }
        }
    }
}

    
