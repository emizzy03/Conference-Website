﻿using System.Net;
using System.Security;
using Azure;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Serilog.Core;
using TCC.Functions.Implementations.Auth;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Model;

namespace TCC.Functions.Functions
{
    public class AdminCoCFunction : AuthenticationBase
    {
        private readonly ILogger<AdminCoCFunction> _logger;
        private readonly IAdminService _codeOfConductService;
        private readonly IPublicDataService _publicDataService;

        public AdminCoCFunction(IAdminService codeOfConductService, ILogger<AdminCoCFunction> logger, IPublicDataService publicDataService, IHttpService httpService,
            IAzureADService azureAdService, IAuthUserService authUserService)
        {
            _httpService = httpService;
            _azureAdService = azureAdService;
            _authUserService = authUserService;
            _codeOfConductService = codeOfConductService;
            _logger = logger;
            _publicDataService = publicDataService;
        }

        [Function("CodeOfConduct")]
        public async Task<HttpResponseData> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            try
            {
                await Roles(req, ["Admin"]);

                var content = await req.ReadAsStringAsync();
                if (String.IsNullOrEmpty(content))
                {
                    throw new Exception("Content not found");
                }
                else
                {
                    await _codeOfConductService.SaveCodeOfConduct(content);
                    _publicDataService.GetBlobItems();
                    await _publicDataService.CreateConferenceInfo();
                    var response = req.CreateResponse(HttpStatusCode.OK);
                    return response;
                }

            }
            catch (SecurityException ex)
            {
                _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
                var response = req.CreateResponse(HttpStatusCode.Unauthorized);
                response.WriteString($"Unauthorized.");
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error writing code of conduct content to blob");
                var response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("Error");
                throw;
            }


        }
    }
}