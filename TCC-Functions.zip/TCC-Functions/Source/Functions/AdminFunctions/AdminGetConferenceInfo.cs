using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net;
using System.Security;
using TCC.Functions.Implementations.Auth;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;

namespace TCC.Functions.Functions;

public class AdminGetConferenceInfo : AuthenticationBase
{
    private readonly ILogger<UpdateAllPublicDataSet> _logger;

    private readonly IPublicDataService _publicDataService;
    public AdminGetConferenceInfo(IPublicDataService publicDataService, ILogger<UpdateAllPublicDataSet> logger, IHttpService httpService,
            IAzureADService azureAdService, IAuthUserService authUserService)
    {
        _httpService = httpService;
        _azureAdService = azureAdService;
        _authUserService = authUserService;
        _logger = logger;
        _publicDataService = publicDataService;
    }

    [Function("GetConferenceInfo")]
    public async Task<HttpResponseData> Run([HttpTrigger(AuthorizationLevel.Function, "get")] HttpRequestData req)
    {
        try
        {
            await Roles(req, ["Admin"]);

            _logger.LogInformation("Received API Request to acquire Conference Info");

            var ConferenceInfoResult = await _publicDataService.GetConferenceInfo();

            var response = req.CreateResponse(HttpStatusCode.OK);
            response.Headers.Add("Content-Type", "text/plain; charset=utf-8");
            response.WriteString(JsonConvert.SerializeObject(ConferenceInfoResult));
            return response;
        }
        catch (SecurityException ex)
        {
            _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
            var response = req.CreateResponse(HttpStatusCode.Unauthorized);
            response.WriteString($"Unauthorized.");
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "GetConferenceInfo Exception");
            throw;
        }
    }
}
