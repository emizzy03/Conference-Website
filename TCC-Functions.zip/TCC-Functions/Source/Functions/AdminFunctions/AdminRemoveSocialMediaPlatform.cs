﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Security;
using TCC.Functions.Implementations.Auth;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Model;

namespace TCC.Functions.Functions.AdminFunctions
{
    public class AdminRemoveSocialMediaPlatform : AuthenticationBase
    {
        private readonly ILogger<AdminRemoveSocialMediaPlatform> _logger;
        private readonly IAdminService _socialMediaService;

        public AdminRemoveSocialMediaPlatform(IAdminService socialMediaService, ILogger<AdminRemoveSocialMediaPlatform> logger, IHttpService httpService,
            IAzureADService azureAdService, IAuthUserService authUserService)
        {
            _httpService = httpService;
            _azureAdService = azureAdService;
            _authUserService = authUserService;
            _socialMediaService = socialMediaService;
            _logger = logger;
        }

        [Function("RemoveSocialMediaPlatforms")]
        public async Task<HttpResponseData> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            try
            {
                await Roles(req, ["Admin"]);

                SocialMediaPlatform? socialMediaPlatformData = GetSocialMediaPlatform(req);


                if (socialMediaPlatformData == null || socialMediaPlatformData.Id == Guid.Empty || String.IsNullOrEmpty(socialMediaPlatformData.Name) || String.IsNullOrEmpty(socialMediaPlatformData.Icon))
                {
                    throw new Exception("Content not found");
                }
                await _socialMediaService.RemoveSocialMediaPlatform(socialMediaPlatformData);
                var response = req.CreateResponse(HttpStatusCode.OK);
                return response;
            }
            catch (SecurityException ex)
            {
                _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
                var response = req.CreateResponse(HttpStatusCode.Unauthorized);
                response.WriteString($"Unauthorized.");
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing social media platform in blob");
                var response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("Error");
                throw;
            }
        }

        [ExcludeFromCodeCoverage]
        private SocialMediaPlatform? GetSocialMediaPlatform(HttpRequestData req)
        {
            SocialMediaPlatform? socialMediaPlatforms = new SocialMediaPlatform();
            if (SystemStats.IsUnitTestRunning)
            {
                var requestBody = req.ReadAsStringAsync().Result;
                socialMediaPlatforms = System.Text.Json.JsonSerializer.Deserialize<SocialMediaPlatform>(requestBody!);
            }
            else
            {
                socialMediaPlatforms = req.ReadFromJsonAsync<SocialMediaPlatform>().Result;
            }

            return socialMediaPlatforms;
        }
    }
}