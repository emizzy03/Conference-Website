using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Interfaces;
using TCC.Functions;
using JsonException = System.Text.Json.JsonException;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Implementations.Auth;
using System.Security;

namespace TCC.Functions.Functions
{
    public class AdminPostConferenceInfo : AuthenticationBase
    {
        private readonly ILogger<AdminPostConferenceInfo> _logger;
        private readonly IAdminService _adminService;
        private readonly IPublicDataService _publicDataService;

        public AdminPostConferenceInfo(IAdminService adminService, ILogger<AdminPostConferenceInfo> logger, IPublicDataService publicDataService, IHttpService httpService,
            IAzureADService azureAdService, IAuthUserService authUserService)
        {
            _httpService = httpService;
            _azureAdService = azureAdService;
            _authUserService = authUserService;
            _adminService = adminService;
            _logger = logger;
            _publicDataService = publicDataService;
        }

        [Function("ConferenceInfo")]
        public async Task<HttpResponseData> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {

            _logger.LogInformation("ConferenceInfo function processed a request.");

            var response = req.CreateResponse(HttpStatusCode.OK);
            try
            {
                await Roles(req, ["Admin"]);

                response.Headers.Add("Content-Type", "text/plain; charset=utf-8");

                // Read the JSON data from the request body
                var conferenceInfoData = GetConferenceInfoDto(req);
                if (conferenceInfoData == null || conferenceInfoData.Id == Guid.Empty || string.IsNullOrEmpty(conferenceInfoData.Name) || string.IsNullOrEmpty(conferenceInfoData.Address1)
    || string.IsNullOrEmpty(conferenceInfoData.City) || string.IsNullOrEmpty(conferenceInfoData.State)
    || string.IsNullOrEmpty(conferenceInfoData.Zip) || string.IsNullOrEmpty(conferenceInfoData.Email) || string.IsNullOrEmpty(conferenceInfoData.Description)
    || string.IsNullOrEmpty(conferenceInfoData.Phone) || string.IsNullOrEmpty(conferenceInfoData.Image) || string.IsNullOrEmpty(conferenceInfoData.MissionStatement)
    || string.IsNullOrEmpty(conferenceInfoData.LocationHeader) || string.IsNullOrEmpty(conferenceInfoData.MiscInfo) || string.IsNullOrEmpty(conferenceInfoData.StaffDescription))
                {
                    ValidationException validationException = new ValidationException("Required fields are missing.");
                    throw validationException;
                }


                await _adminService.SaveConference(conferenceInfoData);
                _publicDataService.GetBlobItems();
                await _publicDataService.CreateConferenceInfo();
                response.WriteString("ConferenceInfo data has been processed.");

            }
            catch (SecurityException ex)
            {
                _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
                 response = req.CreateResponse(HttpStatusCode.Unauthorized);
                response.WriteString($"Unauthorized.");
                return response;
            }
            catch (JsonException jsonError)
            {
                _logger.LogError(jsonError, "Invalid Json Format");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("Invalid Json");

            }
            catch (ValidationException validationException)
            {
                _logger.LogError(validationException, "Validation error in ConferenceInfoUsData");
                response = req.CreateResponse(HttpStatusCode.NoContent);
                response.WriteString("Validation error in submitted data.");
            }


            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while processing the request.");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("An error occurred while processing the request.");
            }
            return response;

        }
        [ExcludeFromCodeCoverage]
        private ConferenceInfoDto? GetConferenceInfoDto(HttpRequestData req)
        {
            ConferenceInfoDto? conferenceInfoDto;
            if (SystemStats.IsUnitTestRunning)
            {
                var requestBody = req.ReadAsStringAsync().Result;
                conferenceInfoDto = System.Text.Json.JsonSerializer.Deserialize<ConferenceInfoDto>(requestBody!);
            }
            else
            {
                conferenceInfoDto = req.ReadFromJsonAsync<ConferenceInfoDto>().Result;
            }
            return conferenceInfoDto;
        }
    }
}

