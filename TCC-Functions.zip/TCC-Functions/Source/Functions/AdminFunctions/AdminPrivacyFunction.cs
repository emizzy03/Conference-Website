using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Security;
using System.Text;
using Azure;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

using Serilog.Core;
using TCC.Functions.Implementations.Auth;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Model;

namespace TCC.Functions.Functions
{
    public class AdminPrivacyFunction : AuthenticationBase
    {
        private readonly ILogger<AdminPrivacyFunction> _logger;
        private readonly IAdminService _privacyService;
        private readonly IPublicDataService _publicDataService;

        public AdminPrivacyFunction(IAdminService privacyService, ILogger<AdminPrivacyFunction> logger, IPublicDataService publicDataService, IHttpService httpService,
            IAzureADService azureAdService, IAuthUserService authUserService)
        {
            _httpService = httpService;
            _azureAdService = azureAdService;
            _authUserService = authUserService;
            _privacyService = privacyService;
            _logger = logger;
            _publicDataService = publicDataService;
        }

        [Function("Privacy")]
        public async Task<HttpResponseData> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            try
            {
                await Roles(req, ["Admin"]);

                var content = await req.ReadAsStringAsync();
                if (String.IsNullOrEmpty(content))
                {
                    throw new Exception("Content not found");
                }
                else
                {
                    await _privacyService.SavePrivacy(content);
                    _publicDataService.GetBlobItems();
                    await _publicDataService.CreateConferenceInfo();
                    var response = req.CreateResponse(HttpStatusCode.OK);
                    response.Body = new MemoryStream(Encoding.UTF8.GetBytes("Privacy content has been processed."));
                    return response;
                }
            }
            catch (SecurityException ex)
            {
                _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
                var response = req.CreateResponse(HttpStatusCode.Unauthorized);
                response.WriteString($"Unauthorized.");
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error writing privacy content to blob");
                var response = req.CreateResponse(HttpStatusCode.NotModified);
                response.Body = new MemoryStream(Encoding.UTF8.GetBytes("Error writing privacy content to blob"));
                return response;
            }
        }
    }
}