﻿﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Security;
using System.Text.Json;
using TCC.Functions.Implementations.Auth;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Model;

namespace TCC.Functions.Functions.AdminFunctions
{
    public class AdminSocialMediaPlatforms : AuthenticationBase
    {
        private readonly ILogger<AdminSocialMediaPlatforms> _logger;
        private readonly IAdminService _socialMediaService;

        public AdminSocialMediaPlatforms(IAdminService socialMediaService, ILogger<AdminSocialMediaPlatforms> logger, IHttpService httpService,
            IAzureADService azureAdService, IAuthUserService authUserService)
        {
            _httpService = httpService;
            _azureAdService = azureAdService;
            _authUserService = authUserService;
            _socialMediaService = socialMediaService;
            _logger = logger;
        }

        [Function("SocialMediaPlatforms")]
        public async Task<HttpResponseData> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            _logger.LogInformation("SocialMediaPlatforms function processes a request.");
            var response = req.CreateResponse(HttpStatusCode.OK);

            try
            {
                await Roles(req, ["Admin"]);

                response.Headers.Add("Content-Type", "text/plain; charset=utf-8");
                List<SocialMediaPlatform>? socialMediaPlatformData = GetSocialMediaPlatformList(req);

                if (socialMediaPlatformData == null)
                {
                    throw new ArgumentNullException("SocialMediaPlatforms is null");
                }

                foreach (var platform in socialMediaPlatformData)
                {
                    if (string.IsNullOrEmpty(platform.Icon) || string.IsNullOrEmpty(platform.Name))
                    {
                        throw new ValidationException("Required fields are missing");
                    }
                }

                await _socialMediaService.SaveSocialMediaPlatforms(socialMediaPlatformData);
            }
            catch (SecurityException ex)
            {
                _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
                 response = req.CreateResponse(HttpStatusCode.Unauthorized);
                response.WriteString($"Unauthorized.");
                return response;
            }
            catch (JsonException jsonError)
            {
                _logger.LogError(jsonError, "Invalid Json Format");
                response = req.CreateResponse(HttpStatusCode.UnprocessableContent);
                response.WriteString("Invalid Json");

            }

            catch (ValidationException ex)
            {
                _logger.LogError(ex, "Validation error in Social Media Data");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                await response.WriteStringAsync("Validation error in submitted data.");
            }

            catch (ArgumentNullException ex)
            {
                _logger.LogError(ex, "social media data is null");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("social media data is null");
            }

            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while processing the request.");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("An error occurred while processing the request.");
            }

            return response;
        }


        [ExcludeFromCodeCoverage]
        private static List<SocialMediaPlatform>? GetSocialMediaPlatformList(HttpRequestData req)
        {

            List<SocialMediaPlatform>? socialMediaPlatforms = new List<SocialMediaPlatform>();
            if (SystemStats.IsUnitTestRunning)
            {
                var requestBody = req.ReadAsStringAsync().Result;

                if (requestBody == null)
                {
                    return null;
                }
                socialMediaPlatforms = System.Text.Json.JsonSerializer.Deserialize<List<SocialMediaPlatform>>(requestBody!);
            }
            else
            {
                socialMediaPlatforms = req.ReadFromJsonAsync<List<SocialMediaPlatform>>().Result;
            }
            return socialMediaPlatforms;
        }

    }
}