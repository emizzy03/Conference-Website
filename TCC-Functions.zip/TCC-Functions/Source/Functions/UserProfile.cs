using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Security;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using TCC.Functions.Implementations.Auth;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;

namespace TCC.Functions.Functions;

[ExcludeFromCodeCoverage]
public class UserProfile:AuthenticationBase
{
    private readonly ILogger _logger;

    public UserProfile(ILoggerFactory loggerFactory, IHttpService httpService, IAzureADService azureAdService,
        IAuthUserService authUserService)
    {
        _httpService = httpService;
        _azureAdService = azureAdService;
        _authUserService = authUserService;
        _logger = loggerFactory.CreateLogger<UserProfile>();
    }

    [Function("UserProfile")]
    public async Task<HttpResponseData> Run([HttpTrigger(AuthorizationLevel.Function, "get", "post")] 
        HttpRequestData req, FunctionContext executionContext)
    {
        try
        {
            await Roles(req, ["User"]);
            var userRoles = await _authUserService.GetUserProfile(_adUser);

            var response = req.CreateResponse(HttpStatusCode.OK);
            response.Headers.Add("Content-Type", "application/json; charset=utf-8");

            response.WriteString(JsonConvert.SerializeObject(userRoles));

            return response;
        }
        catch (SecurityException ex)
        {
            _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
            var response = req.CreateResponse(HttpStatusCode.Unauthorized);
            response.WriteString($"Unauthorized.");
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating public data set at: {DateTime.Now}");
            throw;
        }
    }
}
