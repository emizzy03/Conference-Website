﻿using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using TCC.Functions.Interfaces;
using System.Net;
using System.Diagnostics.CodeAnalysis;
using TCC.Functions.Implementations.DTO;
using System.ComponentModel.DataAnnotations;
using TCC.Functions.Extensions;
using System.Text.Json;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Implementations.Services.Auth;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Implementations.Auth;
using System.Security;

namespace TCC.Functions.Functions.User
{
    public class PostUsers : AuthenticationBase
    {

        private readonly ILogger<PostUsers> _logger;
        private readonly IUserService _userService;

        public PostUsers(IUserService userService, ILogger<PostUsers> logger, IHttpService httpService,
            IAzureADService azureAdService, IAuthUserService authUserService)
        {
            _httpService = httpService;
            _azureAdService = azureAdService;
            _authUserService = authUserService;
            _logger = logger;
            _userService = userService;
        }

        [Function("UpdateUser")]
        public async Task<HttpResponseData> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {

            _logger.LogInformation("User function processes a request.");
            var response = req.CreateResponse(HttpStatusCode.OK);

            try
            {
                await Roles(req, ["User"]);

                response.Headers.Add("Content-Type", "text/plain; charset=utf-8");
                var userData = GetUserDTO(req);

                if (userData == null)
                {
                    ArgumentNullException validationException = new ArgumentNullException("User is null.");
                    throw validationException;
                }


                if (userData.Id == Guid.Empty && !string.IsNullOrEmpty(userData.FirstName) &&
                     !string.IsNullOrEmpty(userData.LastName) && !string.IsNullOrEmpty(userData.Email) &&
                     !string.IsNullOrEmpty(userData.Biography) ||
                    userData.Id != Guid.Empty && !string.IsNullOrEmpty(userData.FirstName) &&
                     !string.IsNullOrEmpty(userData.LastName) && !string.IsNullOrEmpty(userData.Email) &&
                     !string.IsNullOrEmpty(userData.Biography))
                {
                    response.WriteString("User data has been processed.");

                    try
                    {
                        Guid userId = userData.Id != Guid.Empty ? userData.Id : Guid.NewGuid();
                        var operationPerformed = userData.Id != Guid.Empty ? "saved" : "created";

                        // Save user data
                        await _userService.SaveUser(userData, userId, operationPerformed);

                        // Check if socialMediaDTOs is null - user don't want social media links or want to delete them
                        var socialMediaDTOs = userData.SocialMediaLinks;
                        if (socialMediaDTOs == null)
                        {
                            // Delete the social media data if it exists else returns false - needs social media path to delete it.
                            await _userService.DeleteUserSocialMedia($"users/{userId}/socialmedia/{userId}.json");
                        }
                        else
                        {
                            // Save user social media data
                            await _userService.SaveUserSocialMedia(socialMediaDTOs, userId, operationPerformed);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "An error occurred while processing the user data.");
                        throw;
                    }
                }
                else
                {
                    // Validation failed
                    ValidationException validationException = new ValidationException("Required fields are missing.");
                    throw validationException;
                }
            }
            catch (SecurityException ex)
            {
                _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
                response = req.CreateResponse(HttpStatusCode.Unauthorized);
                response.WriteString($"Unauthorized.");
                return response;
            }
            catch (JsonException jsonError)
            {
                _logger.LogError(jsonError, "Invalid Json Format");
                response = req.CreateResponse(HttpStatusCode.UnprocessableContent);
                response.WriteString("Invalid Json");

            }
            catch (ValidationException validationException)
            {
                _logger.LogError(validationException, "Validation error in UserData");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("Validation error in submitted data.");
            }
            catch (ArgumentNullException ex)
            {
                _logger.LogError(ex, "User is null");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("User is null");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while processing the request.");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("An error occurred while processing the request.");
            }
            return response;
        }

        [ExcludeFromCodeCoverage]
        private UserDTO? GetUserDTO(HttpRequestData req)
        {

            UserDTO? userDTO;
            if (SystemStats.IsUnitTestRunning)
            {
                var requestBody = req.ReadAsStringAsync().Result;

                if (requestBody == null)
                {
                    return null;
                }
                userDTO = JsonSerializer.Deserialize<UserDTO>(requestBody!);
            }
            else
            {
                userDTO = req.ReadFromJsonAsync<UserDTO>().Result;
            }
            return userDTO;
        }
    }
}
