﻿using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCC.Functions.Interfaces;
using System.Net;
using System.Diagnostics.CodeAnalysis;
using TCC.Functions.Implementations.DTO;
using System.Text.Json;
using System.ComponentModel.DataAnnotations;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Implementations.Services.Auth;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Implementations.Auth;
using System.Security;

namespace TCC.Functions.Functions.User
{
    public class PostSessions : AuthenticationBase
    {
        private readonly ILogger<PostSessions> _logger;
        private readonly IUserService _userService;

        public PostSessions(IUserService userService, ILogger<PostSessions> logger, IHttpService httpService,
            IAzureADService azureAdService, IAuthUserService authUserService)
        {
            _httpService = httpService;
            _azureAdService = azureAdService;
            _authUserService = authUserService;
            _logger = logger;
            _userService = userService;
        }

        [Function("UpdateUserSessions")]

        public async Task<HttpResponseData> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {

            _logger.LogInformation("Session function processes a request.");
            var response = req.CreateResponse(HttpStatusCode.OK);

            try
            {
                await Roles(req, ["User"]);

                response.Headers.Add("Content-Type", "text/plain; charset=utf-8");
                var sessionData = GetSessionDTO(req);

                if (sessionData == null)
                {
                    throw new ArgumentNullException("User Session is null.");
                }

                if (DataIsValid(sessionData))
                {
                    response.WriteString("Session data has been processed.");
                    Guid sessionId = sessionData.Id != Guid.Empty ? sessionData.Id : Guid.NewGuid();
                    var operationPerformed = sessionData.Id != Guid.Empty ? "UpdateUserSession" : "NewUserSession";

                    // Save Session data
                    await _userService.UpdateUserSessions(sessionData, sessionId, operationPerformed);
                }
                else
                {
                    // Validation failed
                    ValidationException validationException = new ValidationException("Required fields are missing.");
                    throw validationException;
                }
            }
            catch (SecurityException ex)
            {
                _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
                 response = req.CreateResponse(HttpStatusCode.Unauthorized);
                response.WriteString($"Unauthorized.");
                return response;
            }
            catch (JsonException jsonError)
            {
                _logger.LogError(jsonError, "Invalid Json Format");
                response = req.CreateResponse(HttpStatusCode.UnprocessableContent);
                response.WriteString("Invalid Json");

            }
            catch (ValidationException validationException)
            {
                _logger.LogError(validationException, "Validation error in SessionData");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("Validation error in submitted data.");
            }
            catch (ArgumentNullException ex)
            {
                _logger.LogError(ex, "session is null");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("session is null");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while processing the request.");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("An error occurred while processing the request.");
            }

            return response;
        }
        private static bool DataIsValid(SessionDto? sessionDto)
        {
            return (sessionDto.UserId != Guid.Empty
        && sessionDto.EventId != Guid.Empty
        && !string.IsNullOrEmpty(sessionDto.Title)
        && !string.IsNullOrEmpty(sessionDto.Description));
        }

        [ExcludeFromCodeCoverage]
        private SessionDto? GetSessionDTO(HttpRequestData req)
        {

            SessionDto? sessionDTO;
            if (SystemStats.IsUnitTestRunning)
            {
                var requestBody = req.ReadAsStringAsync().Result;

                if (requestBody == null)
                {
                    return null;
                }
                sessionDTO = JsonSerializer.Deserialize<SessionDto>(requestBody!);
            }
            else
            {
                sessionDTO = req.ReadFromJsonAsync<SessionDto>().Result;
            }
            return sessionDTO;
        }
    }
}