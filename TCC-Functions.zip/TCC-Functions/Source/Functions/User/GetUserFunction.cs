﻿using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net;
using TCC.Functions.Interfaces;
using TCC.Functions.Implementations.Auth;
using TCC.Functions.Interfaces.Auth;
using System.Security;

namespace TCC.Functions.Functions
{
    public class GetUserFunction : AuthenticationBase
    {
        private readonly ILogger<GetUserFunction> _logger;
        private readonly IUserService _userService;

        public GetUserFunction(IUserService userService, ILogger<GetUserFunction> logger, IHttpService httpService,
            IAzureADService azureAdService, IAuthUserService authUserService)
        {
            _httpService = httpService;
            _azureAdService = azureAdService;
            _authUserService = authUserService;
            _logger = logger;
            _userService = userService;
        }

        [Function("GetUser")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get")] HttpRequestData req, string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                _logger.LogInformation("No ID provided. Performing default action.");
                // Add your default action here
                return req.CreateResponse(HttpStatusCode.NoContent);
            }

            try
            {
                await Roles(req, ["User"]);

                _logger.LogInformation($"Received API Request to acquire User Info for ID: {id}");

                // Assuming you need to use the ID to retrieve user info
                var UserResult = await _userService.GetUserDTO(id);

                var response = req.CreateResponse(HttpStatusCode.OK);
                response.Headers.Add("Content-Type", "application/json; charset=utf-8");
                response.WriteString(JsonConvert.SerializeObject(UserResult));
                return response;
            }
            catch (SecurityException ex)
            {
                _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
                var response = req.CreateResponse(HttpStatusCode.Unauthorized);
                response.WriteString($"Unauthorized.");
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Users Exception");
                throw;
            }
        }
    }
}
