﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Security;
using TCC.Functions.Implementations.Auth;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;

namespace TCC.Functions.Functions.User
{
    public class RemoveSessionFunction : AuthenticationBase
    {
        private readonly ILogger<RemoveSessionFunction> _logger;
        private readonly IUserService _removeSessionService;

        public RemoveSessionFunction(IUserService removeSessionService, ILogger<RemoveSessionFunction> logger, IHttpService httpService,
            IAzureADService azureAdService, IAuthUserService authUserService)
        {
            _httpService = httpService;
            _azureAdService = azureAdService;
            _authUserService = authUserService;
            _removeSessionService = removeSessionService;
            _logger = logger;
        }

        [Function("RemoveUserSession")]
        public async Task<HttpResponseData> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            _logger.LogInformation("Remove User Session function received request.");
            var response = req.CreateResponse(HttpStatusCode.OK);

            try
            {
                await Roles(req, ["User"]);

                SessionDto? sessionData = GetSession(req);

                if (sessionData == null)
                {
                    throw new ArgumentNullException("User Session is null.");
                }
                else
                {
                    await _removeSessionService.RemoveSession(sessionData);
                }
            }
            catch (SecurityException ex)
            {
                _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
                 response = req.CreateResponse(HttpStatusCode.Unauthorized);
                response.WriteString($"Unauthorized.");
                return response;
            }
            catch (ArgumentNullException ex)
            {
                _logger.LogError(ex, "session is null");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("session is null");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while processing the request.");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("An error occurred while processing the request.");
            }
            return response;
        }

        [ExcludeFromCodeCoverage]
        private SessionDto? GetSession(HttpRequestData req)
        {

            SessionDto? sessions;
            if (SystemStats.IsUnitTestRunning)
            {
                var requestBody = req.ReadAsStringAsync().Result;

                if (requestBody == null)
                {
                    return null;
                }
                sessions = System.Text.Json.JsonSerializer.Deserialize<SessionDto>(requestBody!);
            }
            else
            {
                sessions = req.ReadFromJsonAsync<SessionDto>().Result;
            }
            return sessions;
        }

    }
}