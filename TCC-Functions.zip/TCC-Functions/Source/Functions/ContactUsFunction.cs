using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using TCC.Functions.Extensions;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Interfaces;
using JsonException = System.Text.Json.JsonException;

namespace TCC.Functions.Functions
{
    public class ContactUsFunction
    {
        private readonly ILogger<ContactUsFunction> _logger;
        private readonly IContactUsService _contactUsService;

        public ContactUsFunction(IContactUsService contactUsService, ILogger<ContactUsFunction> logger)
        {
            _contactUsService = contactUsService;
            _logger = logger;
        }

        [Function("ContactUs")]
        public async Task<HttpResponseData?> RunAsync(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            _logger.LogInformation("ContactUs function processed a request.");

            try
            {
                var contactUsData = await GetContactUsDto(req);
                if (contactUsData == null || !DataIsValid(contactUsData))
                {
                    throw new ValidationException("Required fields are missing.");
                }

                await _contactUsService.ProcessContactUsData(contactUsData);
                return await req.CreateOkJsonResponse("Contact us data has been processed.");
            }
            catch (JsonException jsonError)
            {
                return await req.CreateBadRequestJsonResponse("Invalid Json", _logger, jsonError);
            }
            catch (ValidationException validationException)
            {
                return await req.CreateBadRequestJsonResponse(
                    "Validation error in submitted data.",
                    _logger,
                    validationException);
            }
            catch (Exception ex)
            {
                return await req.CreateBadRequestJsonResponse(
                    "An error occurred while processing the request.",
                    _logger,
                    ex);
            }
        }

        private static bool DataIsValid(ContactUsDto? contactUsDto) =>
            !string.IsNullOrEmpty(contactUsDto?.Name) &&
            !string.IsNullOrEmpty(contactUsDto.Organization) &&
            !string.IsNullOrEmpty(contactUsDto.EmailAddress) &&
            !string.IsNullOrEmpty(contactUsDto.Message);

        [ExcludeFromCodeCoverage]
        private async Task<ContactUsDto?> GetContactUsDto(HttpRequestData req)
        {
            ContactUsDto? contactUsDto;
            if (SystemStats.IsUnitTestRunning)
            {
                var requestBody = await req.ReadAsStringAsync();
                contactUsDto = requestBody?.FromJson<ContactUsDto>();
            }
            else
            {
                contactUsDto = req.ReadFromJsonAsync<ContactUsDto>().Result;
            }

            return contactUsDto;
        }
    }
}