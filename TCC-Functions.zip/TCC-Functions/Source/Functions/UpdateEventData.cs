using System.Diagnostics.CodeAnalysis;
using System.Net;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using TCC.Functions.Extensions;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Interfaces;

namespace TCC.Functions.Functions;

public class UpdateEventData(IPublicDataService publicDataService, ILogger<UpdateEventData> logger)
{
    private readonly ILogger _logger = logger;

    [Function("UpdateEventData")]
    public async Task<HttpResponseData?> RunAsync(
        [HttpTrigger(AuthorizationLevel.Function, "post")]
        HttpRequestData req,
        FunctionContext executionContext)
    {
        _logger.LogInformation("Received a request to update event data.");
        try
        {
            var updateEventDto = await GetUpdateEventDto(req);
            publicDataService.GetBlobItems();
            await publicDataService.CreateEventById(updateEventDto!.Id);
            return await req.CreateOkJsonResponse("Event data updated successfully.", _logger);
        }
        catch (System.Text.Json.JsonException jsonException)
        {
            return await req.CreateBadRequestJsonResponse("Invalid Event Data", _logger, jsonException);
        }
        catch (Exception ex)
        {
            return await req.CreateJsonResponse(
                HttpStatusCode.NotModified,
                "There were issues updating the event data.",
                _logger,
                ex
            );
        }
    }

    [ExcludeFromCodeCoverage]
    private async Task<UpdateEventDto?> GetUpdateEventDto(HttpRequestData req)
    {
        try
        {
            UpdateEventDto? updateEventDto;
            if (SystemStats.IsUnitTestRunning)
            {
                var requestBody = await req.ReadAsStringAsync();
                updateEventDto = System.Text.Json.JsonSerializer.Deserialize<UpdateEventDto>(requestBody!);
            }
            else
            {
                updateEventDto = await req.ReadFromJsonAsync<UpdateEventDto>();
            }

            return updateEventDto;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deserializing event data.");
            throw;
        }
    }
}