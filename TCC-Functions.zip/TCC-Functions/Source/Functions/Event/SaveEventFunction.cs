﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Text.Json;
using TCC.Functions.Extensions;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Implementations.Services.Auth;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Model;
using TCC.Functions.Implementations.Auth;
using System.Security;

namespace TCC.Functions.Functions.Event
{
    public class SaveEventFunction : AuthenticationBase
    {

        private readonly ILogger<SaveEventFunction> _logger;
        private readonly IEventService _eventService;

        public SaveEventFunction(IEventService eventService, ILogger<SaveEventFunction> logger, IHttpService httpService,
            IAzureADService azureAdService, IAuthUserService authUserService)
        {
            _httpService = httpService;
            _azureAdService = azureAdService;
            _authUserService = authUserService;
            _eventService = eventService;
            _logger = logger;
        }

        [Function("SaveEvent")]
        public async Task<HttpResponseData> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {

            _logger.LogInformation("Event function processes a request.");
            var response = req.CreateResponse(HttpStatusCode.OK);

            try
            {
                await Roles(req, ["Admin"]);

                response.Headers.Add("Content-Type", "text/plain; charset=utf-8");
                var eventData = GetEventDTO(req);

                if (eventData == null)
                {
                    ArgumentNullException validationException = new ArgumentNullException("Event is null.");
                    throw validationException;
                }

                if (DataIsValid(eventData))
                {
                    response.WriteString("Event data has been processed.");
                    Guid eventId = eventData.Id != Guid.Empty ? eventData.Id : Guid.NewGuid();
                    var operationPerformed = eventData.Id != Guid.Empty ? "saved" : "created";

                    // Save Event data
                    await _eventService.SaveEvent(eventData, eventId, operationPerformed);
                }
                else
                {
                    ValidationException validationException = new ValidationException("Required fields are missing.");
                    throw validationException;
                }
            }
            catch (SecurityException ex)
            {
                _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
                 response = req.CreateResponse(HttpStatusCode.Unauthorized);
                response.WriteString($"Unauthorized.");
                return response;
            }
            catch (JsonException jsonError)
            {
                _logger.LogError(jsonError, "Invalid Json Format");
                response = req.CreateResponse(HttpStatusCode.UnprocessableContent);
                response.WriteString("Invalid Json");

            }
            catch (ValidationException validationException)
            {
                _logger.LogError(validationException, "Validation error in EventData");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("Validation error in submitted data.");
            }
            catch (ArgumentNullException ex)
            {
                _logger.LogError(ex, "event is null");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("event is null");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while processing the request.");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("An error occurred while processing the request.");
            }
            return response;
        }

        private static bool DataIsValid(EventDto? eventDto)
        {
            return (eventDto.Id == Guid.Empty && !string.IsNullOrEmpty(eventDto.Name) && !string.IsNullOrEmpty(eventDto.Address1) && (eventDto.Status >= EventStatus.NotStarted && eventDto.Status <= EventStatus.Ended) &&
                    (eventDto.Status >= EventStatus.NotStarted && eventDto.Status <= EventStatus.Ended) &&
                    !string.IsNullOrEmpty(eventDto.City) &&
                    !string.IsNullOrEmpty(eventDto.State) &&
                    !string.IsNullOrEmpty(eventDto.Zip) &&
                    !string.IsNullOrEmpty(eventDto.LocationDescription) &&
                    eventDto.EndDate != DateTime.MinValue && eventDto.StartDate != DateTime.MinValue)
                    ||
                    (eventDto.Id != Guid.Empty && !string.IsNullOrEmpty(eventDto.Name) && !string.IsNullOrEmpty(eventDto.Address1) && (eventDto.Status >= EventStatus.NotStarted && eventDto.Status <= EventStatus.Ended) &&
                    (eventDto.Status >= EventStatus.NotStarted && eventDto.Status <= EventStatus.Ended) &&
                    !string.IsNullOrEmpty(eventDto.City) &&
                    !string.IsNullOrEmpty(eventDto.State) &&
                    !string.IsNullOrEmpty(eventDto.Zip) &&
                    !string.IsNullOrEmpty(eventDto.LocationDescription) &&
                    eventDto.EndDate != DateTime.MinValue &&
                    eventDto.StartDate != DateTime.MinValue);
        }

        [ExcludeFromCodeCoverage]
        private EventDto? GetEventDTO(HttpRequestData req)
        {

            EventDto? eventDto;
            if (SystemStats.IsUnitTestRunning)
            {
                var requestBody = req.ReadAsStringAsync().Result;

                if (requestBody == null)
                {
                    return null;
                }
                eventDto = JsonSerializer.Deserialize<EventDto>(requestBody!);
            }
            else
            {
                eventDto = req.ReadFromJsonAsync<EventDto>().Result;
            }
            return eventDto;
        }
    }
}