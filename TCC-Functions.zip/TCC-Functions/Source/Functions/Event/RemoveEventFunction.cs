﻿using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Implementations.Auth;
using System.Security;

namespace TCC.Functions.Functions.AdminFunctions
{
    public class RemoveEventFunction : AuthenticationBase
    {
        private readonly ILogger<RemoveEventFunction> _logger;
        private readonly IAdminService _removeEventService;

        public RemoveEventFunction(IAdminService removeEventService, ILogger<RemoveEventFunction> logger, IHttpService httpService,
            IAzureADService azureAdService, IAuthUserService authUserService)
        {
            _httpService = httpService;
            _azureAdService = azureAdService;
            _authUserService = authUserService;
            _removeEventService = removeEventService;
            _logger = logger;
        }

        [Function("RemoveEvent")]
        public async Task<HttpResponseData> RunAsync([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            _logger.LogInformation("Remove Event function received request.");
            var response = req.CreateResponse(HttpStatusCode.OK);

            try
            {
                await Roles(req, ["Admin"]);

                EventDto? eventData = GetEvent(req);

                if (eventData == null)
                {
                    ArgumentNullException validationException = new ArgumentNullException("Event data is null.");
                    throw validationException;
                }
                else
                {
                    await _removeEventService.RemoveEvent(eventData);
                }
            }
            catch (SecurityException ex)
            {
                _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
                 response = req.CreateResponse(HttpStatusCode.Unauthorized);
                response.WriteString($"Unauthorized.");
                return response;
            }
            catch (ArgumentNullException ex)
            {
                _logger.LogError(ex, "event is null");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("event is null");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while processing the request.");
                response = req.CreateResponse(HttpStatusCode.BadRequest);
                response.WriteString("An error occurred while processing the request.");
            }
            return response;
        }

        [ExcludeFromCodeCoverage]
        private EventDto? GetEvent(HttpRequestData req)
        {

            EventDto? events = new EventDto();
            if (SystemStats.IsUnitTestRunning)
            {
                var requestBody = req.ReadAsStringAsync().Result;

                if (requestBody == null)
                {
                    return null;
                }
                events = System.Text.Json.JsonSerializer.Deserialize<EventDto>(requestBody!);
            }
            else
            {
                events = req.ReadFromJsonAsync<EventDto>().Result;
            }
            return events;
        }

    }
}