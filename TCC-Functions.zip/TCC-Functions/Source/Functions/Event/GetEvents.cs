﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net;
using System.Security;
using TCC.Functions.Implementations.Auth;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;

namespace TCC.Functions.Functions.Event
{
    public class GetEvents : AuthenticationBase
    {
        private readonly ILogger<UpdateAllPublicDataSet> _logger;
        private readonly IPublicDataService _publicDataService;

        public GetEvents(IPublicDataService publicDataService, ILogger<UpdateAllPublicDataSet> logger, IHttpService httpService,
            IAzureADService azureAdService, IAuthUserService authUserService)
        {
            _httpService = httpService;
            _azureAdService = azureAdService;
            _authUserService = authUserService;
            _logger = logger;
            _publicDataService = publicDataService;
        }

        [Function("GetEvents")]
        public async Task<HttpResponseData> Run([HttpTrigger(AuthorizationLevel.Function, "get")] HttpRequestData req)
        {
            try
            {
                await Roles(req, ["Admin"]);

                _logger.LogInformation("Received API Request to acquire Event Info");

                _publicDataService.GetBlobItems();
                var EventsResult = await _publicDataService.GetEvents();

                var response = req.CreateResponse(HttpStatusCode.OK);
                response.Headers.Add("Content-Type", "text/plain; charset=utf-8");
                response.WriteString(JsonConvert.SerializeObject(EventsResult));
                return response;
            }
            catch (SecurityException ex)
            {
                _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
                var response = req.CreateResponse(HttpStatusCode.Unauthorized);
                response.WriteString($"Unauthorized.");
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "EventsResult Exception");
                throw;
            }
        }
    }
}