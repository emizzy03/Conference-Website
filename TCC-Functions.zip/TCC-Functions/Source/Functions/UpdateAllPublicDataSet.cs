using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using TCC.Functions.Extensions;
using TCC.Functions.Interfaces;

namespace TCC.Functions.Functions;
[ExcludeFromCodeCoverage]
public class UpdateAllPublicDataSet
{
    private readonly ILogger<UpdateAllPublicDataSet> _logger;

    private readonly IPublicDataService _publicDataService;
    public UpdateAllPublicDataSet(IPublicDataService publicDataService,ILogger<UpdateAllPublicDataSet> logger)
    {
        _logger = logger;
        _publicDataService = publicDataService;
    }

    [Function("UpdateAllPublicDataSet")]
    public async Task Run([TimerTrigger("0 0 0 * * 0")] TimerInfo myTimer)
    {
        _logger.LogInformation($"Weekly Public Data Set Update initiated on: {DateTime.Now}");
        try
        {
            if (myTimer.ScheduleStatus is not null)
            {
                _logger.LogInformation($"Getting items in the blob container: public");
                _publicDataService.GetBlobItems();
                _logger.LogInformation($"Creating Conference Info");
                await _publicDataService.CreateConferenceInfo();
                _logger.LogInformation($"Creating Events");
                await _publicDataService.CreateEvents();
                _logger.LogInformation($"Creating Speakers List");
                await _publicDataService.CreateSpeakersList();
                _logger.LogInformation($"Weekly Public Data Set Update completed on: {DateTime.Now}");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error updating public data set at: {DateTime.Now}");
            throw;
        }
    }
}