using System.Diagnostics.CodeAnalysis;
using System.Reflection;

namespace TCC.Functions;

[ExcludeFromCodeCoverage]
public static class SystemStats
{
    public static bool IsUnitTestRunning
    {
        get
        {
            string testAssemblyName = "nunit.framework";
            return AppDomain.CurrentDomain.GetAssemblies()
                .Any(a => a.FullName.StartsWith(testAssemblyName));
        }
    }
}