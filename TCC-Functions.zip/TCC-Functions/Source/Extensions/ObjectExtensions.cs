﻿using System.Text.Json;

namespace TCC.Functions.Extensions;

public static class ObjectExtensions
{
    private static JsonSerializerOptions CamelCaseJsonSerializerOptions => new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
    };

    public static string ToJson(
        this object obj,
        JsonSerializerOptions? serializerOptions = null) =>
        JsonSerializer.Serialize(obj, serializerOptions ?? CamelCaseJsonSerializerOptions);

    public static T? FromJson<T>(this string json, JsonSerializerOptions? serializerOptions = null) =>
        string.IsNullOrEmpty(json)
            ? default
            : JsonSerializer.Deserialize<T>(json, serializerOptions ?? CamelCaseJsonSerializerOptions);
}