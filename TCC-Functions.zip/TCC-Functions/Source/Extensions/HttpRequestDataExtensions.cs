﻿using System.Net;
using System.Net.Mime;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using TCC.Functions.Implementations.DTO;

namespace TCC.Functions.Extensions;

public static class HttpRequestDataExtensions
{
    public static async Task<HttpResponseData?> CreateResponse<T>(
        this HttpRequestData req,
        HttpStatusCode statusCode,
        string contentType,
        T? body = default,
        ILogger? logger = null,
        Exception? e = null)
    {
        var response = req.CreateResponse(statusCode);
        response.Headers.Add("Content-Type", contentType);
        var responseObject = new BaseResponse
        {
            Message = body?.ToString() ?? string.Empty
        };
        await response.WriteStringAsync(responseObject.ToJson());
        if (statusCode == HttpStatusCode.OK)
        {
            logger?.LogInformation(responseObject.Message);
        }
        else
        {
            logger?.LogError(responseObject.Message, e);
        }

        return response;
    }

    public static async Task<HttpResponseData?> CreateOkJsonResponse(this HttpRequestData req,
        string? body = null, ILogger? logger = null) =>
        await req.CreateJsonResponse(HttpStatusCode.OK, body, logger);

    public static async Task<HttpResponseData?> CreateBadRequestJsonResponse(this HttpRequestData req,
        string? body = null, ILogger? logger = null, Exception? e = null) =>
        await req.CreateJsonResponse(HttpStatusCode.BadRequest, body, logger, e);

    public static async Task<HttpResponseData?> CreateJsonResponse<T>(this HttpRequestData req,
        HttpStatusCode statusCode, T? body = default, ILogger? logger = null, Exception? e = null) =>
        await req.CreateResponse(statusCode, MediaTypeNames.Application.Json, body, logger, e);

    public static async Task<HttpResponseData?> CreateJsonResponse(this HttpRequestData req,
        HttpStatusCode statusCode, string? body = null, ILogger? logger = null) =>
        await req.CreateResponse(statusCode, MediaTypeNames.Application.Json, body, logger);
}