﻿using TCC.Functions.Implementations.DTO;
using TCC.Functions.Model;

namespace TCC.Functions.Interfaces;

public interface IUserService
{
    Task<User> GetUser(string userId);
    Task SaveUser(UserDTO userDTO, Guid userId, string operationPerformed);
    Task SaveUserSocialMedia(IEnumerable<UserSocialMediaDTO> socialMediaDTOs, Guid userId, string operationPerformed);
    Task DeleteUserSocialMedia(string socialMediaPath);
    Task<List<UserSocialMedia>> GetUserSocialMedia(string userId);
    Task<UserDTO> GetUserDTO(string userId);
    Task<List<UserSessionDto>> GetUserSessions(List<string> sessions, Guid userId);
    Task UpdateUserSessions(SessionDto sessionDto, Guid sessionsId, string operationPerformed);

    Task RemoveSession(SessionDto sessionToRemove);
}
