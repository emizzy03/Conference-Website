
namespace TCC.Functions.Interfaces;

public interface IStorageService
{
    Task<byte[]> GetBlobContent(string container, string path);
    Task WriteBlobContent(string container, string path, string data);
    Task WriteObjectToBlobContent(string container, string path, object data);
    Task DeleteFileByPath(string container, string path);
    Task<string> GetDataFromStorage(string container, string path);
    List<string> GetBlobs(string container);
    Task<bool> BlobExists(string container, string path);
    Task DeleteFolderByPath(string containerName, string folderPath);
}