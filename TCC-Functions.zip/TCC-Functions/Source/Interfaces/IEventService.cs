﻿using TCC.Functions.Implementations.DTO;

namespace TCC.Functions.Interfaces
{
    public interface IEventService
    {
        Task SaveEvent(EventDto eventDto, Guid eventId, string operationPerformed);
    }
}

