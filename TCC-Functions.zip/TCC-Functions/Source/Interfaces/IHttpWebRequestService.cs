﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Threading.Tasks;
using TCC.Functions.Model;
using TCC.Functions.Implementations.DTO;

namespace TCC.Functions.Interfaces
{
    public interface IHttpWebRequestService
    {
        WebRequestResponse GetURLResponse(string url);

    }
}
