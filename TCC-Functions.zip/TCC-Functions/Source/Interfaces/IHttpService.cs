using Newtonsoft.Json.Linq;

namespace TCC.Functions.Interfaces;

public interface IHttpService
{
    Task<HttpResponseMessage> PostJsonRequest(Uri uri, JToken request);

    Task<JObject?> GetJsonRequest(string uriString);
    Task<JObject?> DeleteJsonRequest(string uriString);
    Task<JObject?> PostFormRequest(string uriString, MultipartFormDataContent form);
    Task<JObject?> PostStringContentRequest(string uriString, StringContent content);
    Task<JObject?> PostStringContentRequest(string uriString, StringContent content, string contentType);
    void SetBaseAddress(Uri baseAddress);
    void SetDefaultHeaders(Dictionary<string, string> httpHeader);
    void SetMediaType(string mediaType);
}