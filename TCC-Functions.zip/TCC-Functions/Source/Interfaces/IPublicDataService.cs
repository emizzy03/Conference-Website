using Azure.Storage.Blobs.Models;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Model;

namespace TCC.Functions.Interfaces;

public interface IPublicDataService
{
    void GetBlobItems();
    Task<string> GetPrivacy();
    Task<string> GetCodeOfConduct();
    Task<List<SessionDto>> GetSessionsByEventId(List<string> sessionFileNames, Guid eventId);
    Task<List<Staff>> GetStaffByEventId(List<string> staffFileNames, Guid eventId);
    Task CreateSpeakersList();
    Task CreateConferenceInfo();
    Task<ConferenceInfoDto> GetConferenceInfo();
    Task CreateEvents();
    Task CreateEventById(Guid eventId);
    Task<List<EventDto>> GetEvents(bool includeSessions = false);
    Task<List<string>> GetSessionFileNames();
    Task<List<SocialMediaPlatform>> GetSocialMediaPlatforms();
}