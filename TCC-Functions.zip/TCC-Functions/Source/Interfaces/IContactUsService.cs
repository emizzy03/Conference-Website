﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCC.Functions.Implementations.DTO;

namespace TCC.Functions.Interfaces
{
    public interface IContactUsService
    {
        /// <summary>
        /// Processes the contact us data.
        /// </summary>
        /// <param name="message">The contact us data transfer object.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        Task ProcessContactUsData(ContactUsDto message);
    }
}
