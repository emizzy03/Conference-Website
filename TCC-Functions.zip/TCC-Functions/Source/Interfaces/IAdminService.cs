﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Model;

namespace TCC.Functions.Interfaces
{
    public interface IAdminService
    {
        Task SaveCodeOfConduct(string content);
        Task SavePrivacy(string content);
        Task SaveConference(ConferenceInfoDto conference);
        Task RemoveEvent(EventDto eventToRemove);
        Task SaveSocialMediaPlatforms(List<SocialMediaPlatform> socialMediaPlatforms);
        Task RemoveSocialMediaPlatform(SocialMediaPlatform socialMediaPlatform);

    }
}
