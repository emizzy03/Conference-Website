using TCC.Functions.Implementations.DTO.Auth;
using TCC.Functions.Model;
using TCC.Functions.Model.Auth;

namespace TCC.Functions.Interfaces.Auth;

public interface IAuthUserService
{
    Task<bool> IsUserInRole(Guid userId, string[] roles);
    Task<string> GetUserById(Guid userId);
    Task<List<UserRoles>> GetUserRoles();
    List<Roles> GetUserRolesByUserId(Guid userId);
    Task<bool> CheckIfUserIsInRole(Guid userId, string[] roles);
    Task<AuthUserDto>GetUserProfile(ADUser user);
    Task AddNewUserToRoles(Guid userId);
}