using Newtonsoft.Json.Linq;

namespace TCC.Functions.Interfaces.Auth;

public interface IAzureADService
{
    Task<JObject> GetAuthTokenFromMicrosoftAsync();
}