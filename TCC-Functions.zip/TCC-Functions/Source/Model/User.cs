﻿

using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Model
{
    [ExcludeFromCodeCoverage]
    public class User
    {
        public Guid Id;
        public required string FirstName { get; set; }
        public required string LastName { get; set; }
        public required string Email { get; set; }
        public string Biography { get; set; } = null!;
        public string PictureLink{ get; set;} = null!;
        public List<Guid> PresentationSessions { get; set; } = null!;
    }
}
