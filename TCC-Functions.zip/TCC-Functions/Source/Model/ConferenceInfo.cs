﻿using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Model
{
    [ExcludeFromCodeCoverage]
    public class ConferenceInfo
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = null!;
        public string Address1 { get; set; } = null!;
        public string Address2 { get; set; } = null!;
        public string City { get; set; } = null!;
        public string State { get; set; } = null!;
        public string Zip { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string Description { get; set; } = null!;
        public string Phone { get; set; } = null!;
        public string Image { get; set; } = null!;
        public string MissionStatement { get; set; } = null!;
        public string LocationHeader { get; set; } = null!;
        public string MiscInfo { get; set; } = null!;
        public string StaffDescription { get; set; } = null!;
    }
}
