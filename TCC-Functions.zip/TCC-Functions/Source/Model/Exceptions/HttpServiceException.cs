using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Model.Exceptions;

[ExcludeFromCodeCoverage]
public class HttpServiceException : TCCBaseException
{
    public HttpServiceException(object jsonObj) : base(jsonObj)
    {
    }

    public HttpServiceException(Exception innerException, object jsonObj) : base(innerException, jsonObj)
    {
    }
}