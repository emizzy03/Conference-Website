using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Model.Exceptions;

[ExcludeFromCodeCoverage]
public class ItemNotFoundException : HttpServiceException
{
    public ItemNotFoundException(object obj) : base(obj)
    {
    }
}