using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace TCC.Functions.Model.Exceptions;

[ExcludeFromCodeCoverage]
public class TCCBaseException: Exception
{
    public TCCBaseException(object jsonObj) : base(JsonConvert.SerializeObject(jsonObj))
    {
    }

    public TCCBaseException(Exception innerException, object jsonObj) : base(JsonConvert.SerializeObject(jsonObj),
        innerException)
    {
    }
}