﻿
using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Model
{
    [ExcludeFromCodeCoverage]
    public class UserSocialMedia
    {
        public Guid Id { get; set; }

        public Guid SocialMediaPlatformId { get; set; }

        public string Link { get; set; } = null!;

        public Guid UserId { get; set; }    
    }
}
