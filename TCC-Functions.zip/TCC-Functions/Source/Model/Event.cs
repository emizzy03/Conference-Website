﻿
using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Model
{
    [ExcludeFromCodeCoverage]
    public class Event
    {
        public Guid Id { get; set; }

        public string Name { get; set; }

        public DateTime StartDate { get; set; } 

        public DateTime EndDate { get; set; } 

        public EventStatus Status { get; set; }

        public string Address1 { get; set; } = null!;

        public string Address2 { get; set; } = null!;

        public string City { get; set; } = null!;

        public string State { get; set; } = null!;

        public string Zip { get; set; } = null!;

        public string LocationDescription { get; set; } = null!;

        public bool KeynoteSelected { get; set; }

        public bool SessionsSelected { get; set;}

        public bool CallForSpeakerOpen { get; set; }

        public bool IsWorkshopSessionAllowed { get; set; }

        public int Year { get; set;}
    }
}
