namespace TCC.Functions.Model;

public enum EventStatus
{
    NotStarted = 1,
    Active = 2,
    Ended = 3
}