﻿

using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Model
{
    [ExcludeFromCodeCoverage]
    public class SocialMediaPlatform
    {
        public Guid Id { get; set; }

        public string Name { get; set; } = null!;

        public string Icon {  get; set; } = null!;
    }
}
