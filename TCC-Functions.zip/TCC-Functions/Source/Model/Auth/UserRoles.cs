using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Model.Auth;

[ExcludeFromCodeCoverage]
public class UserRoles
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public List<Roles> UserRolesList { get; set; } = null!;
}