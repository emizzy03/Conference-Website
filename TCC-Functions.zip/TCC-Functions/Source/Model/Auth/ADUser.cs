using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace TCC.Functions.Model.Auth;

[ExcludeFromCodeCoverage]
public class ADUser
{
    [JsonProperty("@odata.context")]
    public string odatacontext { get; set; } = string.Empty;
    [JsonProperty("businessPhones")]
    public List<string> BusinessPhones { get; set; } = null!;
    [JsonProperty("displayName")]
    public string DisplayName { get; set; } = null!;
    [JsonProperty("givenName")]
    public string GivenName { get; set; } = null!;

    [JsonProperty("jobTitle")]
    public string JobTitle { get; set; } = null!;

    [JsonProperty("mail")]
    public string Mail { get; set; } = null!;

    [JsonProperty("mobilePhone")]
    public string MobilePhone { get; set; } = null!;

    [JsonProperty("officeLocation")]
    public string OfficeLocation { get; set; } = null!;

    [JsonProperty("preferredLanguage")]
    public string PreferredLanguage { get; set; } = null!;

    [JsonProperty("surname")]
    public string Surname { get; set; } = null!;

    [JsonProperty("userPrincipalName")]
    public string UserPrincipalName { get; set; } = null!;

    [JsonProperty("id")]
    public Guid Id { get; set; }
}
