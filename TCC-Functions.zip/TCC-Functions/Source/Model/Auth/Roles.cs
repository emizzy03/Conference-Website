using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace TCC.Functions.Model.Auth;

[Flags]
[JsonConverter(typeof(StringEnumConverter))]
public enum Roles
{
    Admin,
    User,
    Staff,
    Sponsor,
    Volunteer
}