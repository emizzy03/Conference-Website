﻿

using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Model
{
    [ExcludeFromCodeCoverage]
    public class ContactUs
    {
        public Guid Id { get; set; } 
        public string? Name { get; set; }
        public string? EmailAddress { get; set; }
        public string? Organization { get; set; }
        public string? Role { get; set; }
        public string? Message { get; set; }
        
    }
}
