﻿

using System.Diagnostics.CodeAnalysis;

namespace TCC.Functions.Model
{
    [ExcludeFromCodeCoverage]
    public class Staff
    {
        public Guid Id { get; set;}
        public Guid UserId { get; set;}

        public Guid EventId { get; set; }

        public string Position { get; set; } = null!;
    }
}
