﻿using System.Net;

namespace TCC.Functions.Model
{
    public class WebRequestResponse
    { 
        public HttpStatusCode StatusCode { get; set; } //

    }
}
