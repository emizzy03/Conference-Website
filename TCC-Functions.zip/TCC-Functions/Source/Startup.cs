﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Serilog.Extensions.Logging;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Interfaces;

[assembly: FunctionsStartup(typeof(TCC.Functions.Startup))]
namespace TCC.Functions
{
    [ExcludeFromCodeCoverage]
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            builder.Services.AddSingleton<ILoggerFactory>(sc =>
            {
                var providerCollection = sc.GetService<LoggerProviderCollection>();
                var factory = new SerilogLoggerFactory(null, true, providerCollection);
                foreach (var provider in sc.GetServices<ILoggerProvider>())
                    factory.AddProvider(provider);
                return factory;
            });
            builder.Services.AddSingleton<IStorageService, StorageService>();
        }
    }
}