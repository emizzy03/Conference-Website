﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TCC.Functions.Implementations.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace TCC.Functions.Implementations.Services.Tests
{
    [TestClass]
    public class ContactUsServiceTests
    {
        [TestMethod(Services)]
        public void ContactUsDataTest()
        {
            // Arrange
            var storageServiceMock = new Mock<IStorageService>();
            var contactUsService = new ContactUsService(storageServiceMock.Object);

            var message = new ContactUsDTO
            {
                Name = "John Smith",
                Organization = "Dominican University",
                Role = "Staff",
                EmailAddress = "john.smith@my.dom.edu",
                Message = "Test message",
            };

            // Act
              await contactUsService.ContactUsData(message);
            storageServiceMock.Verify(
              x => x.WriteBlobContent("public", It.IsAny<string>(), It.IsAny<string>()),
            Times.Exactly((0));

           /* // Serialize the ContactUsDTO object to JSON
            var expectedJson = JsonSerializer.Serialize(contactUsDto);

            // Instantiate the ContactUsService with the mock storage service
            var contactUsService = new ContactUsService(storageService);

            // Act
            // Call the ContactUsData method to save the data
            contactUsService.ContactUsData(contactUsDto);

            // Retrieve the JSON data from the storage service
            var actualJson = storageService.ReadData("messages.json");

            // Deserialize the actual JSON data back to a ContactUsDTO object
            var actualContactUsDto = JsonSerializer.Deserialize<ContactUsDTO>(actualJson);

            // Assert
            // Check if the serialized JSON matches the expected JSON
            Assert.Equal(expectedJson, actualJson);

            // Check if the deserialized ContactUsDTO matches the original object
            Assert.Equal(contactUsDto, actualContactUsDto);
           */
        }
    }
}
    }
}