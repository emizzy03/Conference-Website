﻿using Microsoft.Extensions.Logging;
using Moq;
using System.Text;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Interfaces;
using TCC.Functions.Model;


namespace TCC.Functions.Tests.Implementations.Services
{
    public class EventServiceTests
    {
        private Mock<ILogger<EventService>> _logger = null!;
        private Mock<IStorageService> _storageService = null!;
        private Mock<IPublicDataService> _publicDataService;
        private EventService _sut = null!;
        [SetUp]
        public void SetUp()
        {
            _logger = new Mock<ILogger<EventService>>();
            _storageService = new Mock<IStorageService>();
            _publicDataService = new Mock<IPublicDataService>();
            _sut = new EventService(_logger.Object, _storageService.Object);
        }

        [Test]
        public async Task SaveEvent_WithValidContent_CallWriteObjectToBlobContent()
        {

            var eventDto = new EventDto
            {
                Id = Guid.NewGuid(),
                Name = "Event Name",
                Address1 = "123 Main St",
                City = "CityName",
                Zip = "ZipCode",
                LocationDescription = "Description",
                StartDate = DateTime.UtcNow.AddDays(10),
                EndDate = DateTime.UtcNow.AddDays(20),
                Status = EventStatus.Active
            };
            var expectedData = Encoding.UTF8.GetBytes(System.Text.Json.JsonSerializer.Serialize(eventDto));

            _storageService.Setup(s => s.GetBlobContent("public", It.IsAny<string>())).ReturnsAsync(expectedData);
            _storageService.Setup(x => x.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Event>())).Returns(Task.CompletedTask);

            await _sut.SaveEvent(eventDto, eventDto.Id, "saved");

            //assert
            _storageService.Verify(
             x => x.WriteObjectToBlobContent("public", It.IsAny<string>(), It.IsAny<Event>()), Times.Exactly(1));
        }


        [Test]
        public void SaveEvent_WhenWriteObjectToBlobContentThrowsException_LogsErrorandThrows()
        {
            var eventDto = new EventDto
            {
                Id = Guid.NewGuid(),
                Name = "Event Name",
                Address1 = "123 Main St",
                City = "CityName",
                Zip = "ZipCode",
                LocationDescription = "Description",
                StartDate = DateTime.UtcNow.AddDays(10),
                EndDate = DateTime.UtcNow.AddDays(20),
                Status = EventStatus.Active
            };
            var exception = new Exception("WriteBlobContent error");
            _storageService.Setup(x => x.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Event>())).ThrowsAsync(exception);

            // Act & Assert
            Assert.ThrowsAsync<Exception>(() => _sut.SaveEvent(eventDto, eventDto.Id, "saved"));
            _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));

        }
    }
}


