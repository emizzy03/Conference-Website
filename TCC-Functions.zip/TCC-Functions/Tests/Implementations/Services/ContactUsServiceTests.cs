﻿
using Microsoft.Extensions.Logging;
using Moq;
using System.Text;
using System.Text.Json;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Interfaces;
using Assert = NUnit.Framework.Assert;

namespace TCC.Functions.Tests.Implementations.Services
{
    public class ContactUsServiceTests

    {
        private Mock<ILogger<ContactUsService>> _logger = null!;
        private Mock<IStorageService> _storageService;
        private ContactUsService _sut = null!;
        [SetUp]
        public void Setup()
        {
            _logger = new Mock<ILogger<ContactUsService>>();
            _storageService = new Mock<IStorageService>();
            _sut = new ContactUsService(_storageService.Object, _logger.Object);
        }
        [Test]
        public async Task ContactUsDataTest_SuccessfulTest()
        {

            var message = new ContactUsDto
            {
                Name = "John Smith",
                Organization = "Dominican University",
                Role = "Staff",
                EmailAddress = "john.smith@my.dom.edu",
                Message = "Hello",
            };
            var expectedData = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(message));
            _storageService.Setup(x => x.GetBlobContent("public", It.IsAny<string>())).ReturnsAsync(expectedData);
            _storageService.Setup(x => x.WriteBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(Task.CompletedTask);
            await _sut.ProcessContactUsData(message);
            // Assert
            _storageService.Verify(
                x => x.WriteBlobContent("public", It.IsAny<string>(), It.IsAny<string>()),
                Times.Exactly(1));
           

            byte[] actualData = await _storageService.Object.GetBlobContent("public", It.IsAny<string>()); 
            string actualJson = Encoding.UTF8.GetString(actualData);
            var actualContactUsDto = JsonSerializer.Deserialize<ContactUsDto>(actualJson);
            var expectedJson = JsonSerializer.Serialize(message);
            Assert.That(actualJson,Is.EqualTo(expectedJson));

            // Assert that the expected ContactUsDTO object matches the actual ContactUsDTO object.
            Assert.That(actualContactUsDto.Name, Is.EqualTo(message.Name));
            Assert.That(actualContactUsDto.Organization, Is.EqualTo(message.Organization));
            Assert.That(actualContactUsDto.Role, Is.EqualTo(message.Role));
            Assert.That(actualContactUsDto.EmailAddress, Is.EqualTo(message.EmailAddress));
            Assert.That(actualContactUsDto.Message, Is.EqualTo(message.Message));


        }

        [Test]
        public Task ContactUsData_ErrorHandling()
        {
            var message = new ContactUsDto
            {
                Name = "John Smith",
                Organization = "Dominican University",
                Role = "Staff",
                EmailAddress = "john.smith@my.dom.edu",
                Message = "Test message",
            };
            Exception exception = new Exception("There was some error reading from storage");
            _storageService.Setup(x => x.WriteBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(exception);
          Assert.ThrowsAsync<Exception>(async () => await _sut.ProcessContactUsData(message));
            _storageService.Verify(
                 x => x.WriteBlobContent("public", It.IsAny<string>(), It.IsAny<string>()),
                 Times.Exactly(1));
            _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
            //verifies that we call logger with error on exception
            _logger.Verify(logger => logger.Log(LogLevel.Error, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
            return Task.CompletedTask;
        }
    }
}