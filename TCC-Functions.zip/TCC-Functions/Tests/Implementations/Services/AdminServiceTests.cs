﻿using Autofac.Core;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestPlatform.ObjectModel.DataCollection;
using Moq;
using Newtonsoft.Json;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Interfaces;
using TCC.Functions.Model;


namespace TCC.Functions.Tests.Implementations.Services
{
    public class AdminServiceTests
    {
        private readonly Mock<ILogger<AdminService>> _loggerMock;
        private readonly Mock<IStorageService> _storageServiceMock;
        private readonly Mock<IPublicDataService> _publicDataServiceMock;
        private readonly AdminService _adminService;

        public AdminServiceTests()
        {
            _loggerMock = new Mock<ILogger<AdminService>>();
            _storageServiceMock = new Mock<IStorageService>();
            _publicDataServiceMock = new Mock<IPublicDataService>();
            _adminService = new AdminService(_loggerMock.Object, _storageServiceMock.Object, _publicDataServiceMock.Object);
        }

        [Test]
        public async Task SaveCodeOfConduct_WithValidContent_CallsWriteBlobContent()
        {
            // Arrange
            var requestBody = "{\"content\":\"Test Content\"}";

            // Act
            await _adminService.SaveCodeOfConduct(requestBody);

            // Assert
            _storageServiceMock.Verify(s => s.WriteBlobContent("public", "codeofconduct.json", requestBody), Times.Once);

        }

        [Test]
        public void SaveCodeOfConduct_WhenWriteBlobContentThrowsException_LogsErrorAndThrows()
        {
            // Arrange
            string content = "Code of conduct content";
            var exception = new Exception("WriteBlobContent error");
            _storageServiceMock.Setup(s => s.WriteBlobContent("public", "codeofconduct.json", content)).ThrowsAsync(exception);

            // Act & Assert
            Assert.ThrowsAsync<Exception>(() => _adminService.SaveCodeOfConduct(content));


        }
        [Test]
        public async Task SavePrivacy_WithValidContent_CallsWriteBlobContent()
        {
            // Arrange
            var requestBody = "{\"content\":\"Test Content\"}";

            // Act
            await _adminService.SavePrivacy(requestBody);

            // Assert
            _storageServiceMock.Verify(s => s.WriteBlobContent("public", "privacy.json", requestBody), Times.Once);

        }

        [Test]
        public void SavePrivacy_WhenWriteBlobContentThrowsException_LogsErrorAndThrows()
        {
            // Arrange
            string content = "Privacy content";
            var exception = new Exception("WriteBlobContent error");
            _storageServiceMock.Setup(s => s.WriteBlobContent("public", "privacy.json", content)).ThrowsAsync(exception);

            // Act & Assert
            Assert.ThrowsAsync<Exception>(() => _adminService.SavePrivacy(content));


        }

        [Test]
        public async Task ConferenceInfo_WithValidContent_CallsWriteObjectToBlobContent()
        {
            //act
            var conferenceInfo = new ConferenceInfoDto
            {
                Id = Guid.Parse("550e8400-e29b-41d4-a716-446655440000"),
                Name = "Christian Conference",
                Address1 = "2222 home",
                Address2 = "",
                City = "River Forest",
                State = "IL",
                Zip = "505050",
                Email = "myemail@myemail.com",
                Description = "data test",
                Phone = "708-777-7777",
                Image = "../../image/myimage",
                MissionStatement = "test mission",
                LocationHeader = "location stats",
                MiscInfo = "miscinfo",
            };
            _storageServiceMock.Setup(x => x.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ConferenceInfo>())).Returns(Task.CompletedTask);

            _storageServiceMock.Verify(
       s => s.WriteObjectToBlobContent("public", "conferenceinfo.json", It.IsAny<ConferenceInfo>()),
       Times.Exactly(1)
   );
            // Act
            await _adminService.SaveConference(conferenceInfo);

            //asert
            _storageServiceMock.Verify(
                   s => s.WriteObjectToBlobContent("public", "conferenceinfo.json", It.IsAny<ConferenceInfo>()),
                   Times.Exactly(2)
               );
            _loggerMock.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(2));


        }

        [Test]
        public void ConferenceInfo_WhenWriteObjectToBlobContentThrowsException_LogsErrorAndThrows()
        {
            var conferenceInfo = new ConferenceInfoDto
            {
                Id = Guid.Parse("550e8400-e29b-41d4-a716-446655440000"),
                Name = "Christian Conference",
                Address1 = "2222 home",
                Address2 = "",
                City = "River Forest",
                State = "IL",
                Zip = "505050",
                Email = "myemail@myemail.com",
                Description = "data test",
                Phone = "708-777-7777",
                Image = "../../image/myimage",
                MissionStatement = "test mission",
                LocationHeader = "location stats",
                MiscInfo = "miscinfo",
                StaffDescription = "description",
            };
            var exception = new Exception("WriteBlobContent error");
            _storageServiceMock.Setup(x => x.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ConferenceInfo>())).ThrowsAsync(exception);

            // Act & Assert
            Assert.ThrowsAsync<Exception>(() => _adminService.SaveConference(conferenceInfo));
            _loggerMock.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));

        }

        [Test]
        public async Task DeleteEvent_WithValidContent_CallDeleteFileByPath()
        {
            List<string> blobs = new List<string>();
            blobs.Add("events/01446bd5-464d-4c3c-a403-36f829d22a97/");

            var eventDto = new EventDto
            {
                Id = Guid.Parse("01446bd5-464d-4c3c-a403-36f829d22a97"),
                Name = "Event Name",
                Address1 = "123 Main St",
                City = "CityName",
                Zip = "ZipCode",
                LocationDescription = "Description",
                StartDate = DateTime.UtcNow.AddDays(10),
                EndDate = DateTime.UtcNow.AddDays(20),
                Status = EventStatus.Active
            };

            _storageServiceMock.Setup(x => x.DeleteFolderByPath("public", It.IsAny<string>())).Returns(Task.CompletedTask);

            await _adminService.RemoveEvent(eventDto);

            //assert
            _storageServiceMock.Verify(
             x => x.DeleteFolderByPath("public", It.IsAny<string>()), Times.AtLeastOnce);
        }


        [Test]
        public async Task DeleteEventWithSession_WithValidContent_CallDeleteFileByPath()
        {
            List<string> blobs = new List<string>();
            blobs.Add("events/01446bd5-464d-4c3c-a403-36f829d22a97/");
            blobs.Add("events/01446bd5-464d-4c3c-a403-36f829d22a97/sessions/3abc5b89-3c6e-49e1-990f-53f986e0ad37.json");

            var eventDto = new EventDto
            {
                Id = Guid.Parse("01446bd5-464d-4c3c-a403-36f829d22a97"),
                Name = "Event Name",
                Address1 = "123 Main St",
                City = "CityName",
                Zip = "ZipCode",
                LocationDescription = "Description",
                StartDate = DateTime.UtcNow.AddDays(10),
                EndDate = DateTime.UtcNow.AddDays(20),
                Status = EventStatus.Active
            };
            _storageServiceMock.Setup(x => x.GetBlobs(It.IsAny<string>()))
                              .Returns(blobs);


            _storageServiceMock.Setup(x => x.DeleteFolderByPath("public", It.IsAny<string>())).Returns(Task.CompletedTask);

            await _adminService.RemoveEvent(eventDto);

            //assert
            _storageServiceMock.Verify(
             x => x.DeleteFolderByPath("public", It.IsAny<string>()), Times.AtLeast(2));
        }

        [Test]
        public void DeleteEvent_ThrowsAnExceptionError()
        {
            List<string> blobs = new List<string>();
            blobs.Add("events/01446bd5-464d-4c3c-a403-36f829d22a97/");

            var eventDto = new EventDto
            {
                Id = Guid.Parse("01446bd5-464d-4c3c-a403-36f829d22a97"),
                Name = "Event Name",
                Address1 = "123 Main St",
                City = "CityName",
                Zip = "ZipCode",
                LocationDescription = "Description",
                StartDate = DateTime.UtcNow.AddDays(10),
                EndDate = DateTime.UtcNow.AddDays(20),
                Status = EventStatus.Active
            };

            var exception = new Exception("Delete file by path error");

            _storageServiceMock.Setup(x => x.GetBlobs(It.IsAny<string>()))
                              .Returns(blobs);


            _storageServiceMock.Setup(x => x.DeleteFolderByPath(It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(exception);

            // Act & Assert
            Assert.ThrowsAsync<Exception>(() => _adminService.RemoveEvent(eventDto));
            _loggerMock.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.AtLeastOnce);

        }

        [Test]
        public void DeleteEventWithSession_ThrowsAnExceptionError()
        {
            List<string> blobs = new List<string>();
            blobs.Add("events/01446bd5-464d-4c3c-a403-36f829d22a97/");
            blobs.Add("events/01446bd5-464d-4c3c-a403-36f829d22a97/sessions/3abc5b89-3c6e-49e1-990f-53f986e0ad37.json");

            var eventDto = new EventDto
            {
                Id = Guid.Parse("01446bd5-464d-4c3c-a403-36f829d22a97"),
                Name = "Event Name",
                Address1 = "123 Main St",
                City = "CityName",
                Zip = "ZipCode",
                LocationDescription = "Description",
                StartDate = DateTime.UtcNow.AddDays(10),
                EndDate = DateTime.UtcNow.AddDays(20),
                Status = EventStatus.Active
            };

            var exception = new Exception("Delete file by path error");


            _storageServiceMock.Setup(x => x.GetBlobs(It.IsAny<string>()))
                               .Returns(blobs);

            _storageServiceMock.Setup(x => x.DeleteFolderByPath(It.IsAny<string>(), It.IsAny<string>()))
                               .ThrowsAsync(exception);


            _storageServiceMock.Setup(x => x.DeleteFolderByPath(It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(exception);

            // Act & Assert
            Assert.ThrowsAsync<Exception>(() => _adminService.RemoveEvent(eventDto));
            _loggerMock.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.AtLeastOnce);

        }

        [Test]
        public async Task SaveSocialMediaPlatforms_WithValidContent_CallsWriteBlobContent()
        {
            //arrange 
            var validList = new List<SocialMediaPlatform>
        {
            new SocialMediaPlatform
            {
                Id = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4"),
                Name = "Twitter",
                Icon = "fa-twitter-square"
            },
            new SocialMediaPlatform {
                Name = "Twitter",
                Icon = "fa-twitter-square"
            }
        };
            _storageServiceMock.Setup(x => x.WriteBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(Task.CompletedTask);

            //act
            await _adminService.SaveSocialMediaPlatforms(validList);

            //assert 
            _storageServiceMock.Verify(
             s => s.WriteBlobContent("public", "socialmediaplatforms/socialmediaplatforms.json", It.IsAny<string>()),
             Times.Exactly(6));
        }


        [Test]
        public void SaveSocialMediaPlatforms_WhenWriteBlobContentThrowsException_LogsErrorAndThrows()
        {
            // Arrange
            var validList = new List<SocialMediaPlatform>
        {
            new SocialMediaPlatform
            {
                Id = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4"),
                Name = "Twitter",
                Icon = "fa-twitter-square"
            }
        };
            var exception = new Exception("WriteBlobContent error");
            _storageServiceMock.Setup(x => x.WriteBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(exception);

            // Act & Assert
            Assert.ThrowsAsync<Exception>(() => _adminService.SaveSocialMediaPlatforms(validList));
        }
      
        [Test]
        public async Task RemoveSessionThenEvents_RemovesSessionsFromUsers()
        {
            // Arrange
            var eventId = Guid.Parse("01446bd5-464d-4c3c-a403-36f829d22a97");
            var sessionId = Guid.Parse("3abc5b89-3c6e-49e1-990f-53f986e0ad37");
            var eventDto = new EventDto { Id = eventId };
            var sessionJson = JsonConvert.SerializeObject(new Session { Id = sessionId, EventId = eventId, Title = "to", Description = "vev", UserId = Guid.Parse("0a3f962c-cb6c-4bc3-a5a6-8bffe7538bc7") });
            var userJson = JsonConvert.SerializeObject(new UserDTO { Id = Guid.Parse("0a3f962c-cb6c-4bc3-a5a6-8bffe7538bc7"), PresentationSessions = new List<Guid> { sessionId, Guid.Parse("bec8ee80-2abc-4e9c-a581-9e84df584179") }, FirstName = "lord", LastName = "lugard", Email = "ll@fool.com" });

            // Setup mock for GetBlobs to return the session file name
            var path = $"public/events/{eventId}/sessions/";
            _storageServiceMock.Setup(s => s.GetBlobs(path))
                .Returns(new List<string> { $"{sessionId}.json" }); // Simulate finding one session file

            _storageServiceMock.Setup(s => s.GetDataFromStorage("public", It.IsAny<string>()))
                 .ReturnsAsync(sessionJson);

            _storageServiceMock.Setup(s => s.GetBlobs("public"))
                .Returns(new List<string> { $"users/0a3f962c-cb6c-4bc3-a5a6-8bffe7538bc7/0a3f962c-cb6c-4bc3-a5a6-8bffe7538bc7.json" });

            _storageServiceMock.Setup(s => s.GetDataFromStorage("public", "users/0a3f962c-cb6c-4bc3-a5a6-8bffe7538bc7/0a3f962c-cb6c-4bc3-a5a6-8bffe7538bc7.json"))
                .ReturnsAsync(userJson);

            // Act
            await _adminService.RemoveSessionsFromUser(eventDto);

            // Assert
            _storageServiceMock.Setup(s => s.WriteObjectToBlobContent("public", "users/0a3f962c-cb6c-4bc3-a5a6-8bffe7538bc7/0a3f962c-cb6c-4bc3-a5a6-8bffe7538bc7.json", It.IsAny<string>()))
            .Returns(Task.CompletedTask);
        }

        [Test]
        public async Task RemoveSocialMediaPlatformWithUserPlatform_WhenCalled_ShouldRemovePlatformFromBlob()
        {
            // Arrange
            var platformToRemove = new SocialMediaPlatform { Id = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4"), Name = "Test Platform", Icon = "Test Icon" };
            var socialMediaPlatforms = new List<SocialMediaPlatform>
        {
            new SocialMediaPlatform
            {
                Id = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4"),
                Name = "Test Platform",
                Icon = "Test Icon"
            },
            new SocialMediaPlatform {
                Id = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead5"),
                Name = "Twitter",
                Icon = "fa-twitter-square"
            }
        };
            var userSocialMediaPlatforms = new List<UserSocialMedia>
        {
            new UserSocialMedia
            {
                SocialMediaPlatformId = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4")
            }
        };
            var userSocialMediaFiles = new List<string> { "users/testuser/socialmedia.json" };

            var content = JsonConvert.SerializeObject(userSocialMediaPlatforms);

            _publicDataServiceMock.Setup(x => x.GetSocialMediaPlatforms()).ReturnsAsync(socialMediaPlatforms);
            _storageServiceMock.Setup(x => x.GetBlobs("public")).Returns(userSocialMediaFiles);
            _storageServiceMock.Setup(x => x.WriteBlobContent("public", It.IsAny<string>(), It.IsAny<string>())).Returns(Task.CompletedTask);
            _storageServiceMock.Setup(x => x.GetDataFromStorage("public", It.IsAny<string>())).ReturnsAsync(content);
            _storageServiceMock.Setup(x => x.DeleteFileByPath("public", It.IsAny<string>())).Returns(Task.CompletedTask);

            // Act
            await _adminService.RemoveSocialMediaPlatform(platformToRemove);

            // Assert
            _publicDataServiceMock.Verify(x => x.GetSocialMediaPlatforms(), Times.Exactly(2));
            _storageServiceMock.Verify(
             s => s.WriteBlobContent("public", "socialmediaplatforms/socialmediaplatforms.json", It.IsAny<string>()),
             Times.Exactly(2));
            _storageServiceMock.Verify(s => s.BlobExists("public", It.IsAny<string>()), Times.Exactly(2));
            _storageServiceMock.Verify(s => s.DeleteFileByPath("public", It.IsAny<string>()), Times.Exactly(1));
        }

        [Test]
        public async Task RemoveSocialMediaPlatformWithoutUserPlatform_WhenCalled_ShouldRemovePlatformFromBlob()
        {
            // Arrange
            var platformToRemove = new SocialMediaPlatform { Id = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4"), Name = "Test Platform", Icon = "Test Icon" };
            var socialMediaPlatforms = new List<SocialMediaPlatform>
        {
            new SocialMediaPlatform {
                Id = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead5"),
                Name = "Twitter",
                Icon = "fa-twitter-square"
            }
        };
            var userSocialMediaPlatforms = new List<UserSocialMedia>
        {
            new UserSocialMedia
            {
                SocialMediaPlatformId = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4")
            },
            new UserSocialMedia {
                SocialMediaPlatformId = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead5")
            }
        };
            var userSocialMediaFiles = new List<string> { "users/testuser/socialmedia.json" };

            var content = JsonConvert.SerializeObject(socialMediaPlatforms);

            _publicDataServiceMock.Setup(x => x.GetSocialMediaPlatforms()).ReturnsAsync(socialMediaPlatforms);
            _storageServiceMock.Setup(x => x.GetBlobs("public")).Returns(userSocialMediaFiles);
            _storageServiceMock.Setup(x => x.WriteBlobContent("public", It.IsAny<string>(), It.IsAny<string>())).Returns(Task.CompletedTask);
            _storageServiceMock.Setup(x => x.GetDataFromStorage("public", It.IsAny<string>())).ReturnsAsync(content);

            // Act
            await _adminService.RemoveSocialMediaPlatform(platformToRemove);

            // Assert
            _publicDataServiceMock.Verify(x => x.GetSocialMediaPlatforms(), Times.Once);
            _storageServiceMock.Verify(
             s => s.WriteBlobContent("public", "socialmediaplatforms/socialmediaplatforms.json", It.IsAny<string>()),
             Times.Exactly(1));
            _storageServiceMock.Verify(s => s.BlobExists("public", It.IsAny<string>()), Times.Exactly(1));
        }

        [Test]
        public async Task RemoveSocialMediaPlatformWithUserPlatformAndBlobNotExist_WhenCalled_ShouldRemovePlatformFromBlob()
        {
            // Arrange
            var platformToRemove = new SocialMediaPlatform { Id = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4"), Name = "Test Platform", Icon = "Test Icon" };
            var socialMediaPlatforms = new List<SocialMediaPlatform>
        {
            new SocialMediaPlatform
            {
                Id = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4"),
                Name = "Test Platform",
                Icon = "Test Icon"
            },
            new SocialMediaPlatform {
                Id = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead5"),
                Name = "Twitter",
                Icon = "fa-twitter-square"
            }
        };
            var userSocialMediaPlatforms = new List<UserSocialMedia>
        {
            new UserSocialMedia
            {
                SocialMediaPlatformId = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4")
            }
        };
            var userSocialMediaFiles = new List<string> { "users/testuser/socialmedia.json" };

            var content = JsonConvert.SerializeObject(userSocialMediaPlatforms);

            _publicDataServiceMock.Setup(x => x.GetSocialMediaPlatforms()).ReturnsAsync(socialMediaPlatforms);
            _storageServiceMock.Setup(x => x.GetBlobs("public")).Returns(userSocialMediaFiles);
            _storageServiceMock.Setup(x => x.WriteBlobContent("public", It.IsAny<string>(), It.IsAny<string>())).Returns(Task.CompletedTask);
            _storageServiceMock.Setup(x => x.GetDataFromStorage("public", It.IsAny<string>())).ReturnsAsync(content);
            _storageServiceMock.Setup(x => x.DeleteFileByPath("public", It.IsAny<string>())).Returns(Task.CompletedTask);
            _storageServiceMock.Setup(x => x.BlobExists(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(true);

            // Act
            await _adminService.RemoveSocialMediaPlatform(platformToRemove);

            // Assert
            _publicDataServiceMock.Verify(x => x.GetSocialMediaPlatforms(), Times.Exactly(4));
            _storageServiceMock.Verify(
             s => s.WriteBlobContent("public", "socialmediaplatforms/socialmediaplatforms.json", It.IsAny<string>()),
             Times.Exactly(4));
            _storageServiceMock.Verify(s => s.BlobExists("public", It.IsAny<string>()), Times.Exactly(4));
            _storageServiceMock.Verify(s => s.DeleteFileByPath("public", It.IsAny<string>()), Times.Exactly(3));
        }
        [Test]
        public void RemoveSocialMediaPlatformWithUserPlatform_WhenCalled_ThrowsException()
        {
            // Arrange
            var platformToRemove = new SocialMediaPlatform { Id = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4"), Name = "Test Platform", Icon = "Test Icon" };
            var socialMediaPlatforms = new List<SocialMediaPlatform>
        {
            new SocialMediaPlatform
            {
                Id = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4"),
                Name = "Test Platform",
                Icon = "Test Icon"
            },
            new SocialMediaPlatform {
                Id = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead5"),
                Name = "Twitter",
                Icon = "fa-twitter-square"
            }
        };
            var userSocialMediaPlatforms = new List<UserSocialMedia>
        {
            new UserSocialMedia
            {
                SocialMediaPlatformId = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4")
            }
        };
            var userSocialMediaFiles = new List<string> { "users/testuser/socialmedia.json" };
            var content = JsonConvert.SerializeObject(userSocialMediaPlatforms);


            var exception = new Exception("WriteBlobContent error");
            _storageServiceMock.Setup(x => x.WriteBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(exception);

            _publicDataServiceMock.Setup(x => x.GetSocialMediaPlatforms()).ReturnsAsync(socialMediaPlatforms);
            _storageServiceMock.Setup(x => x.GetBlobs("public")).Returns(userSocialMediaFiles);
            _storageServiceMock.Setup(x => x.GetDataFromStorage("public", It.IsAny<string>())).ReturnsAsync(content);
            _storageServiceMock.Setup(x => x.DeleteFileByPath("public", It.IsAny<string>())).Returns(Task.CompletedTask);
            _storageServiceMock.Setup(x => x.BlobExists(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(true);

            // Act && Assert
            Assert.ThrowsAsync<Exception>(async () => await _adminService.RemoveSocialMediaPlatform(platformToRemove));
        }

    }
}



