using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using TCC.Functions.Implementations.Services.Auth;
using TCC.Functions.Interfaces;

namespace TCC.Functions.Tests.Implementations.Services.Auth;
[TestFixture]
public class AzureADServiceTests
{
    private Mock<IHttpService> _httpService = new Mock<IHttpService>();
    private Mock<ILogger<AzureADService>> _logger = new Mock<ILogger<AzureADService>>();
    private AzureADService _sut = null!; //System Under Test
    [SetUp]
    public void Setup()
    {
        _httpService = new Mock<IHttpService>();
        _logger = new Mock<ILogger<AzureADService>>();
        _sut = new AzureADService(_httpService.Object);
    }
    [Test]
    public async Task Given_EnvVariablesAreCorrect_Then_ObtainTokenInJObject()
    {
        JObject? jObject = JsonConvert.DeserializeObject<JObject>(_validJsonToken);
        _httpService.Setup(h => h.PostStringContentRequest(It.IsAny<string>(),
            It.IsAny<StringContent>(), string.Empty).Result).Returns(jObject);
        //ACT
        var sutResult = await _sut.GetAuthTokenFromMicrosoftAsync();
        //ASSERT
        _httpService.Verify(p => p.PostStringContentRequest(It.IsAny<string>(),
            It.IsAny<StringContent>(), string.Empty), Times.Once);
        Assert.That(sutResult, Is.EqualTo(jObject));
    }
    [Test]
    public void Given_EnvVariablesAreCorrect_GraphReturnsNull_Then_ThrowException()
    {
        JObject? jObject = null;
        _httpService.Setup(h => h.PostStringContentRequest(It.IsAny<string>(),
            It.IsAny<StringContent>(), string.Empty).Result).Returns(jObject);
        //ACT
        Assert.ThrowsAsync<Exception>(() =>
            _sut.GetAuthTokenFromMicrosoftAsync());
        //ASSERT
        _httpService.Verify(p => p.PostStringContentRequest(It.IsAny<string>(),
            It.IsAny<StringContent>(), string.Empty), Times.Once);
    }
    [Test]
    public Task Given_EnvVariablesAreCorrect_HttpThrowsEx_Then_ThrowException()
    {
        _httpService.Setup(h => h.PostStringContentRequest(It.IsAny<string>(),
            It.IsAny<StringContent>(), string.Empty).Result).Throws(It.IsAny<Exception>());
        //ACT
        Assert.ThrowsAsync<NullReferenceException>(() =>
            _sut.GetAuthTokenFromMicrosoftAsync());
        //ASSERT
        _httpService.Verify(p => p.PostStringContentRequest(It.IsAny<string>(),
            It.IsAny<StringContent>(), string.Empty), Times.Once);
        return Task.CompletedTask;
    }
    #region Helper Methods

    private readonly Guid _userId = Guid.NewGuid();
    private readonly string _validJsonToken =
        "{\"token_type\":\"Bearer\",\"expires_in\":\"3599\",\"ext_expires_in\":\"3599\",\"expires_on\":\"1684792100\",\"not_before\":\"1684788200\",\"resource\":\"https://graph.microsoft.com/\",\"access_token\":\"validaccesstoken\"}";

    #endregion
}