﻿using Azure;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using System;
using System.ComponentModel.Design;
using System.Net;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Interfaces;
using TCC.Functions.Model;

namespace TCC.Functions.Tests.Implementations.Services
{
    [TestFixture]
    public class UrlValidatorTests
    {
        private UrlValidator _urlValidator = null!;
        private Mock<IHttpWebRequestService> _httpWebRequestServiceMock = null!;
        private Mock<ILogger<UrlValidator>> _loggerMock = null!;

        [SetUp]
        public void Setup()
        {
            _httpWebRequestServiceMock = new Mock<IHttpWebRequestService>();
            _loggerMock = new Mock<ILogger<UrlValidator>>();
            _urlValidator = new UrlValidator(_httpWebRequestServiceMock.Object);
        }


        [Test]
        public void UrlIsValid_ValidUrl_ReturnsTrue()
        {
            // Arrange
            string validUrl = "https://creazilla-store.fra1.digitaloceanspaces.com/icons/3220761/user-circle-icon-md.png";


            var response = new WebRequestResponse();
            response.StatusCode = HttpStatusCode.OK;
            _httpWebRequestServiceMock.Setup(x => x.GetURLResponse(validUrl)).Returns(response);

            // Act
            var result = _urlValidator.UrlIsValid(validUrl, _loggerMock.Object);

            // Assert
            Assert.IsTrue(result);
        }

        [Test]
        public void UrlIsValid_Status100_ReturnsTrue()
        {
            // Arrange
            var url = "http://example.com";
            var response = new WebRequestResponse { StatusCode = HttpStatusCode.Continue }; // 100
            _httpWebRequestServiceMock.Setup(x => x.GetURLResponse(url)).Returns(response);

            // Act
            var result = _urlValidator.UrlIsValid(url, _loggerMock.Object);

            // Assert
            Assert.IsTrue(result);
        }

        [Test]
        public void UrlIsValid_Status200_ReturnsTrue()
        {
            // Arrange
            var url = "http://example.com";
            var response = new WebRequestResponse { StatusCode = HttpStatusCode.OK }; // 200
            _httpWebRequestServiceMock.Setup(x => x.GetURLResponse(url)).Returns(response);

            // Act
            var result = _urlValidator.UrlIsValid(url, _loggerMock.Object);

            // Assert
            Assert.IsTrue(result);
        }



        [Test]
        public void UrlIsValid_Status400_ReturnsFalse()
        {
            // Arrange
            var url = "http://example.com";
            var response = new WebRequestResponse { StatusCode = HttpStatusCode.BadRequest }; // 400
            _httpWebRequestServiceMock.Setup(x => x.GetURLResponse(url)).Returns(response);

            // Act
            var result = _urlValidator.UrlIsValid(url, _loggerMock.Object);

            // Assert
            Assert.IsFalse(result);
        }

        [Test]
        public void UrlIsValid_Status500_ReturnsFalse()
        {
            // Arrange
            var url = "http://example.com";
            var response = new WebRequestResponse { StatusCode = HttpStatusCode.InternalServerError }; // 500
            _httpWebRequestServiceMock.Setup(x => x.GetURLResponse(url)).Returns(response);

            // Act
            var result = _urlValidator.UrlIsValid(url, _loggerMock.Object);

            // Assert
            Assert.IsFalse(result);
        }

        [Test]
        public void UrlIsValid_Status510_ReturnsFalse()
        {
            // Arrange
            var url = "http://example.com";
            var response = new WebRequestResponse { StatusCode = (HttpStatusCode)510 }; // 510
            _httpWebRequestServiceMock.Setup(x => x.GetURLResponse(url)).Returns(response);

            // Act
            var result = _urlValidator.UrlIsValid(url, _loggerMock.Object);

            // Assert
            Assert.IsFalse(result);
        }

        [Test]
        public void UrlIsValid_ProtocolError_ReturnsFalse()
        {
            // Arrange
            var invalidUrl = "http://www.protocolerror.com";
            var exception = new WebException("ProtocolError occurred", WebExceptionStatus.ProtocolError);
            _httpWebRequestServiceMock.Setup(x => x.GetURLResponse(invalidUrl)).Throws(exception);

            // Act
            var result = _urlValidator.UrlIsValid(invalidUrl, _loggerMock.Object);

            // Assert
            Assert.IsFalse(result);
        }


        [Test]
        public void UrlIsValid_TimeoutError_ReturnsFalse()
        {
            // Arrange
            var invalidUrl = "http://example.com";
            var exception = new WebException("Timeout occurred", WebExceptionStatus.Timeout);
            _httpWebRequestServiceMock.Setup(x => x.GetURLResponse(invalidUrl)).Throws(exception);

            // Act
            var result = _urlValidator.UrlIsValid(invalidUrl, _loggerMock.Object);

            // Assert
            Assert.IsFalse(result);
        }

        [Test]
        public void UrlIsValid_UnhandledError_ReturnsFalse()
        {
            // Arrange
            var invalidUrl = "http://example.com";
            var exception = new WebException("Unhandled error occurred", WebExceptionStatus.UnknownError);
            _httpWebRequestServiceMock.Setup(x => x.GetURLResponse(invalidUrl)).Throws(exception);

            // Act
            var result = _urlValidator.UrlIsValid(invalidUrl, _loggerMock.Object);

            // Assert
            Assert.IsFalse(result);

        }

        [Test]
        public void UrlIsValid_UnhandledException_ReturnsFalse()
        {
            // Arrange
            var invalidUrl = "http://example.com";
            var exception = new Exception("Unhandled exception occurred");
            _httpWebRequestServiceMock.Setup(x => x.GetURLResponse(invalidUrl)).Throws(exception);

            // Act
            var result = _urlValidator.UrlIsValid(invalidUrl, _loggerMock.Object);

            // Assert
            Assert.IsFalse(result);
        }
    }
}
