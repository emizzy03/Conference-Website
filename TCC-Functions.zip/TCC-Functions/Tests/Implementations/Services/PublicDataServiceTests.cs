using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Interfaces;
using TCC.Functions.Model;

namespace TCC.Functions.Tests.Implementations.Services;

public class PublicDataServiceTests
{
    private Mock<ILogger<PublicDataService>> _logger = null!;
    private Mock<IStorageService> _storageService = null!;
    private PublicDataService _sut = null!;
    private Mock<IHttpWebRequestService> _httpWebRequestServiceMock;
    [SetUp]
    public void Setup()
    {
        _logger = new Mock<ILogger<PublicDataService>>();
        _storageService = new Mock<IStorageService>();
        _httpWebRequestServiceMock = new Mock<IHttpWebRequestService>();
        _sut = new PublicDataService(_storageService.Object, _logger.Object, _httpWebRequestServiceMock.Object);
    }

    [Test]
    public async Task Given_PrivacyPolicyExists_Then_ReturnsPrivacyString()
    {
        //setup
        var expectedResult = ValidPrivacyPolicy;
        var resultString = ValidPrivacyPolicy;
        _storageService.Setup(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()).Result).
            Returns(resultString);
        //Act
        var result = await _sut.GetPrivacy();

        //Assert

        //Tests to make sure our value in "expectedResult" matches the return result of the System Under Test (SUT)
        Assert.That(result, Is.EqualTo(expectedResult));
        //verifies that we call GetBlobContent once
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
        //verifies that we call logger with information once on method entry
        _logger.Verify(
            logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
                It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!),
            Times.Exactly(1));
    }

    [Test]
    public Task Given_PrivacyPolicyDoesNotExist_Then_LogAndThrowException()
    {
        //setup
        Exception exception = new Exception("There was some error reading from storage");
        _storageService.Setup(s =>
            s.GetDataFromStorage("public", "privacy.json")).ThrowsAsync(exception);
        //Act & Assert
        Assert.ThrowsAsync<Exception>(() =>
            _sut.GetPrivacy()
        );
        //verifies that we call GetBlobContent once
        _storageService.Verify(s =>
            s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
        //verifies that we call logger with information once on method entry
        _logger.Verify(logger =>
            logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(),
                ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
        //verifies that we call logger with error on exception
        _logger.Verify(logger => logger.Log(LogLevel.Error, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
            It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
        return Task.CompletedTask;
    }

    [Test]
    public async Task Given_CodeOfConductExists_Then_ReturnsPrivacyString()
    {
        //setup
        var expectedResult = ValidCodeOfConduct;
        var resultString = ValidCodeOfConduct;
        _storageService.Setup(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()).Result).
            Returns(resultString);
        //Act
        var result = await _sut.GetCodeOfConduct();

        //Assert

        Assert.That(result, Is.EqualTo(expectedResult));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
    }

    [Test]
    public Task Given_CodeOfConductDoesNotExist_Then_LogAndThrowException()
    {
        //setup
        Exception exception = new Exception("There was some error reading from storage");
        _storageService.Setup(s => s.GetDataFromStorage("public", "codeofconduct.json")).ThrowsAsync(exception);
        //Act & Assert
        Assert.ThrowsAsync<Exception>(() =>
            _sut.GetCodeOfConduct()
        );
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
        _logger.Verify(logger => logger.Log(LogLevel.Error, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
        return Task.CompletedTask;
    }
    [Test]
    public void Given_GetBlobItems_CallsGetsBlobs_ReturnsList_Then_Log()
    {
        //setup
        var expectedResult = GetValidBlobItems;
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);
        //Act
        _sut.GetBlobItems();

        //Assert
        //verifies that we call GetBlobs once
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        //verifies that we call logger with information once on method entry
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(2));
    }
    [Test]
    public void Given_GetBlobItems_CallsGetsBlobs_ReturnsEmptyList_Then_Log()
    {
        //setup
        var expectedResult = new List<string>();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);
        //Act
        _sut.GetBlobItems();

        //Assert
        //verifies that we call GetBlobs once
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        //verifies that we call logger with information once on method entry
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
            It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(2));
    }
    [Test]
    public void Given_GetBlobItems_CallsGetsBlobs_ReturnsNull_Then_LogThrowsArgumentException()
    {
        //setup
        List<string>? expectedResult = null;
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult!);
        //Act
        Assert.Throws<ArgumentNullException>(() =>
            _sut.GetBlobItems());
        //Assert
        //verifies that we call GetBlobs once
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        //verifies that we call logger with information once on method entry

        _logger.Verify(l => l.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((o, t) => string.Equals("GetBlobs returned Null or Empty for container: public",
                    o.ToString(), StringComparison.InvariantCultureIgnoreCase)),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);
    }
    [Test]
    public void Given_GetBlobItems_CallsGetsBlobs_ThrowsException_Then_Log()
    {
        //setup
        Exception exception = new Exception("There was some error reading from storage");
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Throws(exception);
        //Act
        Assert.Throws<Exception>(() =>
            _sut.GetBlobItems());
        //Assert
        //verifies that we call GetBlobs once
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        //verifies that we call logger with information once on method entry
        _logger.Verify(l => l.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((o, t) => string.Equals("Error getting items from blob container: public",
                    o.ToString(), StringComparison.InvariantCultureIgnoreCase)),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);
    }
    [Test]
    public async Task Given_GetSessionsByEventId_CallsGetsBlobs_ReturnsList_Then_Log()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        var eventId = ValidEventId;
        var sessions = expectedResult.Where(s => s.Contains("sessions")).ToList();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);

        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(Session1String)
            .ReturnsAsync(Session2String)
            .ReturnsAsync(Session3String);
        //Act
        _sut.GetBlobItems();
        var sessionsList = await _sut.GetSessionsByEventId(sessions, eventId);

        //Assert
        Assert.That(sessionsList, Has.Count.EqualTo(2));
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(2));
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(3));
    }
    [Test]
    public async Task Given_GetSessionsByEventIdIsInvalid_CallsGetsBlobs_ReturnsList_Then_Log()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        var eventId = Guid.Parse("bce217b0-dc67-40f1-a82f-ffd3cc119e10");
        var sessions = expectedResult.Where(s => s.Contains("sessions")).ToList();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);

        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(Session1String)
            .ReturnsAsync(Session2String)
            .ReturnsAsync(Session3String);
        //Act
        _sut.GetBlobItems();
        var sessionsList = await _sut.GetSessionsByEventId(sessions, eventId);

        //Assert
        Assert.That(sessionsList, Is.Empty);
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(0));
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(3));
    }
    [Test]
    public async Task Given_GetSessionsByEventId_CallsGetsBlobs_ReturnsEmptyList_Then_Log()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        var eventId = Guid.Parse("bce217b0-dc67-40f1-a82f-ffd3cc119e99");
        var sessions = expectedResult.Where(s => s.Contains("sessions")).ToList();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);

        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync("")
            .ReturnsAsync("")
            .ReturnsAsync("");
        //Act
        _sut.GetBlobItems();
        var sessionsList = await _sut.GetSessionsByEventId(sessions, eventId);

        //Assert
        Assert.That(sessionsList, Is.Empty);
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(2));
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(3));
    }
    [Test]
    public void Given_GetSessionsByEventId_FailsOnGetDataFromStorage_Then_LogAndThrowException()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        var eventId = Guid.Parse("bce217b0-dc67-40f1-a82f-ffd3cc119e99");
        var sessions = expectedResult.Where(s => s.Contains("sessions")).ToList();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);
        var exception = new Exception("There was some error reading from storage");
        _storageService.Setup(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .Throws(exception);
        //Act
        _sut.GetBlobItems();
        Assert.ThrowsAsync<Exception>(async () => await _sut.GetSessionsByEventId(sessions, eventId));

        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(3));
    }

    [Test]
    public async Task Given_CreateSpeakersList_WritesBlobOfSpeakers_Then_Log()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        var eventId = Guid.Parse("bce217b0-dc67-40f1-a82f-ffd3cc119e99");
        var sessions = expectedResult.Where(s => s.Contains("sessions")).ToList();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);

        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(EventString)
            .ReturnsAsync(Session1String)
            .ReturnsAsync(Session2String)
            .ReturnsAsync(Session3String)
            .ReturnsAsync(StaffString)
            .ReturnsAsync(User1String)
            .ReturnsAsync(User2String);
        //Act
        _sut.GetBlobItems();
        await _sut.CreateSpeakersList();

        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(),It.IsAny<string>()), Times.Exactly(7));
        _storageService.Verify(s => s.WriteObjectToBlobContent(It.IsAny<string>(),It.IsAny<string>(),It.IsAny<object>()), Times.Exactly(1));
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),  It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(12));
    }

    [Test]
    public async Task Given_CreateSpeakersList_NoSpeakers_Then_Log()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        var eventId = Guid.Parse("bce217b0-dc67-40f1-a82f-ffd3cc119e99");
        var sessions = expectedResult.Where(s => s.Contains("sessions")).ToList();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);

        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(EventString)
            .ReturnsAsync(Session1String)
            .ReturnsAsync(Session2String)
            .ReturnsAsync(Session3String)
            .ReturnsAsync("")
            .ReturnsAsync("")
            .ReturnsAsync("");
        //Act
        _sut.GetBlobItems();
        await _sut.CreateSpeakersList();

        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(7));
        _storageService.Verify(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(0));
        _logger.Verify(logger => logger.Log(LogLevel.Warning, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
            It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(2));
    }
    [Test]
    public void Given_CreateSpeakersList_FailsOnReadData_Then_LogAndThrowException()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        var eventId = Guid.Parse("bce217b0-dc67-40f1-a82f-ffd3cc119e99");
        var sessions = expectedResult.Where(s => s.Contains("sessions")).ToList();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);

        Exception exception = new Exception("There was some error reading from storage");
        _storageService.Setup(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .Throws(exception);
        //Act
        _sut.GetBlobItems();
        Assert.ThrowsAsync<Exception>(() =>
            _sut.CreateSpeakersList());

        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(0));
    }
    [Test]
    public Task Given_CreateSpeakersList_FailsOnWriteData_Then_LogAndThrowException()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        var eventId = Guid.Parse("bce217b0-dc67-40f1-a82f-ffd3cc119e99");
        var sessions = expectedResult.Where(s => s.Contains("sessions")).ToList();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);
        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(EventString)
            .ReturnsAsync(Session1String)
            .ReturnsAsync(Session2String)
            .ReturnsAsync(Session3String)
            .ReturnsAsync(StaffString)
            .ReturnsAsync(User1String)
            .ReturnsAsync(User2String);
        Exception exception = new Exception("There was some error reading from storage");
        _storageService.Setup(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()))
            .Throws(exception);
        //Act
        _sut.GetBlobItems();
        Assert.ThrowsAsync<Exception>(() =>
            _sut.CreateSpeakersList());

        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(7));
        _storageService.Verify(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(1));
        return Task.CompletedTask;
    }
    [Test]
    public async Task Given_ConferenceInfoDTO_Exist_Then_returnDTO()
    {
        // Arrange
        var expectedResult = JsonConvert.DeserializeObject<ConferenceInfoDto>(ConferenceInfoString);
        _storageService.SetupSequence(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()).Result)
                       .Returns(ConferenceInfoString)
                       .Returns(ValidPrivacyPolicy)
                       .Returns(EventString)
                       .Returns(ValidCodeOfConduct);
        // Act
        var result = await _sut.GetConferenceInfo();

        // Assert
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(3));
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(6));
        Assert.IsNotNull(result);
    }

    [Test]
    public void Given_ConferenceInfoDTO_DoesNotExist_then_return_Exception()
    {
        //setup
        Exception exception = new Exception("There was some error reading from storage");
        _storageService.SetupSequence(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()).Result).Returns(ConferenceInfoString).Throws(exception);
        //Act & Assert
        Assert.ThrowsAsync<Exception>(() =>
            _sut.GetConferenceInfo()
        );

        //verifys that we call GetBlobContent once
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(2));
        //verifys that we call logger with information once on method entry
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(2));
        //verifys that we call logger with error on exception
        _logger.Verify(logger => logger.Log(LogLevel.Error, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(2));
    }

    [Test]
    public async Task Given_CreateConferenceInfo_GeneratesBlobData_Then_Log()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);
        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(ConferenceInfoString)
            .ReturnsAsync(ValidPrivacyPolicy)
            .ReturnsAsync(ConferenceInfoString)
            .ReturnsAsync(EventString)
            .ReturnsAsync("");
        //Act
        _sut.GetBlobItems();
        await _sut.CreateConferenceInfo();
        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(5));
        _storageService.Verify(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(1));
    }
    [Test]
    public Task Given_CreateConferenceInfo_FailsOnReadData_Then_LogAndThrowException()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);
        Exception exception = new Exception("There was some error reading from storage");
        _storageService.Setup(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .Throws(exception);
        //Act
        _sut.GetBlobItems();
        Assert.ThrowsAsync<Exception>(() =>
            _sut.CreateConferenceInfo());
        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(0));
        return Task.CompletedTask;
    }
    [Test]
    public Task Given_CreateConferenceInfo_ReadsEmptyConferenceInfo_Then_LogAndThrowException()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);
        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(EmptyEventString);
        //Act
        _sut.GetBlobItems();
        Assert.ThrowsAsync<Exception>(() =>
            _sut.CreateConferenceInfo());
        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(0));
        return Task.CompletedTask;
    }
    [Test]
    public Task Given_CreateConferenceInfo_FailsOnWriteData_Then_LogAndThrowException()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);
        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(ConferenceInfoString)
            .ReturnsAsync(ValidPrivacyPolicy)
            .ReturnsAsync(ConferenceInfoString)
            .ReturnsAsync(EventString)
            .ReturnsAsync(EmptyEventString);
        var exception = new Exception("There was some error reading from storage");
        _storageService.Setup(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()))
            .Throws(exception);
        //Act
        _sut.GetBlobItems();
        Assert.ThrowsAsync<Exception>(() =>
            _sut.CreateConferenceInfo());
        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(5));
        _storageService.Verify(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(1));
        return Task.CompletedTask;
    }

    [Test]
    public async Task Given_GetEvents_WithNoSessionData_Then_ReturnsEvents()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).Returns(expectedResult);
        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(EventString)
            .ReturnsAsync(EmptyEventString);
        //Act
        _sut.GetBlobItems();
        var result = await _sut.GetEvents();
        //Assert
        Assert.That(1, Is.EqualTo(result.Count));
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
            It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(4));
    }

    [Test]
    public async Task Given_GetEvents_WithSessionData_Then_ReturnsEvents()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).Returns(expectedResult);
        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(EventString)
            .ReturnsAsync(EmptyEventString)
            .ReturnsAsync(Session1String)
            .ReturnsAsync(Session2String)
            .ReturnsAsync(Session3String);
        //Act
        _sut.GetBlobItems();
        var result = await _sut.GetEvents(true);
        //Assert
        Assert.That(2, Is.EqualTo(result.Count));
        Assert.That(1, Is.EqualTo(result[0].Sessions.Count));
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
            It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(8));
    }

    [Test]
    public async Task Given_GetEvents_ErrorsOnGetDataFromStorage_Then_ReturnsEvents()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        var exception = new Exception("There was some error reading from storage");
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).Returns(expectedResult);
        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .Throws(exception);
        //Act
        _sut.GetBlobItems();
        Assert.ThrowsAsync<Exception>(async () => await _sut.GetEvents());
        //Assert
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
            It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(3));
        _logger.Verify(logger => logger.Log(LogLevel.Error, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
            It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
    }

    [Test]
    public async Task Given_CreateEvents_WithSessionData_Then_ReturnsEvents()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).Returns(expectedResult);
        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(EventString)
            .ReturnsAsync(Session1String)
            .ReturnsAsync(Session2String)
            .ReturnsAsync(EmptyEventString)
            .ReturnsAsync(Session3String);
        //Act
        _sut.GetBlobItems();
        await _sut.CreateEvents();
        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(5));
        _storageService.Verify(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(2));
    }
    [Test]
    public void Given_CreateEvents_ThrowsErrorOnWriteStorage_Then_ReturnsEvents()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).Returns(expectedResult);
        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(EventString)
            .ReturnsAsync(Session1String)
            .ReturnsAsync(Session2String)
            .ReturnsAsync(EmptyEventString)
            .ReturnsAsync(Session3String);
        Exception exception = new Exception("There was some error writing to storage");
        _storageService.Setup(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<object>())).Throws(exception);
        //Act
        _sut.GetBlobItems();
        Assert.ThrowsAsync<Exception>(() => _sut.CreateEvents());
        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(5));
        _storageService.Verify(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(1));
    }

    [Test]
    public async Task Given_CreateEventById_Then_ReturnsEvents()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        var eventId = ValidEventId;
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).Returns(expectedResult);
        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(EventString)
            .ReturnsAsync(Session1String)
            .ReturnsAsync(Session2String)
            .ReturnsAsync(EmptyEventString)
            .ReturnsAsync(Session3String);
        //Act
        _sut.GetBlobItems();
        await _sut.CreateEventById(eventId);
        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(5));
        _storageService.Verify(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(1));
    }
    [Test]
    public void Given_CreateEventById_GetEventsReturnsNull_Then_ThrowException()
    {
        //setup
        var eventId = ValidEventId;
        var expectedResult = GetValidBlobItems();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).Returns(expectedResult);
        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync("")
            .ReturnsAsync("")
            .ReturnsAsync("")
            .ReturnsAsync("")
            .ReturnsAsync("");
        Exception exception = new Exception("Event not found");
        _storageService.Setup(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<object>())).Throws(exception);
        //Act
        _sut.GetBlobItems();
        Assert.ThrowsAsync<Exception>(() => _sut.CreateEventById(eventId));
        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(2));
    }
    [Test]
    public void Given_CreateEventById_ThrowsErrorOnWriteStorage_Then_ReturnsEvents()
    {
        //setup
        var eventId = ValidEventId;
        var expectedResult = GetValidBlobItems();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).Returns(expectedResult);
        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(EventString)
            .ReturnsAsync(Session1String)
            .ReturnsAsync(Session2String)
            .ReturnsAsync(EmptyEventString)
            .ReturnsAsync(Session3String);
        var exception = new Exception("There was some error writing to storage");
        _storageService.Setup(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<object>())).Throws(exception);
        //Act
        _sut.GetBlobItems();
        Assert.ThrowsAsync<Exception>(async () => await _sut.CreateEventById(eventId));
        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(5));
        _storageService.Verify(s => s.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(1));
    }

    [Test]
    public async Task Given_GetStaffByEventId_IsCalled_Then_ReturnListOfStaff()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        var eventId = ValidEventId;
        var staffList = expectedResult.Where(s => s.Contains("staff")).ToList();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);

        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(StaffString);
        //Act
        _sut.GetBlobItems();
        var staffResultList = await _sut.GetStaffByEventId(staffList, eventId);

        //Assert
        Assert.That(staffResultList, Has.Count.EqualTo(1));
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(3));
    }
    [Test]
    public void Given_GetStaffByEventId_GetDataFromStorageHasError_Then_LogAndThrowException()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        var eventId = ValidEventId;
        var staffList = expectedResult.Where(s => s.Contains("staff")).ToList();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);
        var exception = new Exception("There was some error reading from storage");
        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .Throws(exception);
        //Act
        _sut.GetBlobItems();
        Assert.ThrowsAsync<Exception>(async () => await _sut.GetStaffByEventId(staffList, eventId));

        //Assert
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(3));
    }

    [Test]
    public async Task Given_SocialMediaPlatformsExists_Then_ReturnsSocialMediaPlatforms()
    {
        //setup
        var expectedResult = ValidSocialMediaPlatforms;
        var expectedResultObject = JsonConvert.DeserializeObject<List<SocialMediaPlatform>>(expectedResult);
        var resultString = ValidSocialMediaPlatforms;
        _storageService.Setup(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()).Result).
            Returns(resultString);
        _storageService.Setup(s => s.BlobExists(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(true);
        //Act
        var result = await _sut.GetSocialMediaPlatforms();

        //Assert

        //Tests to make sure our value in "expectedResult" matches the return result of the System Under Test (SUT)
        for (int i = 0; i < result.Count; i++)
        {
            Assert.That(result[i].Id, Is.EqualTo(expectedResultObject[i].Id));
            Assert.That(result[i].Name, Is.EqualTo(expectedResultObject[i].Name));
            Assert.That(result[i].Icon, Is.EqualTo(expectedResultObject[i].Icon));
        }
        //verifies that we call GetBlobContent once
        _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
        //verifies that we call logger with information once on method entry
        _logger.Verify(
            logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
                It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!),
            Times.Exactly(1));
    }

    [Test]
    public Task Given_SocialMediaPlatformsErrors_Then_LogAndThrowException()
    {
        //setup
        Exception exception = new Exception("There was some error reading from storage");
        _storageService.Setup(s =>
            s.GetDataFromStorage("public", "socialmediaplatforms/socialmediaplatforms.json")).ThrowsAsync(exception);
        _storageService.Setup(s => s.BlobExists(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(true);

        //Act & Assert
        Assert.ThrowsAsync<Exception>(() =>
            _sut.GetSocialMediaPlatforms()
        );
        //verifies that we call GetBlobContent once
        _storageService.Verify(s =>
            s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
        //verifies that we call logger with information once on method entry
        _logger.Verify(logger =>
            logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(),
                ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
        //verifies that we call logger with error on exception
        _logger.Verify(logger => logger.Log(LogLevel.Error, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
            It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
        return Task.CompletedTask;
    }

    [Test]
    public async Task Given_SocialMediaPlatformsDoesNotExist_Then_ReturnsEmptySocialMediaPlatforms()
    {
        //setup
        var expectedResult = ValidSocialMediaPlatforms;
        var expectedResultObject = JsonConvert.DeserializeObject<List<SocialMediaPlatform>>(expectedResult);
        var resultString = ValidSocialMediaPlatforms;
        _storageService.Setup(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()).Result).
            Returns(resultString);
        _storageService.Setup(s => s.BlobExists(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(false);
        //Act
        var result = await _sut.GetSocialMediaPlatforms();

        //Assert

        //Tests to make sure our value in "expectedResult" matches the return result of the System Under Test (SUT)
        for (int i = 0; i < result.Count; i++)
        {
            Assert.That(result[i].Id, Is.EqualTo(expectedResultObject[i].Id));
            Assert.That(result[i].Name, Is.EqualTo(expectedResultObject[i].Name));
            Assert.That(result[i].Icon, Is.EqualTo(expectedResultObject[i].Icon));
        }
        //verifies that we call logger with information once on method entry
        _logger.Verify(
            logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
                It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!),
            Times.Exactly(1));
    }

    [Test]
    public async Task Given_GetSessionFileNames_CallsGetsBlobs_ReturnsList_Then_Log()
    {
        //setup
        var expectedResult = GetValidBlobItems();
        _storageService.Setup(s => s.GetBlobs(It.IsAny<string>())).
            Returns(expectedResult);

        _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
            .ReturnsAsync(Session1String)
            .ReturnsAsync(Session2String)
            .ReturnsAsync(Session3String);

        //Act
        _sut.GetBlobItems();
        var sessionsList = await _sut.GetSessionFileNames();

        //Assert
        Assert.That(sessionsList, Has.Count.EqualTo(3));
        _storageService.Verify(s => s.GetBlobs(It.IsAny<string>()), Times.Exactly(1));
        _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(3));
    }
    // To-Do: Ticket #131: Unit test for throwing an exception is needed

    #region TestData

    private static readonly Guid ValidEventId = Guid.Parse("bce217b0-dc67-40f1-a82f-ffd3cc119e99");
    private static readonly string UpdateEventString = "{\"Id\":\"71358ec6-e186-4556-8ac3-dea90112c7a6\"}";

    private const string Session1String =
        "{\"id\":\"0ce253b1-97f9-40ef-ac52-3c8cbade7c25\",\"title\":\"Cloud Design Patterns\",\"description\":\"With the advent of Kubernetes as the defacto application orchestration tool, it's important the applications are developed with the idioms of the hosting environment in mind. This presentation discusses the problems distributed systems need to solve and how K8S native primitives help solve them.\",\"userId\":\"492d9189-e08e-4d4b-a902-29fad2497d1b\",\"isKeynote\":false,\"videoLink\":null,\"isSelected\":false,\"isWorkshop\":false,\"eventId\":\"71358ec6-e186-4556-8ac3-dea90112c7a6\",\"videoThumbnail\":null}";

    private const string Session2String =
        "{\"id\":\"1b9a6656-7991-4a91-a127-63afc5019d12\",\"title\":\"What C# Programmers Need to Know About Pattern Matching\",\"description\":\"At first glance, C# Pattern Matching just looks like a more powerful switch statement. But upon further investigation, it can dramatically clean up your code. The key is to approach pattern matching with the right mindset.&nbsp;\\n\\nThis session will examine the benefits of C# pattern matching by looking at how some high-profile C# open source projects are using it. It will also look at the ways languages like F#, Elixir, Swift, and Rust benefit from using pattern matching. It will look at some of the exciting new features proposed for C# 8. Lastly, it will talk about how you can improve your code by incorporating pattern matching.\",\"userId\":\"ea7fa209-dfb0-45ee-8fcd-67deb1181034\",\"isKeynote\":false,\"videoLink\":null,\"isSelected\":false,\"isWorkshop\":false,\"eventId\":\"71358ec6-e186-4556-8ac3-dea90112c7a6\",\"videoThumbnail\":null}";

    private const string Session3String =
        "{\"id\":\"6f70015d-46c0-4da3-bbad-adcbbfd07577\",\"title\":\"What The Shell? How Xamarin.Forms Shell will change your life\",\"description\":\"Xamarin.Forms 4 may still be in preview, but the new shell features are INCREDIBLE. Get an introduction to the application architecture, UI patterns, new navigation controls, and lots of great examples. See how to retro-fit your current applications to have a fresh new look.\",\"userId\":\"8ccd973d-6920-42ed-a2c3-aa7cd5a6fe9d\",\"isKeynote\":false,\"videoLink\":null,\"isSelected\":false,\"isWorkshop\":false,\"eventId\":\"bce217b0-dc67-40f1-a82f-ffd3cc119e10\",\"videoThumbnail\":null}";

    private const string User1String =
        "{\"id\":\"0aa3255d-edd6-4260-888e-c50ec5c1e1f4\",\"firstName\":\"Rob\",\"lastName\":\"Zelt\",\"email\":\"robzelt@robzelt.com\",\"biography\":\"Rob is a Principal Software ngineer at University of North Carolina at Chapel Hill. With a strong background in web, mobile and cloud technologies he enjoys applying his experience to increasing productivity and providing solutions to challenging problems. He&#39;s a 5 year Microsoft MVP award recipient, ASP Insider and active participant and speaker in the software development community\",\"pictureLink\":null,\"presentationSessions\":[\"cb607d26-065f-430f-a8e5-091e5534be9c\"]}";

    private const string User2String =
        "{\"id\":\"0aa3255d-edd6-4260-888e-c50ec5c1e1f5\",\"firstName\":\"Rob\",\"lastName\":\"Zelt\",\"email\":\"robzelt@robzelt.com\",\"biography\":\"Rob is a Principal Software Engineer at University of North Carolina at Chapel Hill. With a strong background in web, mobile and cloud technologies he enjoys applying his experience to increasing productivity and providing solutions to challenging problems. He&#39;s a 5 year Microsoft MVP award recipient, ASP Insider and active participant and speaker in the software development community\",\"pictureLink\":null,\"presentationSessions\":[]}";

    private const string StaffString =
        "{\"id\":\"0ec5a72d-c972-4a35-a0c9-7284bff10166\",\"userId\":\"0aa3255d-edd6-4260-888e-c50ec5c1e1f4\",\"eventId\":\"bce217b0-dc67-40f1-a82f-ffd3cc119e99\",\"position\":\"Organizer\"}";

    private const string Staff2String =
        "{\"id\":\"0ec5a72d-c972-4a35-a0c9-7284bff10177\",\"userId\":\"0aa3255d-edd6-4260-888e-c50ec5c1e1f4\",\"eventId\":\"113f8c47-6256-4f14-bb99-e91e0e2319a9\",\"position\":\"Organizer\"}";

    private const string EventString =
        "{\"id\":\"bce217b0-dc67-40f1-a82f-ffd3cc119e99\",\"name\":\"2019\",\"startDate\":\"2019-05-11T07:00:00\",\"endDate\":\"2019-05-11T07:00:00\",\"status\":2,\"address1\":\"7900 Division St\",\"address2\":null,\"city\":\"River Forest\",\"state\":\"IL\",\"zip\":\"60305\",\"locationDescription\":\"Entrance to the main event\",\"keynoteSelected\":true,\"sessionsSelected\":true,\"year\":2019}";

    private const string Event2String =
        "{\"id\":\"bce217b0-dc67-40f1-a82f-ffd3cc119e10\",\"name\":\"2019\",\"startDate\":\"2019-05-11T07:00:00\",\"endDate\":\"2019-05-11T07:00:00\",\"status\":2,\"address1\":\"7900 Division St\",\"address2\":null,\"city\":\"River Forest\",\"state\":\"IL\",\"zip\":\"60305\",\"locationDescription\":\"Entrance to the main event\",\"keynoteSelected\":true,\"sessionsSelected\":true,\"year\":2019}";

    private static readonly string EmptyEventString = string.Empty;
    public static readonly string EmptyEventIdString = "{\"id\":null}";
    private static readonly string ValidPrivacyPolicy = "Some Privacy Policy";
    private static readonly string ValidCodeOfConduct = "Some Code of Conduct";
    private static readonly string ConferenceInfoString = "{\r\n    \"id\": \"4ab18025-dd35-4438-877d-e9e800f10610\",\r\n    \"name\": \"Windy City Conference\",\r\n    \"address1\": \"7900 Division St\",\r\n    \"address2\": null,\r\n    \"city\": \"River Forest\",\r\n    \"state\": \"IL\",\r\n    \"zip\": \"60305\",\r\n    \"email\":\"contactus@windycityconference.com\",\r\n    \"description\": \"<p>The Windy City Conference is a one-day event that brings together the best and brightest in the tech industry for a day of learning, networking, and sharing. The conference is organized by the Chicago .NET User Group and is a not-for-profit event. All proceeds go to the Chicago .NET User Group, a 501c3 non-profit organization.</p>\",  \r\n    \"phone\": \"555-555-5555\",\r\n    \"image\":\"../../assets/jumbotron.svg\",\r\n    \"missionStatement\": \" <h2 className='aboutHeaders'>The Mission</h2><p>The mission of Windy City Conference is to provide a credible resource within the IT industry:<br></br> to <span className='aboutBold'>learn</span> about advancements in our field,<br></br> to <span className='aboutBold'>share</span> knowledge from our experiences, and<br></br> to <span className='aboutBold'>develop</span> valued relationships with ourpeers </p>\",\r\n    \"locationHeader\": \"<h2 className='aboutHeaders'>Location</h2>\",\r\n    \"miscInfo\": \"<h2 className='aboutHeaders'>What We Offer For You</h2><p>As a day-long event, we are here to connect the talent and expertise within the Developer community of the Windy City. Discussions for the day have previously included development and trending topics in .net, java, open sourced frameworks, web, mobile, cloud, robotics, testing, soft skills, and more.</p><h2 className='aboutHeaders'>Why Windy City Conference?</h2><p>We are still the same conference that was started 12 years ago. The same spirit and urge to learn has never went away. Infact, the hunger for knowledge and sharing of information has increase for every one of our organizers, volunteers, speakers, and attendees.</p><p>In order to accomodate more diverge technologies and offerings, the organizers decided to re-brand the Chicago Code Camp as Windy City Conference. We are still paying tribute to the code camp that started it all and looking forward to bigger and better conference for everyone!</p>\",\r\n    \"staffDescription\": \"The Windy City Conference is organized by the Chicago .NET User Group. The conference is run by a team of volunteers who are passionate about the local tech community.\"\r\n  }\r\n";
    private static readonly UpdateEventDto? UpdateEvent = JsonConvert.DeserializeObject<UpdateEventDto>(UpdateEventString);

    private List<string> GetValidBlobItems()
    {
        List<string> result =
        [
            "users/60995f39-8857-4c99-8a89-7a91977b4790/60995f39-8857-4c99-8a89-7a91977b4790.json",
            "users/2d512b99-f94d-4b69-a824-947c7edc692e/2d512b99-f94d-4b69-a824-947c7edc692e.json",
            "events/bce217b0-dc67-40f1-a82f-ffd3cc119e99/bce217b0-dc67-40f1-a82f-ffd3cc119e99.json",
            "events/113f8c47-6256-4f14-bb99-e91e0e2319a9/113f8c47-6256-4f14-bb99-e91e0e2319a9.json",
            "events/bce217b0-dc67-40f1-a82f-ffd3cc119e99/sessions/1ca2d0de-02b2-4044-ab83-ebbb9a0fa454.json",
            "events/bce217b0-dc67-40f1-a82f-ffd3cc119e99/sessions/1d1b4ce1-3f13-49fd-a473-b3bf2e56236c.json",
            "events/bce217b0-dc67-40f1-a82f-ffd3cc119e99/staff/0aa3255d-edd6-4260-888e-c50ec5c1e1f4.json",
            "events/113f8c47-6256-4f14-bb99-e91e0e2319a9/sessions/28d8179b-a266-47e7-88e9-9d8113dfe3dd.json"
        ];
        return result;
    }

    private const string ValidSocialMediaPlatforms = "[\r\n{\r\n\"Id\" :\"e4b6ad76-60da-4f2b-bef9-a47b18daead4\",\r\n        \"Name\" : \"Twitter\",\r\n        \"Icon\" : \"fa-twitter-square\"\r\n    },\r\n    {\r\n        \"Id\" :\"0db5ddac-1c4e-4cb9-a510-1fc003922861\",\r\n        \"Name\" : \"LinkedIn\",\r\n        \"Icon\" : \"fa-linkedin-square\"\r\n    }\r\n]";
    private const string ValidEvents = "[\r\n {\r\n \"Id\" :\"f0f4e7ca-8840-4904-8fe2-4772d839ccbc\",\r\n \"Name\" : \"July's Presenter\",\r\n\"StartDate\" : \"2020-07-11T21:00:00\",\r\n\"EndDate\" : \"2020-07-11T21:00:00\",\r\n\"Status\" : \"1\",\r\n\"Address1\" : null,\r\n\"Address2\" : null,\r\n\"City\" : null,\r\n\"State\" : null,\r\n\"Zip\" : null,\r\n\"LocationDescription\" : null,\r\n\"KeynoteSelected\" : false,\r\n\"SessionsSelected\" : false,\r\n\"Year\" : \"2020\"\r\n},\r\n{\r\n\"Id\" :\"edda02e9-2579-4f55-a84a-e2c446deae43\",\r\n\"Name\" : \"Nov 21\",\r\n\"StartDate\" : \"2021-11-12T12:00:00\",\r\n\"EndDate\" : \"2021-11-12T12:00:00\",\r\n\"Status\" : \"1\",\r\n\"Address1\" : null,\r\n\"Address2\" : null,\r\n\"City\" : null,\r\n\"State\" : null,\r\n\"Zip\" : null,\r\n\"LocationDescription\" : null,\r\n\"KeynoteSelected\" : false,\r\n\"SessionsSelected\" : true,\r\n\"Year\" : \"2021\"\r\n}\r\n]";
    private const string StringValidEventId = "f0f4e7ca-8840-4904-8fe2-4772d839ccbc";
    #endregion
}
