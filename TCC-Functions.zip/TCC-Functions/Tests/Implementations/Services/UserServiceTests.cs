﻿using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using System.Text;
using System.Text.Json;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Interfaces;
using TCC.Functions.Model;
using static System.Reflection.Metadata.BlobBuilder;


namespace TCC.Functions.Tests.Implementations.Services
{
    public class UserServiceTests
    {
        private Mock<ILogger<UserService>> _logger = null!;
        private Mock<IStorageService> _storageService = null!;
        private Mock<IPublicDataService> _publicDataService;
        private UserService _sut = null!;
        private PublicDataService _sutPDS = null!;
        private Mock<IHttpWebRequestService> _httpWebRequestServiceMock;

        [SetUp]
        public void SetUp()
        {
            _logger = new Mock<ILogger<UserService>>();
            _storageService = new Mock<IStorageService>();
            _publicDataService = new Mock<IPublicDataService>();
            _httpWebRequestServiceMock = new Mock<IHttpWebRequestService>();
            _sut = new UserService(_storageService.Object, _logger.Object, _publicDataService.Object, _httpWebRequestServiceMock.Object);

        }

        [Test]
        public async Task SaveUser_WithValidContent_CallWriteObjectToBlobContent()
        {

            var user = GetUserDTO();
            var expectedData = Encoding.UTF8.GetBytes(System.Text.Json.JsonSerializer.Serialize(user));

            _storageService.Setup(s => s.GetBlobContent("public", It.IsAny<string>())).ReturnsAsync(expectedData);
            _storageService.Setup(x => x.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<User>())).Returns(Task.CompletedTask);

            await _sut.SaveUser(user, user.Id, "saved");

            //assert
            _storageService.Verify(
             x => x.WriteObjectToBlobContent("public", It.IsAny<string>(), It.IsAny<User>()), Times.Exactly(1));

            byte[] actualData = await _storageService.Object.GetBlobContent("public", It.IsAny<string>());
            string actualJson = Encoding.UTF8.GetString(actualData);
            var actualContactUsDto = System.Text.Json.JsonSerializer.Deserialize<UserDTO>(actualJson);
            var expectedJson = System.Text.Json.JsonSerializer.Serialize(user);

            Assert.That(actualJson, Is.EqualTo(expectedJson));

            // Assert that the expected UserDTO object matches the actual UserDTO object.
            Assert.That(actualContactUsDto.Id, Is.EqualTo(user.Id));
            Assert.That(actualContactUsDto.FirstName, Is.EqualTo(user.FirstName));
            Assert.That(actualContactUsDto.LastName, Is.EqualTo(user.LastName));
            Assert.That(actualContactUsDto.Email, Is.EqualTo(user.Email));
            Assert.That(actualContactUsDto.PictureLink, Is.EqualTo(user.PictureLink));
            Assert.That(actualContactUsDto.Biography, Is.EqualTo(user.Biography));
            Assert.That(actualContactUsDto.PresentationSessions, Is.EqualTo(user.PresentationSessions));
        }

        [Test]
        public async Task SaveUser_WithNopictureLink_CallWriteObjectToBlobContent()
        {

            var user = GetUserDTONoPictureLink();
            var expctedData = Encoding.UTF8.GetBytes(System.Text.Json.JsonSerializer.Serialize(user));

            _storageService.Setup(s => s.GetBlobContent("public", It.IsAny<string>())).ReturnsAsync(expctedData);
            _storageService.Setup(x => x.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<User>())).Returns(Task.CompletedTask);

            await _sut.SaveUser(user, user.Id, "saved");

            //assert
            _storageService.Verify(
             x => x.WriteObjectToBlobContent("public", It.IsAny<string>(), It.IsAny<User>()), Times.Exactly(1));

            byte[] actualData = await _storageService.Object.GetBlobContent("public", It.IsAny<string>());
            string actualJson = Encoding.UTF8.GetString(actualData);
            var actualContactUsDto = System.Text.Json.JsonSerializer.Deserialize<UserDTO>(actualJson);
            var expectedJson = System.Text.Json.JsonSerializer.Serialize(user);

            Assert.That(actualJson, Is.EqualTo(expectedJson));

            // Assert that the expected UserDTO object matches the actual UserDTO object.
            Assert.That(actualContactUsDto.Id, Is.EqualTo(user.Id));
            Assert.That(actualContactUsDto.FirstName, Is.EqualTo(user.FirstName));
            Assert.That(actualContactUsDto.LastName, Is.EqualTo(user.LastName));
            Assert.That(actualContactUsDto.Email, Is.EqualTo(user.Email));
            Assert.That(actualContactUsDto.PictureLink, Is.EqualTo(user.PictureLink));
            Assert.That(actualContactUsDto.Biography, Is.EqualTo(user.Biography));
            Assert.That(actualContactUsDto.PresentationSessions, Is.EqualTo(user.PresentationSessions));
        }

        [Test]
        public void SaveUser_WhenWriteObjectToBlobContentThrowsException_LogsErrorandThrows()
        {
            var user = GetUserDTO();
            var exception = new Exception("WriteBlobContent error");
            _storageService.Setup(x => x.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<User>())).ThrowsAsync(exception);

            // Act & Assert
            Assert.ThrowsAsync<Exception>(() => _sut.SaveUser(user, user.Id, "saved"));
            _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));

        }

        [Test]
        public async Task SaveUserSocialMedia_WithValidContent_CallWriteObjectToBlobContent()
        {
            // Arrange
            var socialMediaDTOs = GetUserSocialMediaDTO(); // Get social media DTOs from the user DTO
            var userId = Guid.NewGuid();
            var operationPerformed = "saved";

            _storageService.Setup(x => x.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<UserSocialMedia>>())).Returns(Task.CompletedTask);

            // Act
            await _sut.SaveUserSocialMedia(socialMediaDTOs, userId, operationPerformed);

            // Assert
            _storageService.Verify(
                x => x.WriteObjectToBlobContent("public", It.IsAny<string>(), It.IsAny<List<UserSocialMedia>>()), Times.Exactly(1));
        }

        [Test]
        public async Task SaveUserSocialMedia_WithNullSocialMediaDtO_CallWriteObjectToBlobContent()
        {
            // Arrange
            var userSocialMedia = GetNullUserSocialMediaDTO();
            var userId = Guid.NewGuid();

            _storageService.Setup(x => x.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<UserSocialMedia>>())).Returns(Task.CompletedTask);

            // Act
            await _sut.SaveUserSocialMedia(userSocialMedia, userId, "saved");

            // Assert
            _storageService.Verify(
                x => x.WriteObjectToBlobContent("public", It.IsAny<string>(), It.IsAny<List<UserSocialMedia>>()), Times.Exactly(1));

        }


        [Test]
        public async Task SaveUserSocialMedia_NewSocialMedia_CallWriteObjectToBlobContent()
        {
            // Arrange
            var userSocialMedia = GetNewUserSocialMediaDTO();
            var userId = Guid.NewGuid();
            _storageService.Setup(x => x.WriteObjectToBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<UserSocialMedia>>())).Returns(Task.CompletedTask);

            // Act
            await _sut.SaveUserSocialMedia(userSocialMedia, userId, "saved");

            // Assert
            _storageService.Verify(
                x => x.WriteObjectToBlobContent("public", It.IsAny<string>(), It.IsAny<List<UserSocialMedia>>()), Times.Exactly(1));
        }


        [Test]
        public void SaveUserSocialMedia_WhenWriteObjectToBlobContentThrowsException_LogsErrorandThrows()
        {
            // Arrange
            var socialMediaDTOs = GetUserSocialMediaDTO(); // Get social media DTOs from the user DTO
            var userId = Guid.NewGuid();

            var exception = new Exception("WriteBlobContent error");
            _storageService.Setup(x => x.WriteObjectToBlobContent("public", It.IsAny<string>(), It.IsAny<List<UserSocialMedia>>())).ThrowsAsync(exception);

            // Act & Assert
            Assert.ThrowsAsync<Exception>(() => _sut.SaveUserSocialMedia(socialMediaDTOs, userId, "saved"));
            _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));

        }

        [Test]
        public async Task DeleteUserSocialMedia_WithValidPath_DeletesFileAndLogsInformation()
        {
            // Arrange
            string socialMediaPath = "users/25b2fd9c-2b51-472a-8e1a-695f74e8beb2/socialmedia/25b2fd9c-2b51-472a-8e1a-695f74e8beb2.json";

            // Act
            await _sut.DeleteUserSocialMedia(socialMediaPath);

            // Assert
            _storageService.Verify(
                service => service.DeleteFileByPath("public", socialMediaPath),
                Times.Once);
            _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));

        }

        [Test]
        public async Task UserInfo_WithValidContent_ReturnsUserInfo()
        {
            //setup
            var expectedResultString = ValidUser;
            var expectedResultUser = JsonConvert.DeserializeObject<User>(expectedResultString);
            var id = ValidUserId;
            var resultUser = ValidUser;
            _storageService.Setup(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()).Result).
                Returns(resultUser);

            //Act
            var result = await _sut.GetUser(id);
            //Assert
            //Tests to make sure our value in "expectedResult" matches the return result of the System Under Test (SUT)
            Assert.That(result.Id, Is.EqualTo(expectedResultUser.Id));
            Assert.That(result.FirstName, Is.EqualTo(expectedResultUser.FirstName));
            Assert.That(result.LastName, Is.EqualTo(expectedResultUser.LastName));
            Assert.That(result.Biography, Is.EqualTo(expectedResultUser.Biography));
            Assert.That(result.Email, Is.EqualTo(expectedResultUser.Email));
            Assert.That(result.PictureLink, Is.EqualTo(expectedResultUser.PictureLink));
            for (int i = 0; i < result.PresentationSessions.Count; i++)
            {
                Assert.That(result.PresentationSessions[i], Is.EqualTo(expectedResultUser.PresentationSessions[i]));
            }
            //verifies that we call GetBlobContent once
            _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
            //verifies that we call logger with information once on method entry
            _logger.Verify(
                logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
                    It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!),
                Times.Exactly(1));
        }

        [Test]
        public Task Given_UserDoesNotExist_Then_LogAndThrowException()
        {
            //setup
            var id = ValidUserId;
            string path = "users/" + id.ToString() + "/" + id.ToString() + ".json";
            Exception exception = new Exception("There was some error reading from storage");
            _storageService.Setup(s =>
                s.GetDataFromStorage("public", path)).ThrowsAsync(exception);
            //Act & Assert
            Assert.ThrowsAsync<Exception>(() =>
                _sut.GetUser(id)
            );
            //verifies that we call GetBlobContent once
            _storageService.Verify(s =>
                s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
            //verifies that we call logger with information once on method entry
            _logger.Verify(logger =>
                logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(),
                    ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
            //verifies that we call logger with error on exception
            _logger.Verify(logger => logger.Log(LogLevel.Error, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
                It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
            return Task.CompletedTask;
        }

        [Test]
        public async Task UserSocialMedia_WithValidContent_ReturnsUserSocialMedia()
        {
            //setup
            var expectedResultString = ValidUserSocialMedia;
            var expectedResultUserSocialMedia = JsonConvert.DeserializeObject<List<UserSocialMedia>>(expectedResultString);
            var id = ValidUserId;
            var resultUserSocialMedia = ValidUserSocialMedia;
            _storageService.Setup(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()).Result).
                Returns(resultUserSocialMedia);
            _storageService.Setup(s => s.BlobExists(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(true);

            //Act
            var result = await _sut.GetUserSocialMedia(id);
            //Assert
            //Tests to make sure our value in "expectedResult" matches the return result of the System Under Test (SUT)
            for (int i = 0; i < result.Count; i++)
            {
                Assert.That(result[i].Id, Is.EqualTo(expectedResultUserSocialMedia[i].Id));
                Assert.That(result[i].Link, Is.EqualTo(expectedResultUserSocialMedia[i].Link));
                Assert.That(result[i].SocialMediaPlatformId, Is.EqualTo(expectedResultUserSocialMedia[i].SocialMediaPlatformId));
                Assert.That(result[i].UserId, Is.EqualTo(expectedResultUserSocialMedia[i].UserId));
            }
            //verifies that we call GetBlobContent once
            _storageService.Verify(s => s.BlobExists(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
            _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
            //verifies that we call logger with information once on method entry
            _logger.Verify(
                logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
                    It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!),
                Times.Exactly(1));
        }

        [Test]
        public async Task Given_UserSocialMediaDoesNotExist_Then_ReturnEmptyList()
        {
            //setup
            var expectedResultString = ValidUserSocialMedia;
            var expectedResultUserSocialMedia = JsonConvert.DeserializeObject<List<UserSocialMedia>>(expectedResultString);
            var id = ValidUserId;
            var resultUserSocialMedia = ValidUserSocialMedia;
            _storageService.Setup(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()).Result).
                Returns(resultUserSocialMedia);
            _storageService.Setup(s => s.BlobExists(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(false);

            //Act
            var result = await _sut.GetUserSocialMedia(id);
            //Assert
            //Tests to make sure our value in "expectedResult" matches the return result of the System Under Test (SUT)
            for (int i = 0; i < result.Count; i++)
            {
                Assert.That(result[i].Id, Is.EqualTo(expectedResultUserSocialMedia[i].Id));
                Assert.That(result[i].Link, Is.EqualTo(expectedResultUserSocialMedia[i].Link));
                Assert.That(result[i].SocialMediaPlatformId, Is.EqualTo(expectedResultUserSocialMedia[i].SocialMediaPlatformId));
                Assert.That(result[i].UserId, Is.EqualTo(expectedResultUserSocialMedia[i].UserId));
            }
            //verifies that we call GetBlobContent once
            _storageService.Verify(s => s.BlobExists(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
            //verifies that we call logger with information once on method entry
            _logger.Verify(
                logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
                    It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!),
                Times.Exactly(1));
        }

        [Test]
        public Task Given_UserSocialMediaFailsToRead_Then_LogAndThrowException()
        {
            //setup
            var id = ValidUserId;
            string path = "users/" + id.ToString() + "/socialmedia/" + id.ToString() + ".json";
            Exception exception = new Exception("There was some error reading from storage");
            _storageService.Setup(s => s.GetDataFromStorage("public", path)).ThrowsAsync(exception);
            _storageService.Setup(s => s.BlobExists(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(true);
            //Act & Assert
            Assert.ThrowsAsync<Exception>(() =>
                _sut.GetUserSocialMedia(id)
            );
            //verifies that we call GetBlobContent once
            _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
            _storageService.Verify(s => s.BlobExists(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));

            //verifies that we call logger with information once on method entry
            _logger.Verify(logger =>
                logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(),
                    ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
            //verifies that we call logger with error on exception
            _logger.Verify(logger => logger.Log(LogLevel.Error, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
                It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
            return Task.CompletedTask;
        }

        [Test]
        public async Task UserDtoInfo_WithValidContent_ReturnsUserInfoDto()
        {
            //setup
            var expectedResultString = ValidUserDTO;
            var expectedUserDto = JsonConvert.DeserializeObject<UserDTO>(expectedResultString);
            var resultUserDto = ValidUserDTO;
            var resultUser = ValidUser;
            var resultUserSocialMedia = ValidUserSocialMedia;
            var socialMediaPlatforms = JsonConvert.DeserializeObject<List<SocialMediaPlatform>>(ValidSocialMediaPlatforms);
            _storageService.SetupSequence(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()).Result).
                Returns(resultUser).Returns(resultUserSocialMedia);
            _publicDataService.Setup(s => s.GetSocialMediaPlatforms()).ReturnsAsync(socialMediaPlatforms);
            _storageService.Setup(s => s.BlobExists(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(true);
            //Act
            var result = await _sut.GetUserDTO(ValidUserId);

            //Assert

            //Tests to make sure our value in "expectedResult" matches the return result of the System Under Test (SUT)
            Assert.That(result.Id, Is.EqualTo(expectedUserDto.Id));
            Assert.That(result.FirstName, Is.EqualTo(expectedUserDto.FirstName));
            Assert.That(result.LastName, Is.EqualTo(expectedUserDto.LastName));
            Assert.That(result.Biography, Is.EqualTo(expectedUserDto.Biography));
            Assert.That(result.PictureLink, Is.EqualTo(expectedUserDto.PictureLink));
            Assert.That(result.Email, Is.EqualTo(expectedUserDto.Email));
            for (int i = 0; i < result.PresentationSessions.Count; i++)
            {
                Assert.That(result.PresentationSessions[i], Is.EqualTo(expectedUserDto.PresentationSessions[i]));
            }
            for (int i = 0; i < result.SocialMediaLinks.Count; i++)
            {
                Assert.That(result.SocialMediaLinks[i].SocialMediaLink, Is.EqualTo(expectedUserDto.SocialMediaLinks[i].SocialMediaLink));
                Assert.That(result.SocialMediaLinks[i].SocialMediaPlatformId, Is.EqualTo(expectedUserDto.SocialMediaLinks[i].SocialMediaPlatformId));
                Assert.That(result.SocialMediaLinks[i].UserId, Is.EqualTo(expectedUserDto.SocialMediaLinks[i].UserId));
                Assert.That(result.SocialMediaLinks[i].UserSocialMediaId, Is.EqualTo(expectedUserDto.SocialMediaLinks[i].UserSocialMediaId));
            }

            //verifies that we call GetBlobContent once
            _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(2));
            _publicDataService.Verify(s => s.GetSocialMediaPlatforms(), Times.Exactly(1));
            _storageService.Verify(s => s.BlobExists(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
            //verifies that we call logger with information once on method entry
            _logger.Verify(
                logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
                    It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!),
                Times.Exactly(3));
        }

        [Test]
        public Task Given_UserDtoMediaDoesNotExist_Then_LogAndThrowException()
        {
            //setup
            var userSocialMediaResultString = ValidUserSocialMedia;
            var expectedResultUserSocialMedia = JsonConvert.DeserializeObject<List<UserSocialMedia>>(userSocialMediaResultString);
            var userResultString = ValidUser;
            var expectedResultUser = JsonConvert.DeserializeObject<User>(userResultString);
            var socialMediaPlatforms = JsonConvert.DeserializeObject<List<SocialMediaPlatform>>(ValidSocialMediaPlatforms);
            Exception exception = new Exception("There was some error reading from storage");
            _storageService.SetupSequence(s =>
                s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()).Result).Returns(userResultString).Returns(userSocialMediaResultString).Throws(exception);
            _publicDataService.SetupSequence(s => s.GetSocialMediaPlatforms()).Throws(exception);
            _storageService.Setup(s => s.BlobExists(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(true);
            //Act & Assert
            Assert.ThrowsAsync<Exception>(() =>
                _sut.GetUserDTO(ValidUserId)
            );
            //verifies that we call GetBlobContent once
            _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(2));
            _publicDataService.Verify(s => s.GetSocialMediaPlatforms(), Times.Exactly(1));
            _storageService.Verify(s => s.BlobExists(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
            //verifies that we call logger with information once on method entry
            _logger.Verify(logger =>
                logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(),
                    ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(2));
            //verifies that we call logger with error on exception
            _logger.Verify(logger => logger.Log(LogLevel.Error, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(),
                It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
            return Task.CompletedTask;
        }

        //Start of Post User Sessions Unit Test
        [Test]
        public async Task UpdateUserSessions_NewUserSession_WithWorkshopAllowed_anWorkshopSubmited_Success()
        {
            // Arrange
            var sessionDto = GetNewUserSessionWithWorkshopDto();
            var sessionId = Guid.NewGuid();
            var operationPerformed = "NewUserSession";
            var userId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"); // Assuming userId is a string

            var currentUserJson = "{\"Id\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"FirstName\":\"Min\",\"LastName\":\"Maung\",\"Email\":\"min@maungs.com\",\"Biography\":\"Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.\",\"PictureLink\":\"http://www.gravatar.com/avatar/099173ab96424339e82de5ad2b447ed3?s=250&&r=G\",\"PresentationSessions\":[\"a8292a14-3f7b-4fef-b0a5-27584cc6fa96\",\"26dcb903-1bb0-4551-85fe-163736bdf80d\",\"7acff94c-dbf4-44c1-bd4b-e887b8dd01f8\",\"c98a89be-f6dd-4a98-bbdf-52924dbb4410\",\"90355858-9a37-4d15-9b74-e8c1a8a230b2\",\"7b6b2037-9146-4f9e-ae4c-6771fe1995a7\",\"a10967b6-e307-4759-a36b-98c2c2fc2f90\",\"2418db21-7944-49fc-b4f3-68948e9ef0f9\",\"1eeff8a5-3aaa-4080-bcd7-d447ec7465b5\",\"d7544eb6-816c-47f5-aabf-81970d3850fd\",\"3abc5b89-3c6e-49e1-990f-53f986e0ad37\",\"d40f0b15-8466-45bc-8b0a-f0d21f7b44f9\",\"b77d5f01-05ae-4fb8-8c78-ac36376c451c\",\"290be8fc-7e43-4b23-854f-d82da875a3b6\",\"a970b9e5-8996-4ad7-a38b-93943d7bfe15\",\"f1ef4255-1829-424c-857b-085d039822cf\",\"9fe7ced4-365a-4c95-9158-248a3ccaf592\",\"c65730c6-379a-4569-a749-3a12786b50fd\",\"1305c920-7c7c-4c18-9900-247cc67395aa\",\"ba46b2ec-07d0-4083-a0ac-60c1580403a6\",\"c06e43dd-eb8f-4525-a5f2-59b883b34c08\",\"80d86fff-e37d-4a23-a8d2-36cb0357cfe5\",\"78047456-a74c-4d5d-8159-3a03b4ff475a\",\"b33e4d0a-7ce8-4dcb-a9ef-4ae56cf1dfdd\",\"e6b02251-a533-4871-a1e9-72a7c21087fb\",\"f693f1a0-6afe-4354-8b41-72752dce6f1f\",\"9116ef0d-8d4b-46e7-af33-f8f1e16b9233\"]}";
            var currentEventJson = "{\"Id\":\"01446bd5-464d-4c3c-a403-36f829d22a97\",\"Name\":\"Open Talk - June '21\",\"StartDate\":\"2021-06-14T12:00:00\",\"EndDate\":\"2021-06-14T12:00:00\",\"Status\":1,\"Address1\":null,\"Address2\":null,\"City\":null,\"State\":null,\"Zip\":null,\"LocationDescription\":null,\"KeynoteSelected\":false,\"CallForSpeakerOpen\":true,\"IsWorkshopSessionAllowed\":true,\"SessionsSelected\":true,\"Year\":2021}";


            _storageService.Setup(x => x.GetDataFromStorage("public", It.IsAny<string>()))
                               .ReturnsAsync((string container, string path) =>
                               {
                                   if (path.Contains("users"))
                                       return currentUserJson;
                                   else if (path.Contains("events"))
                                       return currentEventJson;
                                   else
                                       return null;
                               });

            // Act
            await _sut.UpdateUserSessions(sessionDto, sessionId, operationPerformed);

            // Assert
            // Add assertions here to verify the expected behavior
            // Verify that WriteObjectToBlobContent is called with the correct parameters
            _storageService.Verify(x => x.WriteObjectToBlobContent("public", It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(2));
            // Verify that GetUser is called to retrieve the current user data
            _storageService.Verify(x => x.GetDataFromStorage("public", $"users/{userId}/{userId}.json"), Times.Once);
            // Verify that GetDataFromStorage is called to retrieve the current event data
            _storageService.Verify(x => x.GetDataFromStorage("public", $"events/{sessionDto.EventId}/{sessionDto.EventId}.json"), Times.Once);
        }
        [Test]
        public async Task UpdateUserSessions_NewUserSession_WithNoWorkshopAllowed_AndNoWorkshopSubmited_Success()
        {
            // Arrange
            var sessionDto = GetNewUserSessionDto();
            var sessionId = Guid.NewGuid();
            var operationPerformed = "NewUserSession";
            var userId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"); // Assuming userId is a string

            var currentUserJson = "{\"Id\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"FirstName\":\"Min\",\"LastName\":\"Maung\",\"Email\":\"min@maungs.com\",\"Biography\":\"Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.\",\"PictureLink\":\"http://www.gravatar.com/avatar/099173ab96424339e82de5ad2b447ed3?s=250&&r=G\",\"PresentationSessions\":[\"a8292a14-3f7b-4fef-b0a5-27584cc6fa96\",\"26dcb903-1bb0-4551-85fe-163736bdf80d\",\"7acff94c-dbf4-44c1-bd4b-e887b8dd01f8\",\"c98a89be-f6dd-4a98-bbdf-52924dbb4410\",\"90355858-9a37-4d15-9b74-e8c1a8a230b2\",\"7b6b2037-9146-4f9e-ae4c-6771fe1995a7\",\"a10967b6-e307-4759-a36b-98c2c2fc2f90\",\"2418db21-7944-49fc-b4f3-68948e9ef0f9\",\"1eeff8a5-3aaa-4080-bcd7-d447ec7465b5\",\"d7544eb6-816c-47f5-aabf-81970d3850fd\",\"3abc5b89-3c6e-49e1-990f-53f986e0ad37\",\"d40f0b15-8466-45bc-8b0a-f0d21f7b44f9\",\"b77d5f01-05ae-4fb8-8c78-ac36376c451c\",\"290be8fc-7e43-4b23-854f-d82da875a3b6\",\"a970b9e5-8996-4ad7-a38b-93943d7bfe15\",\"f1ef4255-1829-424c-857b-085d039822cf\",\"9fe7ced4-365a-4c95-9158-248a3ccaf592\",\"c65730c6-379a-4569-a749-3a12786b50fd\",\"1305c920-7c7c-4c18-9900-247cc67395aa\",\"ba46b2ec-07d0-4083-a0ac-60c1580403a6\",\"c06e43dd-eb8f-4525-a5f2-59b883b34c08\",\"80d86fff-e37d-4a23-a8d2-36cb0357cfe5\",\"78047456-a74c-4d5d-8159-3a03b4ff475a\",\"b33e4d0a-7ce8-4dcb-a9ef-4ae56cf1dfdd\",\"e6b02251-a533-4871-a1e9-72a7c21087fb\",\"f693f1a0-6afe-4354-8b41-72752dce6f1f\",\"9116ef0d-8d4b-46e7-af33-f8f1e16b9233\"]}";
            var currentEventJson = "{\"Id\":\"01446bd5-464d-4c3c-a403-36f829d22a97\",\"Name\":\"Open Talk - June '21\",\"StartDate\":\"2021-06-14T12:00:00\",\"EndDate\":\"2021-06-14T12:00:00\",\"Status\":1,\"Address1\":null,\"Address2\":null,\"City\":null,\"State\":null,\"Zip\":null,\"LocationDescription\":null,\"KeynoteSelected\":false,\"CallForSpeakerOpen\":true,\"IsWorkshopSessionAllowed\":false,\"SessionsSelected\":true,\"Year\":2021}";


            _storageService.Setup(x => x.GetDataFromStorage("public", It.IsAny<string>()))
                               .ReturnsAsync((string container, string path) =>
                               {
                                   if (path.Contains("users"))
                                       return currentUserJson;
                                   else if (path.Contains("events"))
                                       return currentEventJson;
                                   else
                                       return null;
                               });

            // Act
            await _sut.UpdateUserSessions(sessionDto, sessionId, operationPerformed);

            // Assert
            // Add assertions here to verify the expected behavior
            // Verify that WriteObjectToBlobContent is called with the correct parameters
            _storageService.Verify(x => x.WriteObjectToBlobContent("public", It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(2));
            // Verify that GetUser is called to retrieve the current user data
            _storageService.Verify(x => x.GetDataFromStorage("public", $"users/{userId}/{userId}.json"), Times.Once);
            // Verify that GetDataFromStorage is called to retrieve the current event data
            _storageService.Verify(x => x.GetDataFromStorage("public", $"events/{sessionDto.EventId}/{sessionDto.EventId}.json"), Times.Once);
        }

        [Test]
        public async Task UpdateUserSessions_NewUserSession_WithWorkshopAllowed_WithUserSessionListNull_Success()
        {
            // Arrange
            var sessionDto = GetNewUserSessionDto();
            var sessionId = Guid.NewGuid();
            var operationPerformed = "NewUserSession";
            var userId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"); // Assuming userId is a string

            var currentUserJson = "{\"Id\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"FirstName\":\"Min\",\"LastName\":\"Maung\",\"Email\":\"min@maungs.com\",\"Biography\":\"Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.\",\"PictureLink\":\"http://www.gravatar.com/avatar/099173ab96424339e82de5ad2b447ed3?s=250&&r=G\",\"PresentationSessions\":null}";
            var currentEventJson = "{\"Id\":\"01446bd5-464d-4c3c-a403-36f829d22a97\",\"Name\":\"Open Talk - June '21\",\"StartDate\":\"2021-06-14T12:00:00\",\"EndDate\":\"2021-06-14T12:00:00\",\"Status\":1,\"Address1\":null,\"Address2\":null,\"City\":null,\"State\":null,\"Zip\":null,\"LocationDescription\":null,\"KeynoteSelected\":false,\"CallForSpeakerOpen\":true,\"IsWorkshopSessionAllowed\":true,\"SessionsSelected\":true,\"Year\":2021}";


            _storageService.Setup(x => x.GetDataFromStorage("public", It.IsAny<string>()))
                               .ReturnsAsync((string container, string path) =>
                               {
                                   if (path.Contains("users"))
                                       return currentUserJson;
                                   else if (path.Contains("events"))
                                       return currentEventJson;
                                   else
                                       return null;
                               });

            // Act
            await _sut.UpdateUserSessions(sessionDto, sessionId, operationPerformed);

            // Assert
            // Add assertions here to verify the expected behavior
            // Verify that WriteObjectToBlobContent is called with the correct parameters
            _storageService.Verify(x => x.WriteObjectToBlobContent("public", It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(2));
            // Verify that GetUser is called to retrieve the current user data
            _storageService.Verify(x => x.GetDataFromStorage("public", $"users/{userId}/{userId}.json"), Times.Once);
            // Verify that GetDataFromStorage is called to retrieve the current event data
            _storageService.Verify(x => x.GetDataFromStorage("public", $"events/{sessionDto.EventId}/{sessionDto.EventId}.json"), Times.Once);
        }





        [Test]
        public async Task UpdateUserSessions_SaveUserSession_Success()
        {
            // Arrange
            var sessionDto = GetUserSessionDto();
            var sessionId = Guid.Parse("3abc5b89-3c6e-49e1-990f-53f986e0ad37");
            var operationPerformed = "UpdateUserSession";
            var userId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"); // Assuming userId is a string

            var currentUserJson = "{\"Id\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"FirstName\":\"Min\",\"LastName\":\"Maung\",\"Email\":\"min@maungs.com\",\"Biography\":\"Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.\",\"PictureLink\":\"http://www.gravatar.com/avatar/099173ab96424339e82de5ad2b447ed3?s=250&&r=G\",\"PresentationSessions\":[\"a8292a14-3f7b-4fef-b0a5-27584cc6fa96\",\"26dcb903-1bb0-4551-85fe-163736bdf80d\",\"7acff94c-dbf4-44c1-bd4b-e887b8dd01f8\",\"c98a89be-f6dd-4a98-bbdf-52924dbb4410\",\"90355858-9a37-4d15-9b74-e8c1a8a230b2\",\"7b6b2037-9146-4f9e-ae4c-6771fe1995a7\",\"a10967b6-e307-4759-a36b-98c2c2fc2f90\",\"2418db21-7944-49fc-b4f3-68948e9ef0f9\",\"1eeff8a5-3aaa-4080-bcd7-d447ec7465b5\",\"d7544eb6-816c-47f5-aabf-81970d3850fd\",\"3abc5b89-3c6e-49e1-990f-53f986e0ad37\",\"d40f0b15-8466-45bc-8b0a-f0d21f7b44f9\",\"b77d5f01-05ae-4fb8-8c78-ac36376c451c\",\"290be8fc-7e43-4b23-854f-d82da875a3b6\",\"a970b9e5-8996-4ad7-a38b-93943d7bfe15\",\"f1ef4255-1829-424c-857b-085d039822cf\",\"9fe7ced4-365a-4c95-9158-248a3ccaf592\",\"c65730c6-379a-4569-a749-3a12786b50fd\",\"1305c920-7c7c-4c18-9900-247cc67395aa\",\"ba46b2ec-07d0-4083-a0ac-60c1580403a6\",\"c06e43dd-eb8f-4525-a5f2-59b883b34c08\",\"80d86fff-e37d-4a23-a8d2-36cb0357cfe5\",\"78047456-a74c-4d5d-8159-3a03b4ff475a\",\"b33e4d0a-7ce8-4dcb-a9ef-4ae56cf1dfdd\",\"e6b02251-a533-4871-a1e9-72a7c21087fb\",\"f693f1a0-6afe-4354-8b41-72752dce6f1f\",\"9116ef0d-8d4b-46e7-af33-f8f1e16b9233\"]}";
            var currentEventJson = "{\"Id\":\"01446bd5-464d-4c3c-a403-36f829d22a97\",\"Name\":\"Open Talk - June '21\",\"StartDate\":\"2021-06-14T12:00:00\",\"EndDate\":\"2021-06-14T12:00:00\",\"Status\":1,\"Address1\":null,\"Address2\":null,\"City\":null,\"State\":null,\"Zip\":null,\"LocationDescription\":null,\"KeynoteSelected\":false,\"CallForSpeakerOpen\":true,\"IsWorkshopSessionAllowed\":true,\"SessionsSelected\":true,\"Year\":2021}";


            _storageService.Setup(x => x.GetDataFromStorage("public", It.IsAny<string>()))
                               .ReturnsAsync((string container, string path) =>
                               {
                                   if (path.Contains("users"))
                                       return currentUserJson;
                                   else if (path.Contains("events"))
                                       return currentEventJson;
                                   else
                                       return null;
                               });

            // Act
            await _sut.UpdateUserSessions(sessionDto, sessionId, operationPerformed);

            // Assert
            // Add assertions here to verify the expected behavior
            // Verify that WriteObjectToBlobContent is called with the correct parameters
            _storageService.Verify(x => x.WriteObjectToBlobContent("public", It.IsAny<string>(), It.IsAny<object>()), Times.Exactly(1));
            // Verify that GetUser is called to retrieve the current user data
            _storageService.Verify(x => x.GetDataFromStorage("public", $"users/{userId}/{userId}.json"), Times.Once);
            // Verify that GetDataFromStorage is called to retrieve the current event data
            _storageService.Verify(x => x.GetDataFromStorage("public", $"events/{sessionDto.EventId}/{sessionDto.EventId}.json"), Times.Once);
        }

        [Test]
        public async Task UpdateUserSessions_NewUserSession_WithNoWorkshopAllowed_AndWorkshopSubmited_Throws_InvalidOperationException_Success()
        {
            // Arrange
            var sessionDto = GetNewUserSessionWithWorkshopDto();
            var sessionId = Guid.NewGuid();
            var operationPerformed = "NewUserSession";
            var userId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"); // Assuming userId is a string

            var currentUserJson = "{\"Id\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"FirstName\":\"Min\",\"LastName\":\"Maung\",\"Email\":\"min@maungs.com\",\"Biography\":\"Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.\",\"PictureLink\":\"http://www.gravatar.com/avatar/099173ab96424339e82de5ad2b447ed3?s=250&&r=G\",\"PresentationSessions\":[\"a8292a14-3f7b-4fef-b0a5-27584cc6fa96\",\"26dcb903-1bb0-4551-85fe-163736bdf80d\",\"7acff94c-dbf4-44c1-bd4b-e887b8dd01f8\",\"c98a89be-f6dd-4a98-bbdf-52924dbb4410\",\"90355858-9a37-4d15-9b74-e8c1a8a230b2\",\"7b6b2037-9146-4f9e-ae4c-6771fe1995a7\",\"a10967b6-e307-4759-a36b-98c2c2fc2f90\",\"2418db21-7944-49fc-b4f3-68948e9ef0f9\",\"1eeff8a5-3aaa-4080-bcd7-d447ec7465b5\",\"d7544eb6-816c-47f5-aabf-81970d3850fd\",\"3abc5b89-3c6e-49e1-990f-53f986e0ad37\",\"d40f0b15-8466-45bc-8b0a-f0d21f7b44f9\",\"b77d5f01-05ae-4fb8-8c78-ac36376c451c\",\"290be8fc-7e43-4b23-854f-d82da875a3b6\",\"a970b9e5-8996-4ad7-a38b-93943d7bfe15\",\"f1ef4255-1829-424c-857b-085d039822cf\",\"9fe7ced4-365a-4c95-9158-248a3ccaf592\",\"c65730c6-379a-4569-a749-3a12786b50fd\",\"1305c920-7c7c-4c18-9900-247cc67395aa\",\"ba46b2ec-07d0-4083-a0ac-60c1580403a6\",\"c06e43dd-eb8f-4525-a5f2-59b883b34c08\",\"80d86fff-e37d-4a23-a8d2-36cb0357cfe5\",\"78047456-a74c-4d5d-8159-3a03b4ff475a\",\"b33e4d0a-7ce8-4dcb-a9ef-4ae56cf1dfdd\",\"e6b02251-a533-4871-a1e9-72a7c21087fb\",\"f693f1a0-6afe-4354-8b41-72752dce6f1f\",\"9116ef0d-8d4b-46e7-af33-f8f1e16b9233\"]}";
            var currentEventJson = "{\"Id\":\"01446bd5-464d-4c3c-a403-36f829d22a97\",\"Name\":\"Open Talk - June '21\",\"StartDate\":\"2021-06-14T12:00:00\",\"EndDate\":\"2021-06-14T12:00:00\",\"Status\":1,\"Address1\":null,\"Address2\":null,\"City\":null,\"State\":null,\"Zip\":null,\"LocationDescription\":null,\"KeynoteSelected\":false,\"CallForSpeakerOpen\":true,\"IsWorkshopSessionAllowed\":false,\"SessionsSelected\":true,\"Year\":2021}";

            _storageService.Setup(x => x.GetDataFromStorage("public", It.IsAny<string>()))
                               .ReturnsAsync((string container, string path) =>
                               {
                                   if (path.Contains("users"))
                                       return currentUserJson;
                                   else if (path.Contains("events"))
                                       return currentEventJson;
                                   else
                                       return null;
                               });

            // Act & Assert
            // Verify that UpdateUserSessions throws InvalidOperationException
             Assert.ThrowsAsync<InvalidOperationException>(async () => await _sut.UpdateUserSessions(sessionDto, sessionId, operationPerformed));

        }

        [Test]
        public async Task UpdateUserSessions_UnexpectedException_ThrowsException()
        {
            // Arrange
            var sessionDto = GetNewUserSessionDto(); // create a valid SessionDto object
            var sessionId = Guid.NewGuid(); // generate a random sessionId
            var operationPerformed = "NewUserSession"; // specify the operation performed
            var userId = Guid.NewGuid(); // generate a random userId
            var exceptionMessage = "Test exception message";

            // Mock dependencies
           
            _storageService.Setup(x => x.GetDataFromStorage("public", It.IsAny<string>()))
                           .ThrowsAsync(new Exception(exceptionMessage)); // throw an exception when GetDataFromStorage is called

            // Act & Assert
            // Verify that UpdateUserSessions throws an exception
            var exception =  Assert.ThrowsAsync<Exception>(async () =>
            {
                await _sut.UpdateUserSessions(sessionDto, sessionId, operationPerformed);
            });    
        }

        [Test]
        public async Task DeleteSessionAndUserWithSession_WithValidContent_CallDeleteFileByPath()
        {
            List<string> blobs = new List<string>();
            blobs.Add("events/01446bd5-464d-4c3c-a403-36f829d22a97/sessions/a8292a14-3f7b-4fef-b0a5-27584cc6fa96.json");
            blobs.Add("users/25b2fd9c-2b51-472a-8e1a-695f74e8beb2/25b2fd9c-2b51-472a-8e1a-695f74e8beb2.json");

            var sessionDto = new SessionDto
            {
                Id = Guid.Parse("a8292a14-3f7b-4fef-b0a5-27584cc6fa96"),
                Title = "Session Name",
                Description = "Desc",
                IsKeynote = true,
                VideoLink = "37218.com",
                IsWorkshop = true,
                UserId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                EventId = Guid.Parse("01446bd5-464d-4c3c-a403-36f849d22a97"),
                VideoThumbnail = "3219.jpeg"
            };

            var user = new User
            {
                Id = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                FirstName = "Ivan",
                LastName = "Moreno",
                Email = "imoreno1@test.com",
                Biography = "Hello",
                PictureLink = "ifaio.jpeg",
                PresentationSessions = new List<Guid>
                {
                    Guid.Parse("a8292a14-3f7b-4fef-b0a5-27584cc6fa96")
                }
            };

            _storageService.Setup(x => x.GetBlobs("public")).Returns(blobs);
            _storageService.Setup(x => x.DeleteFileByPath("public", It.IsAny<string>())).Returns(Task.CompletedTask);
            _storageService.Setup(x => x.WriteBlobContent("public", It.IsAny<string>(), It.IsAny<string>())).Returns(Task.CompletedTask);
            _storageService.SetupSequence(x => x.GetDataFromStorage("public", It.IsAny<string>())).ReturnsAsync(SessionRemovalString).ReturnsAsync(ValidUser);

            await _sut.RemoveSession(sessionDto);

            //assert
            _storageService.Verify(
             x => x.DeleteFileByPath("public", It.IsAny<string>()), Times.AtLeastOnce);
            _storageService.Verify(
             s => s.WriteBlobContent("public", "users/25b2fd9c-2b51-472a-8e1a-695f74e8beb2/25b2fd9c-2b51-472a-8e1a-695f74e8beb2.json", It.IsAny<string>()),
             Times.AtLeastOnce);
        }

        [Test]
        public async Task DeleteSessionAndUserWithSession_WithoutMatchingId_Logs()
        {
            List<string> blobs = new List<string>();
            blobs.Add("events/01446bd5-464d-4c3c-a403-36f829d22a97/sessions/a8292a14-3f7b-4fef-b0a5-27584cc6fa96.json");
            blobs.Add("users/25b2fd9c-2b51-472a-8e1a-695f74e8beb2/25b2fd9c-2b51-472a-8e1a-695f74e8beb2.json");

            var sessionDto = new SessionDto
            {
                Id = Guid.Parse("a8292a14-3f7b-4fef-b0a5-27584cc6fa96"),
                Title = "Session Name",
                Description = "Desc",
                IsKeynote = true,
                VideoLink = "37218.com",
                IsWorkshop = true,
                UserId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                EventId = Guid.Parse("01446bd5-464d-4c3c-a403-36f849d22a97"),
                VideoThumbnail = "3219.jpeg"
            };

            var user = new User
            {
                Id = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                FirstName = "Ivan",
                LastName = "Moreno",
                Email = "imoreno1@test.com",
                Biography = "Hello",
                PictureLink = "ifaio.jpeg",
                PresentationSessions = new List<Guid>
                {
                    Guid.Parse("a8292a14-3f7b-4fef-b0a5-27584cc6fa96")
                }
            };

            _storageService.Setup(x => x.GetBlobs("public")).Returns(blobs);
            _storageService.Setup(x => x.DeleteFileByPath("public", It.IsAny<string>())).Returns(Task.CompletedTask);
            _storageService.Setup(x => x.WriteBlobContent("public", It.IsAny<string>(), It.IsAny<string>())).Returns(Task.CompletedTask);
            _storageService.SetupSequence(x => x.GetDataFromStorage("public", It.IsAny<string>())).ReturnsAsync(SessionRemovalString2).ReturnsAsync(ValidUser);

            await _sut.RemoveSession(sessionDto);

            //assert
            _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
            _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
        }

        [Test]
        public void DeleteSessionAndUserWithSession_WriteBlobContentThrowsException()
        {
            List<string> blobs = new List<string>();
            blobs.Add("events/01446bd5-464d-4c3c-a403-36f829d22a97/sessions/a8292a14-3f7b-4fef-b0a5-27584cc6fa96.json");
            blobs.Add("users/25b2fd9c-2b51-472a-8e1a-695f74e8beb2/25b2fd9c-2b51-472a-8e1a-695f74e8beb2.json");

            var sessionDto = new SessionDto
            {
                Id = Guid.Parse("a8292a14-3f7b-4fef-b0a5-27584cc6fa96"),
                Title = "Session Name",
                Description = "Desc",
                IsKeynote = true,
                VideoLink = "37218.com",
                IsWorkshop = true,
                UserId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                EventId = Guid.Parse("01446bd5-464d-4c3c-a403-36f849d22a97"),
                VideoThumbnail = "3219.jpeg"
            };

            var user = new User
            {
                Id = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                FirstName = "Ivan",
                LastName = "Moreno",
                Email = "imoreno1@test.com",
                Biography = "Hello",
                PictureLink = "ifaio.jpeg",
                PresentationSessions = new List<Guid>
                {
                    Guid.Parse("a8292a13-3f7b-4fef-b0a5-27584cc6fa96")
                }
            };

            var exception = new Exception("WriteBlobContent error");
            _storageService.Setup(x => x.WriteBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(exception);

            _storageService.Setup(x => x.GetBlobs("public")).Returns(blobs);
            _storageService.Setup(x => x.DeleteFileByPath("public", It.IsAny<string>())).Returns(Task.CompletedTask);
            _storageService.SetupSequence(x => x.GetDataFromStorage("public", It.IsAny<string>())).ReturnsAsync(SessionRemovalString).ReturnsAsync(ValidUser);

            //assert
            Assert.ThrowsAsync<Exception>(async () => await _sut.RemoveSession(sessionDto));
        }

        [Test]
        public void DeleteSessionAndUserWithSession_GetDataFromStorageThrowsAnotherException()
        {
            List<string> blobs = new List<string>();
            blobs.Add("events/01446bd5-464d-4c3c-a403-36f829d22a97/sessions/a8292a14-3f7b-4fef-b0a5-27584cc6fa96.json");
            blobs.Add("users/25b2fd9c-2b51-472a-8e1a-695f74e8beb2/25b2fd9c-2b51-472a-8e1a-695f74e8beb2.json");

            var sessionDto = new SessionDto
            {
                Id = Guid.Parse("a8292a14-3f7b-4fef-b0a5-27584cc6fa96"),
                Title = "Session Name",
                Description = "Desc",
                IsKeynote = true,
                VideoLink = "37218.com",
                IsWorkshop = true,
                UserId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                EventId = Guid.Parse("01446bd5-464d-4c3c-a403-36f849d22a97"),
                VideoThumbnail = "3219.jpeg"
            };

            var user = new User
            {
                Id = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                FirstName = "Ivan",
                LastName = "Moreno",
                Email = "imoreno1@test.com",
                Biography = "Hello",
                PictureLink = "ifaio.jpeg",
                PresentationSessions = new List<Guid>
                {
                    Guid.Parse("a8292a13-3f7b-4fef-b0a5-27584cc6fa96")
                }
            };


            var exception = new Exception("Get Data from storage error");
            _storageService.Setup(x => x.GetBlobs("public")).Returns(blobs);
            _storageService.Setup(x => x.GetDataFromStorage("public", It.IsAny<string>())).ThrowsAsync(exception);

            _storageService.Setup(x => x.WriteBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(Task.CompletedTask);

            _storageService.Setup(x => x.DeleteFileByPath("public", It.IsAny<string>())).Returns(Task.CompletedTask);

            //assert
            Assert.ThrowsAsync<Exception>(async () => await _sut.RemoveSession(sessionDto));
        }

        [Test]
        public void DeleteSession_ThrowsException()
        {
            List<string> blobs = new List<string>();
            blobs.Add("events/01446bd5-464d-4c3c-a403-36f829d22a97/sessions/a8292a14-3f7b-4fef-b0a5-27584cc6fa96.json");
            blobs.Add("users/25b2fd9c-2b51-472a-8e1a-695f74e8beb2/25b2fd9c-2b51-472a-8e1a-695f74e8beb2.json");

            var sessionDto = new SessionDto
            {
                Id = Guid.Parse("a8292a14-3f7b-4fef-b0a5-27584cc6fa96"),
                Title = "Session Name",
                Description = "Desc",
                IsKeynote = true,
                VideoLink = "37218.com",
                IsWorkshop = true,
                UserId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                EventId = Guid.Parse("01446bd5-464d-4c3c-a403-36f849d22a97"),
                VideoThumbnail = "3219.jpeg"
            };

            var user = new User
            {
                Id = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                FirstName = "Ivan",
                LastName = "Moreno",
                Email = "imoreno1@test.com",
                Biography = "Hello",
                PictureLink = "ifaio.jpeg",
                PresentationSessions = new List<Guid>
                {
                    Guid.Parse("a8292a13-3f7b-4fef-b0a5-27584cc6fa96")
                }
            };

            var exception = new Exception("Delete file by path error");

            _storageService.SetupSequence(x => x.GetDataFromStorage("public", It.IsAny<string>())).ReturnsAsync(SessionRemovalString).ReturnsAsync(ValidUser);
            _storageService.Setup(x => x.GetBlobs("public")).Returns(blobs);
            _storageService.Setup(x => x.DeleteFileByPath("public", It.IsAny<string>())).ThrowsAsync(exception);
            _storageService.Setup(x => x.WriteBlobContent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(Task.CompletedTask);

            // Act & Assert
            Assert.ThrowsAsync<Exception>(() => _sut.RemoveSession(sessionDto));
        }


        // End of Post User Session Unit Test

        // GetUserSessions Tests
        [Test]
        public async Task Given_GetUserSessionsByUserId_CallsGetsBlobs_ReturnsList_Then_Log()
        {
            //setup
            var expectedBlobs = GetValidBlobItems();
            var userId = ValidUserId2;
            var sessions = expectedBlobs.Where(s => s.Contains("sessions")).ToList();

            _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
                .ReturnsAsync(ValidUser2)
                .ReturnsAsync(Session1String)
                .ReturnsAsync(Session2String)
                .ReturnsAsync(Session3String)
                .ReturnsAsync(EventString)
                .ReturnsAsync(EventString)
                .ReturnsAsync(EventString);


            //Act
            var sessionsList = await _sut.GetUserSessions(sessions, userId);

            //Assert
            Assert.That(sessionsList, Has.Count.EqualTo(3));
            _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(7));
            _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(2));
        }
        [Test]
        public async Task Given_GetUserSessionsByUserId_FailsOnGetDataFromStorage_Then_LogAndThrowException()
        {
            //setup
            var expectedBlobs = GetValidBlobItems();
            var userId = ValidUserId2;
            var sessions = expectedBlobs.Where(s => s.Contains("sessions")).ToList();
            var exception = new Exception("There was some error reading from storage");
            _storageService.Setup(s => s.GetDataFromStorage("public", It.IsAny<string>()))
                .Throws(exception);

            //Act
            Assert.ThrowsAsync<Exception>(async () => await _sut.GetUserSessions(sessions, userId));

            //Assert
            _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
            _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
        }
        [Test]
        public async Task Given_GetUserSessions_ThrowsException_When_UserNotFound()
        {
            // Arrange
            var expectedBlobs = GetValidBlobItems();
            var userId = ValidUserId2;
            var sessions = expectedBlobs.Where(s => s.Contains("sessions")).ToList();
            var userResult = JsonConvert.SerializeObject(null); // Simulating null user result
            _storageService.Setup(s => s.GetDataFromStorage("public", It.IsAny<string>()))
                .ReturnsAsync(userResult);

            // Act
            Assert.ThrowsAsync<Exception>(async () => await _sut.GetUserSessions(sessions, userId));

            // Assert
            _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(1));
            _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(1));
        }
        [Test]
        public async Task Given_GetUserSessionsByUserId_CallsGetsBlobs_ReturnsEmptyList_Then_Log()
        {
            //setup
            var expectedBlobs = GetValidBlobItems();
            var userId = ValidUserId2;
            var sessions = expectedBlobs.Where(s => s.Contains("sessions")).ToList();

            _storageService.SetupSequence(s => s.GetDataFromStorage("public", It.IsAny<string>()))
                .ReturnsAsync(ValidUser2)
                .ReturnsAsync("")
                .ReturnsAsync("")
                .ReturnsAsync("");

            //Act
            var sessionsList = await _sut.GetUserSessions(sessions, userId);

            //Assert
            Assert.That(sessionsList, Is.Empty);
            _storageService.Verify(s => s.GetDataFromStorage(It.IsAny<string>(), It.IsAny<string>()), Times.Exactly(4));
            _logger.Verify(logger => logger.Log(LogLevel.Information, It.IsAny<EventId>(), It.IsAny<It.IsAnyType>(), It.IsAny<Exception>(), ((Func<It.IsAnyType, Exception, string>)It.IsAny<object>())!), Times.Exactly(2));
        }
        //End of GetUserSessions Tests

        #region Test Data
        //Start of Post User Session Test Data
        public SessionDto GetNewUserSessionDto()
        {
            var userSession = new SessionDto
            {
                Title = "Open Talk  - Dot Net111",
                Description = "The moderators Lwin Maung &amp; Min Maung will share their experience, and bring various experts in different areas. Come join the community as we discuss with all of you on various development journeys. \n<br><br><br>\nWe will be covering topics below and more:<br>\n- Evolution of Dot Net<br>\n- Dot Net Core<br>\n- Cross Platform use<br>\n- Windows, Mac, Linux and Dot NET<br>",
                UserId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                IsKeynote = false,
                VideoLink = null,
                IsSelected = true,
                IsWorkshop = false,
                EventId = Guid.Parse("01446bd5-464d-4c3c-a403-36f829d22a97"),
                VideoThumbnail = null

            };
            return userSession;
        }

        public SessionDto GetNewUserSessionWithWorkshopDto()
        {
            var userSession = new SessionDto
            {
                Title = "Open Talk  - Dot Net111",
                Description = "The moderators Lwin Maung &amp; Min Maung will share their experience, and bring various experts in different areas. Come join the community as we discuss with all of you on various development journeys. \n<br><br><br>\nWe will be covering topics below and more:<br>\n- Evolution of Dot Net<br>\n- Dot Net Core<br>\n- Cross Platform use<br>\n- Windows, Mac, Linux and Dot NET<br>",
                UserId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                IsKeynote = false,
                VideoLink = null,
                IsSelected = true,
                IsWorkshop = true,
                EventId = Guid.Parse("01446bd5-464d-4c3c-a403-36f829d22a97"),
                VideoThumbnail = null

            };
            return userSession;
        }
        public SessionDto GetUserSessionDto()
        {
            var userSession = new SessionDto
            {

                Id = Guid.Parse("3abc5b89-3c6e-49e1-990f-53f986e0ad37"),
                Title = "Open Talk  - Dot Net111",
                Description = "The moderators Lwin Maung &amp; Min Maung will share their experience, and bring various experts in different areas. Come join the community as we discuss with all of you on various development journeys. \n<br><br><br>\nWe will be covering topics below and more:<br>\n- Evolution of Dot Net<br>\n- Dot Net Core<br>\n- Cross Platform use<br>\n- Windows, Mac, Linux and Dot NET<br>",
                UserId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                IsKeynote = false,
                VideoLink = null,
                IsSelected = true,
                IsWorkshop = false,
                EventId = Guid.Parse("01446bd5-464d-4c3c-a403-36f829d22a97"),
                VideoThumbnail = null

            };
            return userSession;
        }

        //End of Post User Session Test Data

        public UserDTO GetUserDTO()
        {
            var newUser = new UserDTO
            {
                Id = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                FirstName = "Minnn",
                LastName = "Maung",
                Email = "min@maungs.com",
                Biography = "Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.",
                PictureLink = "http://www.gravatar.com/avatar/099173ab96424339e82de5ad2b447ed3?s=250&&r=G",
                SocialMediaLinks = new List<UserSocialMediaDTO>
            {
                new UserSocialMediaDTO
                {
                    UserSocialMediaId = Guid.Parse("5a732ca6-8f99-4943-bd0d-29847ec21e29"),
                    SocialMediaPlatformId = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4"),
                    UserId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                    SocialMediaLink = "https://twitter.com/"

                },
                new UserSocialMediaDTO
                {
                    UserSocialMediaId = Guid.Parse("7397823f-3c3a-48dd-bf90-ace6693085d6"),
                    SocialMediaPlatformId = Guid.Parse("0db5ddac-1c4e-4cb9-a510-1fc003922861"),
                    UserId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                    SocialMediaLink = "https://www.linkedin.com/"

                }
            },
                PresentationSessions = new List<Guid>
            {
                Guid.Parse("a8292a14-3f7b-4fef-b0a5-27584cc6fa96"),
                Guid.Parse("26dcb903-1bb0-4551-85fe-163736bdf80d"),
                Guid.Parse("7acff94c-dbf4-44c1-bd4b-e887b8dd01f8"),
                Guid.Parse("c98a89be-f6dd-4a98-bbdf-52924dbb4410"),
                Guid.Parse("90355858-9a37-4d15-9b74-e8c1a8a230b2")
            }
            };
            return newUser;
        }

        public List<UserSocialMediaDTO> GetUserSocialMediaDTO()
        {
            var socialMediaList = new List<UserSocialMediaDTO>
    {
        new UserSocialMediaDTO
        {
            UserSocialMediaId = Guid.Parse("5a732ca6-8f99-4943-bd0d-29847ec21e29"),
            SocialMediaPlatformId = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4"),
            UserId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
            SocialMediaLink = "https://twitter.com/"
        },
        new UserSocialMediaDTO
        {
            UserSocialMediaId = Guid.Parse("7397823f-3c3a-48dd-bf90-ace6693085d6"),
            SocialMediaPlatformId = Guid.Parse("0db5ddac-1c4e-4cb9-a510-1fc003922861"),
            UserId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
            SocialMediaLink = "https://www.linkedin.com/"
        }
    };

            return socialMediaList;
        }


        public List<UserSocialMediaDTO> GetNewUserSocialMediaDTO()
        {
            var socialMediaList = new List<UserSocialMediaDTO>
    {
        new UserSocialMediaDTO
        {
            SocialMediaPlatformId = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4"),
            SocialMediaLink = "https://twitter.com/"
        },
        new UserSocialMediaDTO
        {
            SocialMediaPlatformId = Guid.Parse("0db5ddac-1c4e-4cb9-a510-1fc003922861"),
            SocialMediaLink = "https://www.linkedin.com/"
        }
    };

            return socialMediaList;
        }

        public List<UserSocialMediaDTO> GetNullUserSocialMediaDTO()
        {
            List<UserSocialMediaDTO> socialMediaList = null;
            return socialMediaList;
        }

        public UserDTO GetUserDTONoPictureLink()
        {
            var newUser = new UserDTO
            {
                Id = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                FirstName = "Minnn",
                LastName = "Maung",
                Email = "min@maungs.com",
                Biography = "Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.",
                SocialMediaLinks = new List<UserSocialMediaDTO>
            {
                new UserSocialMediaDTO
                {
                    UserSocialMediaId = Guid.Parse("5a732ca6-8f99-4943-bd0d-29847ec21e29"),
                    SocialMediaPlatformId = Guid.Parse("e4b6ad76-60da-4f2b-bef9-a47b18daead4"),
                    UserId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                    SocialMediaLink = "https://twitter.com/"

                },
                new UserSocialMediaDTO
                {
                    UserSocialMediaId = Guid.Parse("7397823f-3c3a-48dd-bf90-ace6693085d6"),
                    SocialMediaPlatformId = Guid.Parse("0db5ddac-1c4e-4cb9-a510-1fc003922861"),
                    UserId = Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"),
                    SocialMediaLink = "https://www.linkedin.com/"

                }
            },
                PresentationSessions = new List<Guid>
            {
                Guid.Parse("a8292a14-3f7b-4fef-b0a5-27584cc6fa96"),
                Guid.Parse("26dcb903-1bb0-4551-85fe-163736bdf80d"),
                Guid.Parse("7acff94c-dbf4-44c1-bd4b-e887b8dd01f8"),
                Guid.Parse("c98a89be-f6dd-4a98-bbdf-52924dbb4410"),
                Guid.Parse("90355858-9a37-4d15-9b74-e8c1a8a230b2")
            }
            };
            return newUser;
        }
        private List<string> GetValidBlobItems()
        {
            List<string> result =
            [
                "users/60995f39-8857-4c99-8a89-7a91977b4790/60995f39-8857-4c99-8a89-7a91977b4790.json",
                "users/2d512b99-f94d-4b69-a824-947c7edc692e/2d512b99-f94d-4b69-a824-947c7edc692e.json",
                "events/bce217b0-dc67-40f1-a82f-ffd3cc119e99/bce217b0-dc67-40f1-a82f-ffd3cc119e99.json",
                "events/113f8c47-6256-4f14-bb99-e91e0e2319a9/113f8c47-6256-4f14-bb99-e91e0e2319a9.json",
                "events/bce217b0-dc67-40f1-a82f-ffd3cc119e99/sessions/1ca2d0de-02b2-4044-ab83-ebbb9a0fa454.json",
                "events/bce217b0-dc67-40f1-a82f-ffd3cc119e99/sessions/1d1b4ce1-3f13-49fd-a473-b3bf2e56236c.json",
                "events/bce217b0-dc67-40f1-a82f-ffd3cc119e99/staff/0aa3255d-edd6-4260-888e-c50ec5c1e1f4.json",
                "events/113f8c47-6256-4f14-bb99-e91e0e2319a9/sessions/28d8179b-a266-47e7-88e9-9d8113dfe3dd.json"
            ];
            return result;
        }

        private const string ValidUserId = "25b2fd9c-2b51-472a-8e1a-695f74e8beb2";
        private static readonly Guid ValidUserId2 = Guid.Parse("492d9189-e08e-4d4b-a902-29fad2497d1b");
        private const string ValidUser = "{\"Id\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"FirstName\":\"Min\",\"LastName\":\"Maung\",\"Email\":\"min@maungs.com\",\"Biography\":\"Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.\",\"PictureLink\":\"http://www.gravatar.com/avatar/099173ab96424339e82de5ad2b447ed3?s=250&&r=G\",\"PresentationSessions\":[\"a8292a14-3f7b-4fef-b0a5-27584cc6fa96\",\"26dcb903-1bb0-4551-85fe-163736bdf80d\",\"7acff94c-dbf4-44c1-bd4b-e887b8dd01f8\",\"c98a89be-f6dd-4a98-bbdf-52924dbb4410\",\"90355858-9a37-4d15-9b74-e8c1a8a230b2\",\"7b6b2037-9146-4f9e-ae4c-6771fe1995a7\",\"a10967b6-e307-4759-a36b-98c2c2fc2f90\",\"2418db21-7944-49fc-b4f3-68948e9ef0f9\",\"1eeff8a5-3aaa-4080-bcd7-d447ec7465b5\",\"d7544eb6-816c-47f5-aabf-81970d3850fd\",\"3abc5b89-3c6e-49e1-990f-53f986e0ad37\",\"d40f0b15-8466-45bc-8b0a-f0d21f7b44f9\",\"b77d5f01-05ae-4fb8-8c78-ac36376c451c\",\"290be8fc-7e43-4b23-854f-d82da875a3b6\",\"a970b9e5-8996-4ad7-a38b-93943d7bfe15\",\"f1ef4255-1829-424c-857b-085d039822cf\",\"9fe7ced4-365a-4c95-9158-248a3ccaf592\",\"c65730c6-379a-4569-a749-3a12786b50fd\",\"1305c920-7c7c-4c18-9900-247cc67395aa\",\"ba46b2ec-07d0-4083-a0ac-60c1580403a6\",\"c06e43dd-eb8f-4525-a5f2-59b883b34c08\",\"80d86fff-e37d-4a23-a8d2-36cb0357cfe5\",\"78047456-a74c-4d5d-8159-3a03b4ff475a\",\"b33e4d0a-7ce8-4dcb-a9ef-4ae56cf1dfdd\",\"e6b02251-a533-4871-a1e9-72a7c21087fb\",\"f693f1a0-6afe-4354-8b41-72752dce6f1f\"]}";
        private const string ValidUser2 = "{\"Id\":\"492d9189-e08e-4d4b-a902-29fad2497d1b\",\"FirstName\":\"Min\",\"LastName\":\"Maung\",\"Email\":\"min@maungs.com\",\"Biography\":\"Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.\",\"PictureLink\":\"http://www.gravatar.com/avatar/099173ab96424339e82de5ad2b447ed3?s=250&&r=G\",\"PresentationSessions\":[\"1ca2d0de-02b2-4044-ab83-ebbb9a0fa454\",\"1d1b4ce1-3f13-49fd-a473-b3bf2e56236c\",\"28d8179b-a266-47e7-88e9-9d8113dfe3dd\"]}";
        private const string ValidUserSocialMedia = "[{\"Id\":\"5a732ca6-8f99-4943-bd0d-29847ec21e29\",\"SocialMediaPlatformId\":\"e4b6ad76-60da-4f2b-bef9-a47b18daead4\",\"Link\":\"https://twitter.com/\",\"UserId\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\"},{\"Id\":\"7397823f-3c3a-48dd-bf90-ace6693085d6\",\"SocialMediaPlatformId\":\"0db5ddac-1c4e-4cb9-a510-1fc003922861\",\"Link\":\"https://www.linkedin.com/\",\"UserId\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\"}]";
        private const string ValidUserDTO = "{\r\n    \"Id\": \"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\r\n    \"FirstName\": \"Min\",\r\n    \"LastName\": \"Maung\",\r\n    \"Email\": \"min@maungs.com\",\r\n    \"Biography\": \"Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.\",\r\n    \"PictureLink\": \"http://www.gravatar.com/avatar/099173ab96424339e82de5ad2b447ed3?s=250&&r=G\",\r\n    \"SocialMediaLinks\": [\r\n        {\r\n            \"UserSocialMediaId\": \"5a732ca6-8f99-4943-bd0d-29847ec21e29\",\r\n            \"SocialMediaPlatformId\": \"e4b6ad76-60da-4f2b-bef9-a47b18daead4\",\r\n            \"UserId\": \"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\r\n            \"SocialMediaLink\": \"https://twitter.com/\",\r\n            \"SocialMediaIcon\": \"fa-twitter-square\"\r\n        },\r\n        {\r\n            \"UserSocialMediaId\": \"7397823f-3c3a-48dd-bf90-ace6693085d6\",\r\n            \"SocialMediaPlatformId\": \"0db5ddac-1c4e-4cb9-a510-1fc003922861\",\r\n            \"UserId\": \"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\r\n            \"SocialMediaLink\": \"https://www.linkedin.com/\",\r\n            \"SocialMediaIcon\": \"fa-linkedin-square\"\r\n        }\r\n    ],\r\n    \"PresentationSessions\": [\r\n        \"a8292a14-3f7b-4fef-b0a5-27584cc6fa96\",\r\n        \"26dcb903-1bb0-4551-85fe-163736bdf80d\",\r\n        \"7acff94c-dbf4-44c1-bd4b-e887b8dd01f8\",\r\n        \"c98a89be-f6dd-4a98-bbdf-52924dbb4410\",\r\n        \"90355858-9a37-4d15-9b74-e8c1a8a230b2\",\r\n        \"7b6b2037-9146-4f9e-ae4c-6771fe1995a7\",\r\n        \"a10967b6-e307-4759-a36b-98c2c2fc2f90\",\r\n        \"2418db21-7944-49fc-b4f3-68948e9ef0f9\",\r\n        \"1eeff8a5-3aaa-4080-bcd7-d447ec7465b5\",\r\n        \"d7544eb6-816c-47f5-aabf-81970d3850fd\",\r\n        \"3abc5b89-3c6e-49e1-990f-53f986e0ad37\",\r\n        \"d40f0b15-8466-45bc-8b0a-f0d21f7b44f9\",\r\n        \"b77d5f01-05ae-4fb8-8c78-ac36376c451c\",\r\n        \"290be8fc-7e43-4b23-854f-d82da875a3b6\",\r\n        \"a970b9e5-8996-4ad7-a38b-93943d7bfe15\",\r\n        \"f1ef4255-1829-424c-857b-085d039822cf\",\r\n        \"9fe7ced4-365a-4c95-9158-248a3ccaf592\",\r\n        \"c65730c6-379a-4569-a749-3a12786b50fd\",\r\n        \"1305c920-7c7c-4c18-9900-247cc67395aa\",\r\n        \"ba46b2ec-07d0-4083-a0ac-60c1580403a6\",\r\n        \"c06e43dd-eb8f-4525-a5f2-59b883b34c08\",\r\n        \"80d86fff-e37d-4a23-a8d2-36cb0357cfe5\",\r\n        \"78047456-a74c-4d5d-8159-3a03b4ff475a\",\r\n        \"b33e4d0a-7ce8-4dcb-a9ef-4ae56cf1dfdd\",\r\n        \"e6b02251-a533-4871-a1e9-72a7c21087fb\",\r\n        \"f693f1a0-6afe-4354-8b41-72752dce6f1f\"\r\n    ]\r\n}";
        private const string ValidSocialMediaPlatforms = "[\r\n    {\r\n        \"Id\" :\"e4b6ad76-60da-4f2b-bef9-a47b18daead4\",\r\n        \"Name\" : \"Twitter\",\r\n        \"Icon\" : \"fa-twitter-square\"\r\n    },\r\n    {\r\n        \"Id\" :\"0db5ddac-1c4e-4cb9-a510-1fc003922861\",\r\n        \"Name\" : \"LinkedIn\",\r\n        \"Icon\" : \"fa-linkedin-square\"\r\n    }\r\n]";
        private const string Session1String =
        "{\"id\":\"0ce253b1-97f9-40ef-ac52-3c8cbade7c25\",\"title\":\"Cloud Design Patterns\",\"description\":\"With the advent of Kubernetes as the defacto application orchestration tool, it's important the applications are developed with the idioms of the hosting environment in mind. This presentation discusses the problems distributed systems need to solve and how K8S native primitives help solve them.\",\"userId\":\"492d9189-e08e-4d4b-a902-29fad2497d1b\",\"isKeynote\":false,\"videoLink\":null,\"isSelected\":false,\"isWorkshop\":false,\"eventId\":\"71358ec6-e186-4556-8ac3-dea90112c7a6\",\"videoThumbnail\":null}";

        private const string Session2String =
            "{\"id\":\"1b9a6656-7991-4a91-a127-63afc5019d12\",\"title\":\"What C# Programmers Need to Know About Pattern Matching\",\"description\":\"At first glance, C# Pattern Matching just looks like a more powerful switch statement. But upon further investigation, it can dramatically clean up your code. The key is to approach pattern matching with the right mindset.&nbsp;\\n\\nThis session will examine the benefits of C# pattern matching by looking at how some high-profile C# open source projects are using it. It will also look at the ways languages like F#, Elixir, Swift, and Rust benefit from using pattern matching. It will look at some of the exciting new features proposed for C# 8. Lastly, it will talk about how you can improve your code by incorporating pattern matching.\",\"userId\":\"ea7fa209-dfb0-45ee-8fcd-67deb1181034\",\"isKeynote\":false,\"videoLink\":null,\"isSelected\":false,\"isWorkshop\":false,\"eventId\":\"71358ec6-e186-4556-8ac3-dea90112c7a6\",\"videoThumbnail\":null}";

        private const string Session3String =
            "{\"id\":\"6f70015d-46c0-4da3-bbad-adcbbfd07577\",\"title\":\"What The Shell? How Xamarin.Forms Shell will change your life\",\"description\":\"Xamarin.Forms 4 may still be in preview, but the new shell features are INCREDIBLE. Get an introduction to the application architecture, UI patterns, new navigation controls, and lots of great examples. See how to retro-fit your current applications to have a fresh new look.\",\"userId\":\"8ccd973d-6920-42ed-a2c3-aa7cd5a6fe9d\",\"isKeynote\":false,\"videoLink\":null,\"isSelected\":false,\"isWorkshop\":false,\"eventId\":\"bce217b0-dc67-40f1-a82f-ffd3cc119e10\",\"videoThumbnail\":null}";

        private const string EventString =
            "{\"Id\":\"bce217b0-dc67-40f1-a82f-ffd3cc119e10\",\"Name\":\"Hangout: Containerization during containment and comparison of cloud providers\",\"StartDate\":\"2020-08-01T16:00:00\",\"EndDate\":\"2020-08-01T16:00:00\",\"Status\":1,\"Address1\":null,\"Address2\":null,\"City\":null,\"State\":null,\"Zip\":null,\"LocationDescription\":null,\"KeynoteSelected\":false,\"SessionsSelected\":false,\"Year\":2020}";

        private const string SessionRemovalString =
            "{\"Id\":\"a8292a14-3f7b-4fef-b0a5-27584cc6fa96\",\"Title\":\"Session Name\",\"Description\":\"Desc\",\"UserId\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"IsKeynote\":true,\"VideoLink\":null,\"IsSelected\":false,\"IsWorkshop\":false,\"EventId\":\"01446bd5-464d-4c3c-a403-36f849d22a97\",\"VideoThumbnail\":null}";

        private const string SessionRemovalString2 =
           "{\"Id\":\"a8292a14-3f7b-4fef-b0a5-27584cc6fa96\",\"Title\":\"Session Name\",\"Description\":\"Desc\",\"UserId\":\"ea7fa209-dfb0-45ee-8fcd-67deb1181034\",\"IsKeynote\":true,\"VideoLink\":null,\"IsSelected\":false,\"IsWorkshop\":false,\"EventId\":\"01446bd5-464d-4c3c-a403-36f849d22a97\",\"VideoThumbnail\":null}";
        #endregion

    }
}
