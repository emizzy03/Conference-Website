﻿using System;
using System.IO;
using System.Net;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;
using TCC.Functions.Implementations.Services;
using TCC.Functions.Interfaces;
using TCC.Functions.Model;

namespace TCC.Functions.Tests
{
    [TestFixture]
    public class HttpWebRequestServiceTests
    {
        private HttpWebRequestService _httpWebRequestService = null!;
        private Mock<ILogger<HttpWebRequestService>> _loggerMock = null!;

        [SetUp]
        public void Setup()
        {
            _loggerMock = new Mock<ILogger<HttpWebRequestService>>();
            _httpWebRequestService = new HttpWebRequestService(_loggerMock.Object);
        }

        [Test]
        public void GetURLResponse_ValidUrl_ReturnsSuccessResponse()
        {
            // Arrange
            var url = "http://example.com";
            var responseMock = new Mock<HttpWebResponse>();
            responseMock.SetupGet(r => r.StatusCode).Returns(HttpStatusCode.OK);
            var requestMock = new Mock<HttpWebRequest>();
            requestMock.Setup(r => r.GetResponse()).Returns(responseMock.Object);
            var webRequestMock = Mock.Of<WebRequest>(w => w.GetResponse() == responseMock.Object);

            // Act
            var result = _httpWebRequestService.GetURLResponse(url);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        [Test]
        public void GetURLResponse_NullUrl_ThrowsArgumentException()
        {
            // Act & Assert
            Assert.Throws<ArgumentException>(() => _httpWebRequestService.GetURLResponse(null));
        }

        // [Test]
        // public void GetURLResponse_WebException_ReturnsErrorResponse()
        // {
        //     // Arrange
        //     var url = "https://httpstat.us/500";
        //     var webException = new WebException("Test WebException");
        //     var requestMock = new Mock<HttpWebRequest>();
        //     requestMock.Setup(r => r.GetResponse()).Throws(webException);
        //
        //     // Act
        //     var result = _httpWebRequestService.GetURLResponse(url);
        //
        //     // Assert
        //     Assert.IsNotNull(result);
        //     // Since there's no error property, we don't assert it
        //     Assert.AreEqual(HttpStatusCode.InternalServerError, result.StatusCode);
        // }

        [Test]
        public void GetURLResponse_WebException_NoHttpResponse_ReturnsNull()
        {
            // Arrange
            var url = "https://nonexistent-url"; 
                                                 
          
            var webException = new WebException("Test WebException");
            var requestMock = new Mock<HttpWebRequest>();
            requestMock.Setup(r => r.GetResponse()).Throws(webException);

            // Act
            var result = _httpWebRequestService.GetURLResponse(url);

            // Assert
            Assert.Null(result);

        }

        [Test]
        public void GetURLResponse_WebException_LogsErrorAndReturnsNull()
        {
            // Arrange
            var url = "invalid_url"; // Assuming this URL will cause a WebException
         
            // Act
            var response = _httpWebRequestService.GetURLResponse(url);

            // Assert
            Assert.IsNull(response);
          
        }
    }
}
