﻿using System.Text.Json;
using TCC.Functions.Extensions;

namespace TCC.Functions.Tests.Extensions;

[TestOf(typeof(ObjectExtensions))]
public class ObjectExtensionsTest
{
    private class TestClass(string userName, int userAge)
    {
        public string UserName { get; set; } = userName;
        public int UserAge { get; set; } = userAge;

        public override string ToString() => this.ToJson();
    }
    
    private const string TestObjectJson = "{\"userName\":\"Test user\",\"userAge\":23}";
    private const string TestObjectSnakeJson = "{\"user_name\":\"Test user\",\"user_age\":23}";
    
    private static JsonSerializerOptions SnakeCaseJsonSerializerOptions => new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower
    };

    [Test]
    public void ToJson_WithObject_ReturnsJsonString()
    {
        var testObject = new TestClass("Test user", 23);
        var jsonString = testObject.ToJson();
        Assert.That(jsonString, Is.EqualTo(TestObjectJson));
    }

    [Test]
    public void FromJson_WithJsonString_ReturnsObject()
    {
        var testObject = TestObjectJson.FromJson<TestClass>();
        Assert.That(testObject, Is.Not.Null);
        Assert.That(testObject, Is.TypeOf<TestClass>());
        Assert.Multiple(() =>
        {
            Assert.That(testObject!.UserName, Is.EqualTo("Test user"));
            Assert.That(testObject.UserAge, Is.EqualTo(23));
        });
    }

    [Test]
    public void ToJson_WithObject_SnakeCase_ReturnsJsonString()
    {
        var testObject = new TestClass("Test user", 23);
        var jsonString = testObject.ToJson(SnakeCaseJsonSerializerOptions);
        Assert.That(jsonString, Is.EqualTo(TestObjectSnakeJson));
    }

    [Test]
    public void FromJson_WithJsonString_SnakeCase_ReturnsObject()
    {
        var testObject = TestObjectSnakeJson.FromJson<TestClass>(SnakeCaseJsonSerializerOptions);
        Assert.That(testObject, Is.Not.Null);
        Assert.That(testObject, Is.TypeOf<TestClass>());
        Assert.Multiple(() =>
        {
            Assert.That(testObject!.UserName, Is.EqualTo("Test user"));
            Assert.That(testObject.UserAge, Is.EqualTo(23));
        });
    }
}