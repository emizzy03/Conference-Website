﻿using System.Net;
using System.Text;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using TCC.Functions.Extensions;
using TCC.Functions.Implementations.DTO;
using HttpRequestDataExtensions = TCC.Functions.Extensions.HttpRequestDataExtensions;

namespace TCC.Functions.Tests.Extensions;

[TestOf(typeof(HttpRequestDataExtensions))]
public class HttpRequestDataExtensionsTest
{
    private static Mock<HttpRequestData> GetMockRequestData(HttpStatusCode statusCode, string? body = null)
    {
        var serviceCollection = new ServiceCollection();
        serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
        var serviceProvider = serviceCollection.BuildServiceProvider();

        var context = new Mock<FunctionContext>();
        context.SetupProperty(c => c.InstanceServices, serviceProvider);

        var request = new Mock<HttpRequestData>(context.Object);
        request.Setup(req => req.Body).Returns(new MemoryStream());
        request.Setup(req => req.CreateResponse()).Returns(() =>
        {
            var response = new Mock<HttpResponseData>(context.Object);
            response.SetupProperty(r => r.Headers, []);
            response.SetupProperty(r => r.StatusCode, statusCode);
            var baseResponse = new BaseResponse { Message = body ?? string.Empty };
            var baseResponseBytes = Encoding.UTF8.GetBytes(baseResponse.ToJson());
            response.Setup(r => r.Body).Returns(new MemoryStream(baseResponseBytes));
            response.Object.Body.Seek(0L, SeekOrigin.Begin);
            return response.Object;
        });

        return request;
    }

    [Test]
    public async Task CreateOkJsonResponse_NoBodyNoLogger_ReturnsOkResponse()
    {
        var request = GetMockRequestData(HttpStatusCode.OK);

        var response = await request.Object.CreateOkJsonResponse();
        if (response == null)
        {
            Assert.Fail("Response was null.");
        }
        else
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            var baseResponse = await new StreamReader(response.Body).ReadToEndAsync();

            Assert.That(baseResponse, Is.Not.Null);
            Assert.That(baseResponse, Is.EqualTo(string.Empty));
        }
    }

    [Test]
    public async Task CreateOkJsonResponse_WithBodyNoLogger_ReturnsOkResponse()
    {
        const string bodyText = "OK body test";

        var request = GetMockRequestData(HttpStatusCode.OK, bodyText);

        var response = await request.Object.CreateOkJsonResponse(bodyText);
        if (response == null)
        {
            Assert.Fail("Response was null.");
        }
        else
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            var body = response.Body;
            body.Seek(0L, SeekOrigin.Begin);
            var baseResponse = await new StreamReader(body).ReadToEndAsync();

            Assert.That(baseResponse, Is.Not.Null);
            Assert.That(baseResponse, Is.Not.EqualTo(string.Empty));
            Assert.That(baseResponse, Contains.Substring("\"message\""));
        }
    }

    [Test]
    public async Task CreateOkJsonResponse_WithBodyAndLogger_ReturnsOkResponse()
    {
        const string bodyText = "OK body plus logger test";

        var mockLogger = new Mock<ILogger<HttpRequestData>>();

        var request = GetMockRequestData(HttpStatusCode.OK, bodyText);

        var response = await request.Object.CreateOkJsonResponse(bodyText, mockLogger.Object);
        if (response == null)
        {
            Assert.Fail("Response was null.");
        }
        else
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            var body = response.Body;
            body.Seek(0L, SeekOrigin.Begin);
            var baseResponse = await new StreamReader(body).ReadToEndAsync();

            Assert.That(baseResponse, Is.Not.Null);
            Assert.That(baseResponse, Is.Not.EqualTo(string.Empty));
            Assert.That(baseResponse, Contains.Substring("\"message\""));
            Assert.That(mockLogger.Invocations, Is.Not.Empty);

            mockLogger.Verify(logger => logger.Log(
                    It.Is<LogLevel>(logLevel => logLevel == LogLevel.Information),
                    It.Is<EventId>(eventId => eventId.Id == 0),
                    It.Is<It.IsAnyType>((state, _) => state.ToString() == bodyText),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()!),
                Times.Once()
            );
        }
    }

    [Test]
    public async Task CreateOkJsonResponse_WithBodyAndLogger_ReturnsBadRequestResponse()
    {
        const string bodyText = "Bad request body plus logger test";

        var mockLogger = new Mock<ILogger<HttpRequestData>>();

        var request = GetMockRequestData(HttpStatusCode.BadRequest, bodyText);

        var response = await request.Object.CreateBadRequestJsonResponse(bodyText, mockLogger.Object);
        if (response == null)
        {
            Assert.Fail("Response was null.");
        }
        else
        {
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            var body = response.Body;
            body.Seek(0L, SeekOrigin.Begin);
            var baseResponse = await new StreamReader(body).ReadToEndAsync();

            Assert.That(baseResponse, Is.Not.Null);
            Assert.That(baseResponse, Is.Not.EqualTo(string.Empty));
            Assert.That(baseResponse, Contains.Substring("\"message\""));
            Assert.That(baseResponse, Contains.Substring(bodyText));
            Assert.That(mockLogger.Invocations, Is.Not.Empty);

            mockLogger.Verify(logger => logger.Log(
                    It.Is<LogLevel>(logLevel => logLevel == LogLevel.Error),
                    It.Is<EventId>(eventId => eventId.Id == 0),
                    It.Is<It.IsAnyType>((state, _) => state.ToString() == bodyText),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()!),
                Times.Once()
            );
        }
    }
}