﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using TCC.Functions.Functions;
using TCC.Functions.Interfaces;
using System.Text;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Implementations;


namespace TCC.Functions.Tests.Functions
{
    public class AdminConferenceInfoTests
    {
        private Mock<ILogger<AdminPostConferenceInfo>> _logger = null!;
        private Mock<IAdminService> _conferenceInfoServiceMock = null!;
        private AdminPostConferenceInfo _sut = null!;
        private Mock<IPublicDataService> _publicDataService;
        private Mock<IHttpService> _httpService = null!;
        private Mock<IAzureADService> _azureAdService = null!;
        private Mock<IAuthUserService> _authUserService = null!;
        [SetUp]
        public void Setup()
        {
            _logger = new Mock<ILogger<AdminPostConferenceInfo>>();
            _conferenceInfoServiceMock = new Mock<IAdminService>();
            _publicDataService = new Mock<IPublicDataService>();
            _httpService = new Mock<IHttpService>();
            _azureAdService = new Mock<IAzureADService>();
            _authUserService = new Mock<IAuthUserService>();
            _sut = new AdminPostConferenceInfo(_conferenceInfoServiceMock.Object, _logger.Object, _publicDataService.Object, _httpService.Object, _azureAdService.Object, _authUserService.Object);
        }

        [Test]
        public async Task Run_WhenAuthorizationHeaderIsMissing_ReturnsUnauthorizedStatusCode()
        {
            UnitTestDetector.SetOverrideValue(false);

            // Arrange
            var contextMock = new Mock<FunctionContext>();
            var httpRequestDataMock = new Mock<HttpRequestData>(contextMock.Object);
            var headers = new HttpHeadersCollection();
            // Simulate missing "Authorization" header by not adding it to the collection
            httpRequestDataMock.Setup(r => r.Headers).Returns(headers);

            httpRequestDataMock.Setup(r => r.CreateResponse()).Returns(() =>
            {
                var httpResponseDataMock = new Mock<HttpResponseData>(contextMock.Object);
                httpResponseDataMock.SetupProperty(r => r.Headers, new HttpHeadersCollection());
                httpResponseDataMock.SetupProperty(r => r.StatusCode, HttpStatusCode.OK);
                httpResponseDataMock.SetupProperty(r => r.Body, new MemoryStream());
                return httpResponseDataMock.Object;
            });

            var response = await _sut.RunAsync(httpRequestDataMock.Object);

            // Assert that the response status code is Unauthorized due to missing Authorization header
            Assert.AreEqual(HttpStatusCode.Unauthorized, response.StatusCode);
            UnitTestDetector.SetOverrideValue(null);

        }

        [Test]
        public async Task RunAsync_ValidRequest_ReturnsOKResponse()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);



            var requestBody = "{\"Id\":\"4ab18025-dd35-4438-877d-e9e800f10610\", \"Name\":\"Windy City Conference\", \"Address1\":\"7900 Division St\", \"Address2\":\"\", \"City\":\"River Forest\",\"State\":\"IL\",\"Zip\":\"6001\",\"Email\":\"contactus@windycityconference.com\",\"Description\":\"This is test stuff\",\"Phone\":\"700-700-7000\",\"Image\":\"../../assets/jumbotron.svg\",\"MissionStatement\":\"this is test\",\"LocationHeader\":\"hello test\",\"MiscInfo\":\"my info\",\"StaffDescription\":\"staff test data\"}"u8.ToArray();

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
            var sutResult = await _sut.RunAsync(request.Object);

            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));

        }
        [Test]
        public async Task RunAsync_InValidRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var invalidRequestBody = "test"u8.ToArray();

            var invalidRequest = new Mock<HttpRequestData>(context.Object);
            invalidRequest.Setup(req => req.Body).Returns(new MemoryStream(invalidRequestBody));
            invalidRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var invalidResult = await _sut.RunAsync(invalidRequest.Object);
            Assert.That(invalidResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        }
        [Test]
        public async Task RunAsync_EmptyRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var emptyRequestBody = Encoding.UTF8.GetBytes("");
            var emptyRequest = new Mock<HttpRequestData>(context.Object);
            emptyRequest.Setup(req => req.Body).Returns(new MemoryStream(emptyRequestBody));
            emptyRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });
            var emptyResult = await _sut.RunAsync(emptyRequest.Object);
            Assert.That(emptyResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));

        }

        [Test]
        public async Task RunAsync_InCompleteRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var incompleteRequestBody = "{\"Name\":\"Windy City Conference\", \"Address1\":\"7900 Division St\", \"Address2\":\"\", \"City\":\"River Forest\",\"State\":\"IL\",\"Zip\":\"6001\",\"Email\":\"contactus@windycityconference.com\",\"Description\":\"This is test stuff\",\"Phone\":\"700-700-7000\",\"Image\":\"../../assets/jumbotron.svg\",\"MissionStatement\":\"this is test\",\"LocationHeader\":\"hello test\",\"MiscInfo\":\"my info\",\"StaffDescription\":\"staff test data\"}"u8.ToArray();
            var incompleteRequest = new Mock<HttpRequestData>(context.Object);
            incompleteRequest.Setup(req => req.Body).Returns(new MemoryStream(incompleteRequestBody));
            incompleteRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var incompleteResult = await _sut.RunAsync(incompleteRequest.Object);
            Assert.That(incompleteResult.StatusCode, Is.EqualTo(HttpStatusCode.NoContent));


        }
        [Test]
        public async Task Given_RunAsync_InValidData_ReturnsNoContent()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = "{\"Name\":\"John Smith\", \"Organization\":\"Dominican University\", \"Role\":\"Staff\", \"EmailAddress\":\"john.smith@my.dom.edu\", \"Message\":\"Hello\"}"u8.ToArray();
            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
            var sutResult = await _sut.RunAsync(request.Object);

            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.NoContent));
            _conferenceInfoServiceMock.Verify(service => service.SaveConference(It.IsAny<ConferenceInfoDto>()), Times.Never);
        }

        [Test]
        public async Task Given_RunAsync_ThrowsException_Then_ReturnsBadRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = "{\"Id\":\"4ab18025-dd35-4438-877d-e9e800f10610\", \"Name\":\"Windy City Conference\", \"Address1\":\"7900 Division St\", \"Address2\":\"\", \"City\":\"River Forest\",\"State\":\"IL\",\"Zip\":\"6001\",\"Email\":\"contactus@windycityconference.com\",\"Description\":\"This is test stuff\",\"Phone\":\"700-700-7000\",\"Image\":\"../../assets/jumbotron.svg\",\"MissionStatement\":\"this is test\",\"LocationHeader\":\"hello test\",\"MiscInfo\":\"my info\",\"StaffDescription\":\"staff test data\"}"u8.ToArray();

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
            Exception ex = new Exception("An error occurred while processing the request.");
            _conferenceInfoServiceMock.Setup(c => c.SaveConference(It.IsAny<ConferenceInfoDto>())).Throws(ex);
            var sutResult = await _sut.RunAsync(request.Object);

            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            _conferenceInfoServiceMock.Verify(service => service.SaveConference(It.IsAny<ConferenceInfoDto>()), Times.Once);

        }
    }
}