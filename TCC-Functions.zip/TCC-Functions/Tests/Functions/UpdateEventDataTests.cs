﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using TCC.Functions.Functions;
using TCC.Functions.Interfaces;

using System.Text;
using Newtonsoft.Json;
using TCC.Functions.Implementations.DTO;


namespace TCC.Functions.Tests.Functions
{
    public class UpdateEventDataTests
    {
        private Mock<ILogger<UpdateEventData>> _logger = null!;
        private Mock<IPublicDataService> _publicEventDataService = null!;
        private Mock<IStorageService> _storageService = null!;
        private UpdateEventData _sut = null!;
        [SetUp]
        public void Setup()
        {
            _logger = new Mock<ILogger<UpdateEventData>>();
            _publicEventDataService = new Mock<IPublicDataService>();
            _storageService = new Mock<IStorageService>();
            _sut = new UpdateEventData(_publicEventDataService.Object, _logger.Object);
        }

        [Test]
        public async Task Given_RunAsync_ValidRequest_ReturnsOKResponse()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();
            
            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);
            
            
            var requestBody = Encoding.UTF8.GetBytes(UpdateEventString);
            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });
            _publicEventDataService.Setup(p => p.CreateEventById(It.IsAny<Guid>())).Returns(Task.CompletedTask);
            // Act
            var sutResult = await _sut.RunAsync(request.Object, context.Object);
            
            // Assert the result here
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            _publicEventDataService.Verify(service => service.GetBlobItems(), Times.Once);
            _publicEventDataService.Verify(service => service.CreateEventById(It.IsAny<Guid>()), Times.Once);
            _logger.Verify(l=> l.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((o, t) => string.Equals("Received a request to update event data.", o.ToString(), StringComparison.InvariantCultureIgnoreCase)),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                Times.Once);
            _logger.Verify(l=> l.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((o, t) => string.Equals("Event data updated successfully.", o.ToString(), StringComparison.InvariantCultureIgnoreCase)),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                Times.Once);

        }
        [Test]
        public async Task Given_RunAsync_InvalidRequestWithEmptyString_ReturnsBadRequestResponse()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();
            
            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);
            
            
            var requestBody = Encoding.UTF8.GetBytes(EmptyEventString);
            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });
            _publicEventDataService.Setup(p => p.CreateEventById(It.IsAny<Guid>())).Returns(Task.CompletedTask);
            // Act
            var sutResult = await _sut.RunAsync(request.Object, context.Object);
            
            // Assert the result here
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            _publicEventDataService.Verify(service => service.GetBlobItems(), Times.Never);
            _publicEventDataService.Verify(service => service.CreateEventById(It.IsAny<Guid>()), Times.Never);
            _logger.Verify(l=> l.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((o, t) => string.Equals("Received a request to update event data.", o.ToString(), StringComparison.InvariantCultureIgnoreCase)),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                Times.Once);
            _logger.Verify(l=> l.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((o, t) => string.Equals("Invalid Event Data", o.ToString(), StringComparison.InvariantCultureIgnoreCase)),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                Times.Once);

        }
        [Test]
        public async Task Given_RunAsync_InvalidRequestWithEmptyEventId_ReturnsBadRequestResponse()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();
            
            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);
            
            
            var requestBody = Encoding.UTF8.GetBytes(EmptyEventIdString);
            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });
            _publicEventDataService.Setup(p => p.CreateEventById(It.IsAny<Guid>())).Returns(Task.CompletedTask);
            // Act
            var sutResult = await _sut.RunAsync(request.Object, context.Object);
            
            // Assert the result here
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            _publicEventDataService.Verify(service => service.GetBlobItems(), Times.Never);
            _publicEventDataService.Verify(service => service.CreateEventById(It.IsAny<Guid>()), Times.Never);
            _logger.Verify(l=> l.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((o, t) => string.Equals("Received a request to update event data.", o.ToString(), StringComparison.InvariantCultureIgnoreCase)),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                Times.Once);
            _logger.Verify(l=> l.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((o, t) => string.Equals("Invalid Event Data", o.ToString(), StringComparison.InvariantCultureIgnoreCase)),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                Times.Once);

        }
        [Test]
        public async Task Given_RunAsync_ThrowErrorOnGetBlobItems_ReturnsBadRequestResponse()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();
            
            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);
            
            
            var requestBody = Encoding.UTF8.GetBytes(UpdateEventString);
            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });
            Exception errorException = new Exception("Blob Error");
            _publicEventDataService.Setup(p=>p.GetBlobItems()).Throws(errorException);
            // Act
            var sutResult = await _sut.RunAsync(request.Object, context.Object);
            
            // Assert the result here
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.NotModified));
            _publicEventDataService.Verify(service => service.GetBlobItems(), Times.Once);
            _publicEventDataService.Verify(service => service.CreateEventById(It.IsAny<Guid>()), Times.Never);
            _logger.Verify(l=> l.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((o, t) => string.Equals("Received a request to update event data.", o.ToString(), StringComparison.InvariantCultureIgnoreCase)),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                Times.Once);
            _logger.Verify(l=> l.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((o, t) => string.Equals("There were issues updating the event data.", o.ToString(), StringComparison.InvariantCultureIgnoreCase)),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                Times.Once);

        }
        [Test]
        public async Task Given_RunAsync_ThrowErrorOnCreateEventById_ReturnsBadRequestResponse()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();
            
            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);
            
            
            var requestBody = Encoding.UTF8.GetBytes(UpdateEventString);
            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });
            Exception errorException = new Exception("Blob Error");
            _publicEventDataService.Setup(p=>p.CreateEventById(It.IsAny<Guid>())).Throws(errorException);
            // Act
            var sutResult = await _sut.RunAsync(request.Object, context.Object);
            
            // Assert the result here
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.NotModified));
            _publicEventDataService.Verify(service => service.GetBlobItems(), Times.Once);
            _publicEventDataService.Verify(service => service.CreateEventById(It.IsAny<Guid>()), Times.Once);
            _logger.Verify(l=> l.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((o, t) => string.Equals("Received a request to update event data.", o.ToString(), StringComparison.InvariantCultureIgnoreCase)),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                Times.Once);
            _logger.Verify(l=> l.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((o, t) => string.Equals("There were issues updating the event data.", o.ToString(), StringComparison.InvariantCultureIgnoreCase)),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                Times.Once);

        }
        #region Test Data

        private static readonly string UpdateEventString = "{\"Id\":\"71358ec6-e186-4556-8ac3-dea90112c7a6\"}";
        private static readonly string EmptyEventString = "";
        private static readonly string EmptyEventIdString = "{\"Id\":null}";
        protected static readonly string PrivacyString="Some Privacy Policy";
        protected static readonly string CodeOfConductString="Some Code of Conduct";
        protected static readonly string ConferenceInfoString = "{\r\n    \"Id\": \"4ab18025-dd35-4438-877d-e9e800f10610\",\r\n    \"Name\": \"Windy City Conference\",\r\n    \"Address1\": \"7900 Division St\",\r\n    \"Address2\": null,\r\n    \"City\": \"River Forest\",\r\n    \"State\": \"IL\",\r\n    \"Zip\": \"60305\",\r\n    \"Email\":\"contactus@windycityconference.com\",\r\n    \"Description\": \"<p>The Windy City Conference is a one-day event that brings together the best and brightest in the tech industry for a day of learning, networking, and sharing. The conference is organized by the Chicago .NET User Group and is a not-for-profit event. All proceeds go to the Chicago .NET User Group, a 501c3 non-profit organization.</p>\",  \r\n    \"Phone\": \"555-555-5555\",\r\n    \"Image\":\"../../assets/jumbotron.svg\",\r\n    \"MissionStatement\": \" <h2 className='aboutHeaders'>The Mission</h2><p>The mission of Windy City Conference is to provide a credible resource within the IT industry:<br></br> to <span className='aboutBold'>learn</span> about advancements in our field,<br></br> to <span className='aboutBold'>share</span> knowledge from our experiences, and<br></br> to <span className='aboutBold'>develop</span> valued relationships with ourpeers </p>\",\r\n    \"LocationHeader\": \"<h2 className='aboutHeaders'>Location</h2>\",\r\n    \"MiscInfo\": \"<h2 className='aboutHeaders'>What We Offer For You</h2><p>As a day-long event, we are here to connect the talent and expertise within the Developer community of the Windy City. Discussions for the day have previously included development and trending topics in .net, java, open sourced frameworks, web, mobile, cloud, robotics, testing, soft skills, and more.</p><h2 className='aboutHeaders'>Why Windy City Conference?</h2><p>We are still the same conference that was started 12 years ago. The same spirit and urge to learn has never went away. Infact, the hunger for knowledge and sharing of information has increase for every one of our organizers, volunteers, speakers, and attendees.</p><p>In order to accomodate more diverge technologies and offerings, the organizers decided to re-brand the Chicago Code Camp as Windy City Conference. We are still paying tribute to the code camp that started it all and looking forward to bigger and better conference for everyone!</p>\",\r\n    \"StaffDescription\": \"The Windy City Conference is organized by the Chicago .NET User Group. The conference is run by a team of volunteers who are passionate about the local tech community.\"\r\n  }\r\n";
        private static readonly UpdateEventDto? UpdateEvent = JsonConvert.DeserializeObject<UpdateEventDto>(UpdateEventString);

        [ExcludeFromCodeCoverage]
        private List<string> GetValidBlobItems()
        {
            List<string> result =
            [
                "users/TestUser1/TestUser1.json",
                "users/TestUser2/TestUser2.json",
                "events/event1/event1.json",
                "events/event2/event2.json",
                "events/event1/sessions/session1.json",
                "events/event1/sessions/session2.json",
                "events/event2/sessions/session1.json"
            ];
            return result;
        }
        #endregion

    }
}