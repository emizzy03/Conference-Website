﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using TCC.Functions.Interfaces;
using System.Text;
using TCC.Functions.Implementations.DTO;
using Newtonsoft.Json;
using TCC.Functions.Functions.User;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Implementations;

namespace TCC.Functions.Tests.Functions
{
    public class PostUsersTests
    {
        private Mock<ILogger<PostUsers>> _logger = null!;
        private Mock<IUserService> _userServiceMock = null!;
        private PostUsers _sut = null!;
        private Mock<IHttpService> _httpService = null!;
        private Mock<IAzureADService> _azureAdService = null!;
        private Mock<IAuthUserService> _authUserService = null!;

        [SetUp]
        public void Setup()
        {
            _logger = new Mock<ILogger<PostUsers>>();
            _userServiceMock = new Mock<IUserService>();
            _httpService = new Mock<IHttpService>();
            _azureAdService = new Mock<IAzureADService>();
            _authUserService = new Mock<IAuthUserService>();
            _sut = new PostUsers(_userServiceMock.Object, _logger.Object, _httpService.Object, _azureAdService.Object, _authUserService.Object);
        }

        [Test]
        public async Task Run_WhenAuthorizationHeaderIsMissing_ReturnsUnauthorizedStatusCode()
        {
            UnitTestDetector.SetOverrideValue(false);

            // Arrange
            var contextMock = new Mock<FunctionContext>();
            var httpRequestDataMock = new Mock<HttpRequestData>(contextMock.Object);
            var headers = new HttpHeadersCollection();
            // Simulate missing "Authorization" header by not adding it to the collection
            httpRequestDataMock.Setup(r => r.Headers).Returns(headers);

            httpRequestDataMock.Setup(r => r.CreateResponse()).Returns(() =>
            {
                var httpResponseDataMock = new Mock<HttpResponseData>(contextMock.Object);
                httpResponseDataMock.SetupProperty(r => r.Headers, new HttpHeadersCollection());
                httpResponseDataMock.SetupProperty(r => r.StatusCode, HttpStatusCode.OK);
                httpResponseDataMock.SetupProperty(r => r.Body, new MemoryStream());
                return httpResponseDataMock.Object;
            });

            var response = await _sut.RunAsync(httpRequestDataMock.Object);

            // Assert that the response status code is Unauthorized due to missing Authorization header
            Assert.AreEqual(HttpStatusCode.Unauthorized, response.StatusCode);
            UnitTestDetector.SetOverrideValue(null);

        }

        [Test]
        public async Task Given_PostUser_ValidRequest_ReturnOKStatusCode()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = Encoding.UTF8.GetBytes(updateUserString);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });

             //Act
            var sutResult = await _sut.RunAsync(request.Object);
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));
           _userServiceMock.Verify(service => service.SaveUser(It.IsAny<UserDTO>(), Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"), "saved" ), Times.Once);
           _userServiceMock.Verify(service => service.DeleteUserSocialMedia($"users/25b2fd9c-2b51-472a-8e1a-695f74e8beb2/socialmedia/25b2fd9c-2b51-472a-8e1a-695f74e8beb2.json"), Times.Never);
           _userServiceMock.Verify(service => service.SaveUserSocialMedia(It.IsAny<IEnumerable<UserSocialMediaDTO>>(), Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"), "saved"),Times.Once);
        }

        [Test]
        public async Task Given_PostUser_MeptySocialMedia_DeleteUserSocialMedia_ReturnOKStatusCode()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = Encoding.UTF8.GetBytes(DeleteUserSocialMedia);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });

            //Act
            var sutResult = await _sut.RunAsync(request.Object);
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            _userServiceMock.Verify(service => service.SaveUser(It.IsAny<UserDTO>(), Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"), "saved"), Times.Once);
            _userServiceMock.Verify(service => service.DeleteUserSocialMedia($"users/25b2fd9c-2b51-472a-8e1a-695f74e8beb2/socialmedia/25b2fd9c-2b51-472a-8e1a-695f74e8beb2.json"), Times.Once);
            _userServiceMock.Verify(service => service.SaveUserSocialMedia(It.IsAny<IEnumerable<UserSocialMediaDTO>>(), Guid.Parse("25b2fd9c-2b51-472a-8e1a-695f74e8beb2"), "saved"), Times.Never);
        }

        [Test]
        public async Task Given_PostNewUser_ValidRequest_ReturnOKStatusCode()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();
            

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);
      
            var requestBody = Encoding.UTF8.GetBytes(CreateNewUserString);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
           
            //Act
            var sutResult = await _sut.RunAsync(request.Object);


            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            _userServiceMock.Verify(service => service.SaveUser(It.IsAny<UserDTO>(), It.IsAny<Guid>() , "created"), Times.Once);
            _userServiceMock.Verify(service => service.SaveUserSocialMedia(It.IsAny<IEnumerable<UserSocialMediaDTO>>(), It.IsAny<Guid>(), "created"), Times.Once);
        }

        [Test]
        public async Task Given_PostUser_RunAsync_InvalidRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var invalidRequestBody = "test"u8.ToArray();

            var invalidRequest = new Mock<HttpRequestData>(context.Object);
            invalidRequest.Setup(req => req.Body).Returns(new MemoryStream(invalidRequestBody));
            invalidRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var invalidResult = await _sut.RunAsync(invalidRequest.Object);
            Assert.That(invalidResult.StatusCode, Is.EqualTo(HttpStatusCode.UnprocessableContent));

        }

        [Test]
        public async Task Given_PostUser_RunAsync_EmptyRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var emptyRequestBody = Encoding.UTF8.GetBytes("");

            var emptyRequest = new Mock<HttpRequestData>(context.Object);
            emptyRequest.Setup(req => req.Body).Returns(new MemoryStream(emptyRequestBody));
            emptyRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var emptyResult = await _sut.RunAsync(emptyRequest.Object);
            Assert.That(emptyResult.StatusCode, Is.EqualTo(HttpStatusCode.UnprocessableContent));

        }

        [Test]
        public async Task Given_PostUser_RunAsync_NullRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var incompleteRequest = new Mock<HttpRequestData>(context.Object);
            incompleteRequest.Setup(req => req.Body).Returns((Stream)null);
            incompleteRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var incompleteResult = await _sut.RunAsync(incompleteRequest.Object);
            Assert.That(incompleteResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        }


        [Test]
        public async Task Given_PostUser_RunAsync_IncompleteRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var incompleteRequestBody = Encoding.UTF8.GetBytes(incompleteUserString);

            var incompleteRequest = new Mock<HttpRequestData>(context.Object);
            incompleteRequest.Setup(req => req.Body).Returns(new MemoryStream(incompleteRequestBody));
            incompleteRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var incompleteResult = await _sut.RunAsync(incompleteRequest.Object);
            Assert.That(incompleteResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));

        }
        [Test]
        public async Task Given_PostUser_RunAsync_InvalidData_ReturnsNoContent()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = Encoding.UTF8.GetBytes(InvalidUserString);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
            var sutResult = await _sut.RunAsync(request.Object);
            var id = Guid.NewGuid();

            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            _userServiceMock.Verify(service => service.SaveUser(It.IsAny<UserDTO>(), id, "Created"), Times.Never);
            _userServiceMock.Verify(service => service.DeleteUserSocialMedia($"users/{id}/socialmedia/{id}.json"), Times.Never);
            _userServiceMock.Verify(service => service.SaveUserSocialMedia(It.IsAny<IEnumerable<UserSocialMediaDTO>>(), id, "Created"), Times.Never);

        }

        [Test]
        public async Task Given_PostCallDoesError_ThenReturnBadRequestStatuscode()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);


            var requestBody = Encoding.UTF8.GetBytes(updateUserString);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
            Exception ex = new Exception("An error occurred while processing the request.");
           _userServiceMock.Setup(c => c.SaveUser(It.IsAny<UserDTO>(), It.IsAny<Guid>() , It.IsAny<string>())).Throws(ex);
            var sutResult = await _sut.RunAsync(request.Object);

            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
          _userServiceMock.Verify(service => service.SaveUser(It.IsAny<UserDTO>(), It.IsAny<Guid>(), It.IsAny<string>()), Times.Once);

        }

        #region Test Data
        private static readonly string CreateNewUserString = "{\"FirstName\":\"Minnn\",\"LastName\":\"Maung\",\"Email\":\"min@maungs.com\",\"Biography\":\"Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.\",\"PictureLink\":\"http://www.gravatar.com/avatar/099173ab96424339e82de5ad2b447ed3?s=250&&r=G\",\"SocialMediaLinks\":[{\"UserSocialMediaId\":\"5a732ca6-8f99-4943-bd0d-29847ec21e29\",\"SocialMediaPlatformId\":\"e4b6ad76-60da-4f2b-bef9-a47b18daead4\",\"UserId\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"SocialMediaLink\":\"https://twitter.com/\",\"SocialMediaIcon\":\"fa-twitter-square\"},{\"UserSocialMediaId\":\"7397823f-3c3a-48dd-bf90-ace6693085d6\",\"SocialMediaPlatformId\":\"0db5ddac-1c4e-4cb9-a510-1fc003922861\",\"UserId\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"SocialMediaLink\":\"https://www.linkedin.com/\",\"SocialMediaIcon\":\"fa-linkedin-square\"}],\"PresentationSessions\":[\"a8292a14-3f7b-4fef-b0a5-27584cc6fa96\",\"26dcb903-1bb0-4551-85fe-163736bdf80d\",\"7acff94c-dbf4-44c1-bd4b-e887b8dd01f8\",\"c98a89be-f6dd-4a98-bbdf-52924dbb4410\",\"90355858-9a37-4d15-9b74-e8c1a8a230b2\",\"7b6b2037-9146-4f9e-ae4c-6771fe1995a7\",\"a10967b6-e307-4759-a36b-98c2c2fc2f90\",\"2418db21-7944-49fc-b4f3-68948e9ef0f9\",\"1eeff8a5-3aaa-4080-bcd7-d447ec7465b5\",\"d7544eb6-816c-47f5-aabf-81970d3850fd\",\"3abc5b89-3c6e-49e1-990f-53f986e0ad37\",\"d40f0b15-8466-45bc-8b0a-f0d21f7b44f9\",\"b77d5f01-05ae-4fb8-8c78-ac36376c451c\",\"290be8fc-7e43-4b23-854f-d82da875a3b6\",\"a970b9e5-8996-4ad7-a38b-93943d7bfe15\",\"f1ef4255-1829-424c-857b-085d039822cf\",\"9fe7ced4-365a-4c95-9158-248a3ccaf592\",\"c65730c6-379a-4569-a749-3a12786b50fd\",\"1305c920-7c7c-4c18-9900-247cc67395aa\",\"ba46b2ec-07d0-4083-a0ac-60c1580403a6\",\"c06e43dd-eb8f-4525-a5f2-59b883b34c08\",\"80d86fff-e37d-4a23-a8d2-36cb0357cfe5\",\"78047456-a74c-4d5d-8159-3a03b4ff475a\",\"b33e4d0a-7ce8-4dcb-a9ef-4ae56cf1dfdd\",\"e6b02251-a533-4871-a1e9-72a7c21087fb\",\"f693f1a0-6afe-4354-8b41-72752dce6f1f\"]}";
        private static readonly string InvalidUserString = "{\"Id\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"FirstName\":\"\",\"LastName\":\"\",\"Email\":\"min@maungs.com\",\"Biography\":\"Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.\",\"PictureLink\":\"http://www.gravatar.com/avatar/099173ab96424339e82de5ad2b447ed3?s=250&&r=G\",\"SocialMediaLinks\":[{\"UserSocialMediaId\":\"5a732ca6-8f99-4943-bd0d-29847ec21e29\",\"SocialMediaPlatformId\":\"e4b6ad76-60da-4f2b-bef9-a47b18daead4\",\"UserId\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"SocialMediaLink\":\"https://twitter.com/\",\"SocialMediaIcon\":\"fa-twitter-square\"},{\"UserSocialMediaId\":\"7397823f-3c3a-48dd-bf90-ace6693085d6\",\"SocialMediaPlatformId\":\"0db5ddac-1c4e-4cb9-a510-1fc003922861\",\"UserId\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"SocialMediaLink\":\"https://www.linkedin.com/\",\"SocialMediaIcon\":\"fa-linkedin-square\"}],\"PresentationSessions\":[\"a8292a14-3f7b-4fef-b0a5-27584cc6fa96\",\"26dcb903-1bb0-4551-85fe-163736bdf80d\",\"7acff94c-dbf4-44c1-bd4b-e887b8dd01f8\",\"c98a89be-f6dd-4a98-bbdf-52924dbb4410\",\"90355858-9a37-4d15-9b74-e8c1a8a230b2\",\"7b6b2037-9146-4f9e-ae4c-6771fe1995a7\",\"a10967b6-e307-4759-a36b-98c2c2fc2f90\",\"2418db21-7944-49fc-b4f3-68948e9ef0f9\",\"1eeff8a5-3aaa-4080-bcd7-d447ec7465b5\",\"d7544eb6-816c-47f5-aabf-81970d3850fd\",\"3abc5b89-3c6e-49e1-990f-53f986e0ad37\",\"d40f0b15-8466-45bc-8b0a-f0d21f7b44f9\",\"b77d5f01-05ae-4fb8-8c78-ac36376c451c\",\"290be8fc-7e43-4b23-854f-d82da875a3b6\",\"a970b9e5-8996-4ad7-a38b-93943d7bfe15\",\"f1ef4255-1829-424c-857b-085d039822cf\",\"9fe7ced4-365a-4c95-9158-248a3ccaf592\",\"c65730c6-379a-4569-a749-3a12786b50fd\",\"1305c920-7c7c-4c18-9900-247cc67395aa\",\"ba46b2ec-07d0-4083-a0ac-60c1580403a6\",\"c06e43dd-eb8f-4525-a5f2-59b883b34c08\",\"80d86fff-e37d-4a23-a8d2-36cb0357cfe5\",\"78047456-a74c-4d5d-8159-3a03b4ff475a\",\"b33e4d0a-7ce8-4dcb-a9ef-4ae56cf1dfdd\",\"e6b02251-a533-4871-a1e9-72a7c21087fb\",\"f693f1a0-6afe-4354-8b41-72752dce6f1f\"]}";
        private static readonly string DeleteUserSocialMedia = "{\"Id\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"FirstName\":\"Minnn\",\"LastName\":\"Maung\",\"Email\":\"min@maungs.com\",\"Biography\":\"Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.\",\"PictureLink\":\"http://www.gravatar.com/avatar/099173ab96424339e82de5ad2b447ed3?s=250&&r=G\",\"PresentationSessions\":[\"a8292a14-3f7b-4fef-b0a5-27584cc6fa96\",\"26dcb903-1bb0-4551-85fe-163736bdf80d\",\"7acff94c-dbf4-44c1-bd4b-e887b8dd01f8\",\"c98a89be-f6dd-4a98-bbdf-52924dbb4410\",\"90355858-9a37-4d15-9b74-e8c1a8a230b2\",\"7b6b2037-9146-4f9e-ae4c-6771fe1995a7\",\"a10967b6-e307-4759-a36b-98c2c2fc2f90\",\"2418db21-7944-49fc-b4f3-68948e9ef0f9\",\"1eeff8a5-3aaa-4080-bcd7-d447ec7465b5\",\"d7544eb6-816c-47f5-aabf-81970d3850fd\",\"3abc5b89-3c6e-49e1-990f-53f986e0ad37\",\"d40f0b15-8466-45bc-8b0a-f0d21f7b44f9\",\"b77d5f01-05ae-4fb8-8c78-ac36376c451c\",\"290be8fc-7e43-4b23-854f-d82da875a3b6\",\"a970b9e5-8996-4ad7-a38b-93943d7bfe15\",\"f1ef4255-1829-424c-857b-085d039822cf\",\"9fe7ced4-365a-4c95-9158-248a3ccaf592\",\"c65730c6-379a-4569-a749-3a12786b50fd\",\"1305c920-7c7c-4c18-9900-247cc67395aa\",\"ba46b2ec-07d0-4083-a0ac-60c1580403a6\",\"c06e43dd-eb8f-4525-a5f2-59b883b34c08\",\"80d86fff-e37d-4a23-a8d2-36cb0357cfe5\",\"78047456-a74c-4d5d-8159-3a03b4ff475a\",\"b33e4d0a-7ce8-4dcb-a9ef-4ae56cf1dfdd\",\"e6b02251-a533-4871-a1e9-72a7c21087fb\",\"f693f1a0-6afe-4354-8b41-72752dce6f1f\"]}";
        private static readonly string incompleteUserString = "{\"Id\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"FirstName\":\"\",\"LastName\":\"\",\"Email\":\"min@maungs.com\",\"Biography\":\"Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.\",\"PictureLink\":\"http://www.gravatar.com/avatar/099173ab96424339e82de5ad2b447ed3?s=250&&r=G\",\"SocialMediaLinks\":[{\"UserSocialMediaId\":\"5a732ca6-8f99-4943-bd0d-29847ec21e29\",\"SocialMediaPlatformId\":\"e4b6ad76-60da-4f2b-bef9-a47b18daead4\",\"UserId\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"SocialMediaLink\":\"https://twitter.com/\",\"SocialMediaIcon\":\"fa-twitter-square\"},{\"UserSocialMediaId\":\"7397823f-3c3a-48dd-bf90-ace6693085d6\",\"SocialMediaPlatformId\":\"0db5ddac-1c4e-4cb9-a510-1fc003922861\",\"UserId\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"SocialMediaLink\":\"https://www.linkedin.com/\",\"SocialMediaIcon\":\"fa-linkedin-square\"}],\"PresentationSessions\":[\"a8292a14-3f7b-4fef-b0a5-27584cc6fa96\",\"26dcb903-1bb0-4551-85fe-163736bdf80d\",\"7acff94c-dbf4-44c1-bd4b-e887b8dd01f8\",\"c98a89be-f6dd-4a98-bbdf-52924dbb4410\",\"90355858-9a37-4d15-9b74-e8c1a8a230b2\",\"7b6b2037-9146-4f9e-ae4c-6771fe1995a7\",\"a10967b6-e307-4759-a36b-98c2c2fc2f90\",\"2418db21-7944-49fc-b4f3-68948e9ef0f9\",\"1eeff8a5-3aaa-4080-bcd7-d447ec7465b5\",\"d7544eb6-816c-47f5-aabf-81970d3850fd\",\"3abc5b89-3c6e-49e1-990f-53f986e0ad37\",\"d40f0b15-8466-45bc-8b0a-f0d21f7b44f9\",\"b77d5f01-05ae-4fb8-8c78-ac36376c451c\",\"290be8fc-7e43-4b23-854f-d82da875a3b6\",\"a970b9e5-8996-4ad7-a38b-93943d7bfe15\",\"f1ef4255-1829-424c-857b-085d039822cf\",\"9fe7ced4-365a-4c95-9158-248a3ccaf592\",\"c65730c6-379a-4569-a749-3a12786b50fd\",\"1305c920-7c7c-4c18-9900-247cc67395aa\",\"ba46b2ec-07d0-4083-a0ac-60c1580403a6\",\"c06e43dd-eb8f-4525-a5f2-59b883b34c08\",\"80d86fff-e37d-4a23-a8d2-36cb0357cfe5\",\"78047456-a74c-4d5d-8159-3a03b4ff475a\",\"b33e4d0a-7ce8-4dcb-a9ef-4ae56cf1dfdd\",\"e6b02251-a533-4871-a1e9-72a7c21087fb\",\"f693f1a0-6afe-4354-8b41-72752dce6f1f\"]}";
        private static readonly string updateUserString = "{\"Id\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"FirstName\":\"Minnn\",\"LastName\":\"Maung\",\"Email\":\"min@maungs.com\",\"Biography\":\"Name a new technology that Min isn’t interested in. Min has developed on all mobile platforms from latest Windows 10 to Windows Mobile 6.5. Of course that also means that he has had countless smartphones and tablets. Min is often honing his skills by aggressively competing in hackathons dating back to his days at Dominican University. Being technologically agnostic, he does not stop tinkering with mobile platforms like Android, he creates his own personal microcontrollers for robotics projects. When he’s not coding, he’s building robots. When he’s not adding more robots to his robot army, you will see him speaking at conferences such as That Conference and CodeMash. Monday through Friday, you’ll find him at Concurrency Inc., cranking out .Net code and writing apps in ASP.Net Core, Knockout.js, Node.js, and other web solutions.\",\"PictureLink\":\"http://www.gravatar.com/avatar/099173ab96424339e82de5ad2b447ed3?s=250&&r=G\",\"SocialMediaLinks\":[{\"UserSocialMediaId\":\"5a732ca6-8f99-4943-bd0d-29847ec21e29\",\"SocialMediaPlatformId\":\"e4b6ad76-60da-4f2b-bef9-a47b18daead4\",\"UserId\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"SocialMediaLink\":\"https://twitter.com/\",\"SocialMediaIcon\":\"fa-twitter-square\"},{\"UserSocialMediaId\":\"7397823f-3c3a-48dd-bf90-ace6693085d6\",\"SocialMediaPlatformId\":\"0db5ddac-1c4e-4cb9-a510-1fc003922861\",\"UserId\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"SocialMediaLink\":\"https://www.linkedin.com/\",\"SocialMediaIcon\":\"fa-linkedin-square\"}],\"PresentationSessions\":[\"a8292a14-3f7b-4fef-b0a5-27584cc6fa96\",\"26dcb903-1bb0-4551-85fe-163736bdf80d\",\"7acff94c-dbf4-44c1-bd4b-e887b8dd01f8\",\"c98a89be-f6dd-4a98-bbdf-52924dbb4410\",\"90355858-9a37-4d15-9b74-e8c1a8a230b2\",\"7b6b2037-9146-4f9e-ae4c-6771fe1995a7\",\"a10967b6-e307-4759-a36b-98c2c2fc2f90\",\"2418db21-7944-49fc-b4f3-68948e9ef0f9\",\"1eeff8a5-3aaa-4080-bcd7-d447ec7465b5\",\"d7544eb6-816c-47f5-aabf-81970d3850fd\",\"3abc5b89-3c6e-49e1-990f-53f986e0ad37\",\"d40f0b15-8466-45bc-8b0a-f0d21f7b44f9\",\"b77d5f01-05ae-4fb8-8c78-ac36376c451c\",\"290be8fc-7e43-4b23-854f-d82da875a3b6\",\"a970b9e5-8996-4ad7-a38b-93943d7bfe15\",\"f1ef4255-1829-424c-857b-085d039822cf\",\"9fe7ced4-365a-4c95-9158-248a3ccaf592\",\"c65730c6-379a-4569-a749-3a12786b50fd\",\"1305c920-7c7c-4c18-9900-247cc67395aa\",\"ba46b2ec-07d0-4083-a0ac-60c1580403a6\",\"c06e43dd-eb8f-4525-a5f2-59b883b34c08\",\"80d86fff-e37d-4a23-a8d2-36cb0357cfe5\",\"78047456-a74c-4d5d-8159-3a03b4ff475a\",\"b33e4d0a-7ce8-4dcb-a9ef-4ae56cf1dfdd\",\"e6b02251-a533-4871-a1e9-72a7c21087fb\",\"f693f1a0-6afe-4354-8b41-72752dce6f1f\"]}";
        private static readonly UserDTO? UpdateUserSTring = JsonConvert.DeserializeObject<UserDTO>(updateUserString);
        #endregion

    }
}
