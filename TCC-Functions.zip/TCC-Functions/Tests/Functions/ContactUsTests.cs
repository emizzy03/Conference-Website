﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using TCC.Functions.Functions;
using TCC.Functions.Interfaces;

using System.Text;
using TCC.Functions.Implementations.DTO;


namespace TCC.Functions.Tests.Functions
{
    public class ContactUsTests
    {
        private Mock<ILogger<ContactUsFunction>> _logger = null!;
        private Mock<IContactUsService> _contactUsService = null!;
        private ContactUsFunction _sut = null!;
        [SetUp]
        public void Setup()
        {
            _logger = new Mock<ILogger<ContactUsFunction>>();
            _contactUsService = new Mock<IContactUsService>();
            _sut = new ContactUsFunction(_contactUsService.Object, _logger.Object);
        }

        [Test]
        public async Task RunAsync_ValidRequest_ReturnsOKResponse()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = "{\"name\":\"John Smith\", \"organization\":\"Dominican University\", \"role\":\"Staff\", \"emailAddress\":\"john.smith@my.dom.edu\", \"message\":\"Hello\"}"u8.ToArray();

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
            var sutResult = await _sut.RunAsync(request.Object);

            // Assert the result here
            Assert.That(sutResult?.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            _contactUsService.Verify(service => service.ProcessContactUsData(It.IsAny<ContactUsDto>()), Times.Once);
        }
        
        [Test]
        public async Task RunAsync_InvalidRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var invalidRequestBody = "6778:89"u8.ToArray();

            var invalidRequest = new Mock<HttpRequestData>(context.Object);
            invalidRequest.Setup(req => req.Body).Returns(new MemoryStream(invalidRequestBody));
            invalidRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var invalidResult = await _sut.RunAsync(invalidRequest.Object);
            Assert.That(invalidResult?.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            //_contactUsService.Verify(service => service.ProcessContactUsData(It.IsAny<ContactUsDTO>()), Times.Never);

        }
        [Test]
        public async Task RunAsync_EmptyRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var emptyRequestBody = Encoding.UTF8.GetBytes("");
            var emptyRequest = new Mock<HttpRequestData>(context.Object);
            emptyRequest.Setup(req => req.Body).Returns(new MemoryStream(emptyRequestBody));
            emptyRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });
            var emptyResult = await _sut.RunAsync(emptyRequest.Object);
            Assert.That(emptyResult?.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        }
        
        [Test]
        public async Task RunAsync_IncompleteRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var incompleteRequestBody = "{\"name\":\"John Smith\", \"organization\":\"Dominican University\"}"u8.ToArray();
            var incompleteRequest = new Mock<HttpRequestData>(context.Object);
            incompleteRequest.Setup(req => req.Body).Returns(new MemoryStream(incompleteRequestBody));
            incompleteRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var incompleteResult = await _sut.RunAsync(incompleteRequest.Object);
            Assert.That(incompleteResult?.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        }
        
        [Test]
        public async Task Given_RunAsync_InvalidData_ReturnsNoContent()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = "{\"name\":\"John Smith\", \"organization\":\"\", \"role\":\"\", \"emailAddress\":\"\", \"message\":\"Hello\"}"u8.ToArray();

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
            var sutResult = await _sut.RunAsync(request.Object);

            // Assert the result here
            Assert.That(sutResult?.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            _contactUsService.Verify(service => service.ProcessContactUsData(It.IsAny<ContactUsDto>()), Times.Never);
        }
        
        [Test]
        public async Task Given_RunAsync_ThrowsException_Then_ReturnsBadRequest()
        { var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = "{\"name\":\"John Smith\", \"organization\":\"Dominican University\", \"role\":\"Staff\", \"emailAddress\":\"john.smith@my.dom.edu\", \"message\":\"Hello\"}"u8.ToArray();

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
            Exception ex = new Exception("An error occurred while processing the request.");
            _contactUsService.Setup(c=> c.ProcessContactUsData(It.IsAny<ContactUsDto>())).Throws(ex);
            var sutResult = await _sut.RunAsync(request.Object);

            // Assert the result here
            Assert.That(sutResult?.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            _contactUsService.Verify(service => service.ProcessContactUsData(It.IsAny<ContactUsDto>()), Times.Once);

        }
    }
}