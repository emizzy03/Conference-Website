﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using System.Text;
using TCC.Functions.Functions.AdminFunctions;
using TCC.Functions.Implementations;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Model;

namespace TCC.Functions.Tests.Functions
{
    public class AdminPostSocialMediaPlatformsTest
    {
        private Mock<IAdminService> _socialMediaPlatformsServiceMock;
        private Mock<ILogger<AdminSocialMediaPlatforms>> _loggerMock;
        private AdminSocialMediaPlatforms _sut;
        private Mock<IHttpService> _httpService = null!;
        private Mock<IAzureADService> _azureAdService = null!;
        private Mock<IAuthUserService> _authUserService = null!;

        [SetUp]
        public void Setup()
        {
            _socialMediaPlatformsServiceMock = new Mock<IAdminService>();
            _loggerMock = new Mock<ILogger<AdminSocialMediaPlatforms>>();
            _httpService = new Mock<IHttpService>();
            _azureAdService = new Mock<IAzureADService>();
            _authUserService = new Mock<IAuthUserService>();
            _sut = new AdminSocialMediaPlatforms(_socialMediaPlatformsServiceMock.Object, _loggerMock.Object, _httpService.Object, _azureAdService.Object, _authUserService.Object);
        }

        [Test]
        public async Task Run_WhenAuthorizationHeaderIsMissing_ReturnsUnauthorizedStatusCode()
        {
            UnitTestDetector.SetOverrideValue(false);

            // Arrange
            var contextMock = new Mock<FunctionContext>();
            var httpRequestDataMock = new Mock<HttpRequestData>(contextMock.Object);
            var headers = new HttpHeadersCollection();
            // Simulate missing "Authorization" header by not adding it to the collection
            httpRequestDataMock.Setup(r => r.Headers).Returns(headers);

            httpRequestDataMock.Setup(r => r.CreateResponse()).Returns(() =>
            {
                var httpResponseDataMock = new Mock<HttpResponseData>(contextMock.Object);
                httpResponseDataMock.SetupProperty(r => r.Headers, new HttpHeadersCollection());
                httpResponseDataMock.SetupProperty(r => r.StatusCode, HttpStatusCode.OK);
                httpResponseDataMock.SetupProperty(r => r.Body, new MemoryStream());
                return httpResponseDataMock.Object;
            });

            var response = await _sut.RunAsync(httpRequestDataMock.Object);

            // Assert that the response status code is Unauthorized due to missing Authorization header
            Assert.AreEqual(HttpStatusCode.Unauthorized, response.StatusCode);
            UnitTestDetector.SetOverrideValue(null);

        }

        [Test]
        public async Task RunAsync_ValidRequest_ReturnsOkResponse()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();
            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(System.Text.Encoding.UTF8.GetBytes(ValidSocialMediaPlatforms)));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(System.Text.Encoding.UTF8.GetBytes(ValidSocialMediaPlatforms)));
                return response.Object;
            });
            var sutResult = await _sut.RunAsync(request.Object);
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));

        }


        [Test]
        public async Task Given_PostSocialMediaPlatform_RunAsync_InvalidRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var invalidRequestBody = "test"u8.ToArray();

            var invalidRequest = new Mock<HttpRequestData>(context.Object);
            invalidRequest.Setup(req => req.Body).Returns(new MemoryStream(invalidRequestBody));
            invalidRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var invalidResult = await _sut.RunAsync(invalidRequest.Object);
            Assert.That(invalidResult.StatusCode, Is.EqualTo(HttpStatusCode.UnprocessableContent));

        }

        [Test]
        public async Task Given_PostSocialMediaPlatform_RunAsync_EmptyRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var emptyRequestBody = Encoding.UTF8.GetBytes("");

            var emptyRequest = new Mock<HttpRequestData>(context.Object);
            emptyRequest.Setup(req => req.Body).Returns(new MemoryStream(emptyRequestBody));
            emptyRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var emptyResult = await _sut.RunAsync(emptyRequest.Object);
            Assert.That(emptyResult.StatusCode, Is.EqualTo(HttpStatusCode.UnprocessableContent));

        }



        [Test]
        public async Task Given_PostSocialMediaPlatform_RunAsync_IncompleteRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var incompleteRequestBody = Encoding.UTF8.GetBytes(InvalidNameSocialMediaPlatforms);

            var incompleteRequest = new Mock<HttpRequestData>(context.Object);
            incompleteRequest.Setup(req => req.Body).Returns(new MemoryStream(incompleteRequestBody));
            incompleteRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var incompleteResult = await _sut.RunAsync(incompleteRequest.Object);
            Assert.That(incompleteResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));

        }

        [Test]
        public async Task Given_PostSocialMediaPlatform_RunAsync_NullRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var incompleteRequest = new Mock<HttpRequestData>(context.Object);
            incompleteRequest.Setup(req => req.Body).Returns((Stream)null);
            incompleteRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var incompleteResult = await _sut.RunAsync(incompleteRequest.Object);
            Assert.That(incompleteResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        }

        [Test]
        public async Task Given_PostIcon_RunAsync_IncompleteRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var incompleteRequestBody = Encoding.UTF8.GetBytes(InvalidIconSocialMediaPlatforms);

            var incompleteRequest = new Mock<HttpRequestData>(context.Object);
            incompleteRequest.Setup(req => req.Body).Returns(new MemoryStream(incompleteRequestBody));
            incompleteRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var incompleteResult = await _sut.RunAsync(incompleteRequest.Object);
            Assert.That(incompleteResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));

        }

        [Test]
        public async Task Given_PostSocialMediaPlatforms_RunAsync_InvalidData_ReturnsNoContent()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = Encoding.UTF8.GetBytes(InvalidNameSocialMediaPlatforms);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
            var sutResult = await _sut.RunAsync(request.Object);
            var id = Guid.NewGuid();

            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            _socialMediaPlatformsServiceMock.Verify(service => service.SaveSocialMediaPlatforms(It.IsAny<List<SocialMediaPlatform>>()), Times.Never);


        }

        [Test]
        public async Task Given_PostCallDoesError_ThenReturnBadRequestStatuscode()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);


            var requestBody = Encoding.UTF8.GetBytes(ValidSocialMediaPlatforms);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
            Exception ex = new Exception("An error occurred while processing the request.");
            _socialMediaPlatformsServiceMock.Setup(c => c.SaveSocialMediaPlatforms(It.IsAny<List<SocialMediaPlatform>>())).Throws(ex);
            var sutResult = await _sut.RunAsync(request.Object);

            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            _socialMediaPlatformsServiceMock.Verify(service => service.SaveSocialMediaPlatforms(It.IsAny<List<SocialMediaPlatform>>()), Times.Once);

        }

        #region Test Data
        private static readonly string EmptySocialMediaPlatformsString = "";
        private const string InvalidIconSocialMediaPlatforms = "[\r\n    {\r\n        \"Id\" :\"e4b6ad76-60da-4f2b-bef9-a47b18daead4\",\r\n        \"Name\" : \"Twitter\",\r\n        \"Icon\" : \"\"\r\n    },\r\n    {\r\n        \"Id\" :\"0db5ddac-1c4e-4cb9-a510-1fc003922861\",\r\n        \"Name\" : \"LinkedIn\",\r\n        \"Icon\" : \"fa-linkedin-square\"\r\n    }\r\n]";
        private const string InvalidIdSocialMediaPlatforms = "[\r\n    {\r\n        \"Id\" :\"00000000-0000-0000-0000-000000000000\",\r\n        \"Name\" : \"Twitter\",\r\n        \"Icon\" : \"fa-twitter-square\"\r\n    },\r\n    {\r\n        \"Id\" :\"0db5ddac-1c4e-4cb9-a510-1fc003922861\",\r\n        \"Name\" : \"LinkedIn\",\r\n        \"Icon\" : \"fa-linkedin-square\"\r\n    }\r\n]";
        private const string InvalidNameSocialMediaPlatforms = "[\r\n    {\r\n        \"Id\" :\"e4b6ad76-60da-4f2b-bef9-a47b18daead4\",\r\n        \"Name\" : \"\",\r\n        \"Icon\" : \"fa-twitter-square\"\r\n    },\r\n    {\r\n        \"Id\" :\"0db5ddac-1c4e-4cb9-a510-1fc003922861\",\r\n        \"Name\" : \"LinkedIn\",\r\n        \"Icon\" : \"fa-linkedin-square\"\r\n    }\r\n]";
        private const string ValidSocialMediaPlatforms = "[\r\n    {\r\n        \"Id\" :\"e4b6ad76-60da-4f2b-bef9-a47b18daead4\",\r\n        \"Name\" : \"Twitter\",\r\n        \"Icon\" : \"fa-twitter-square\"\r\n    },\r\n    {\r\n        \"Id\" :\"0db5ddac-1c4e-4cb9-a510-1fc003922861\",\r\n        \"Name\" : \"LinkedIn\",\r\n        \"Icon\" : \"fa-linkedin-square\"\r\n    }\r\n]";
        #endregion


    }
}