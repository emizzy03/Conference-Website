using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using TCC.Functions.Functions;
using TCC.Functions.Implementations;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;

namespace TCC.Functions.Tests.Functions;

public class AdminGetConferenceInfoTests
{
    private Mock<ILogger<UpdateAllPublicDataSet>> _logger = null!;
    private Mock<IPublicDataService> _publicEventDataService = null!;
    private Mock<IStorageService> _storageService = null!;
    private AdminGetConferenceInfo _sut = null!;
    private Mock<IHttpService> _httpService = null!;
    private Mock<IAzureADService> _azureAdService = null!;
    private Mock<IAuthUserService> _authUserService = null!;
    [SetUp]
    public void Setup()
    {
        _logger = new Mock<ILogger<UpdateAllPublicDataSet>>();
        _publicEventDataService = new Mock<IPublicDataService>();
        _storageService = new Mock<IStorageService>();
        _httpService = new Mock<IHttpService>();
        _azureAdService = new Mock<IAzureADService>();
        _authUserService = new Mock<IAuthUserService>();
        _sut = new AdminGetConferenceInfo(_publicEventDataService.Object, _logger.Object, _httpService.Object, _azureAdService.Object, _authUserService.Object);
    }
    [Test]
    public async Task Run_WhenAuthorizationHeaderIsMissing_ReturnsUnauthorizedStatusCode()
    {
        UnitTestDetector.SetOverrideValue(false);

        // Arrange
        var contextMock = new Mock<FunctionContext>();
        var httpRequestDataMock = new Mock<HttpRequestData>(contextMock.Object);
        var headers = new HttpHeadersCollection();
        // Simulate missing "Authorization" header by not adding it to the collection
        httpRequestDataMock.Setup(r => r.Headers).Returns(headers);

        httpRequestDataMock.Setup(r => r.CreateResponse()).Returns(() =>
        {
            var httpResponseDataMock = new Mock<HttpResponseData>(contextMock.Object);
            httpResponseDataMock.SetupProperty(r => r.Headers, new HttpHeadersCollection());
            httpResponseDataMock.SetupProperty(r => r.StatusCode, HttpStatusCode.OK);
            httpResponseDataMock.SetupProperty(r => r.Body, new MemoryStream());
            return httpResponseDataMock.Object;
        });

        var response = await _sut.Run(httpRequestDataMock.Object);

        // Assert that the response status code is Unauthorized due to missing Authorization header
        Assert.AreEqual(HttpStatusCode.Unauthorized, response.StatusCode);
        UnitTestDetector.SetOverrideValue(null);

    }

    [Test]
    public async Task Given_GetCallDoesNotError_Then_ReturnOkStatusCode()
    {
        var serviceCollection = new ServiceCollection();
        serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
        var serviceProvider = serviceCollection.BuildServiceProvider();

        var context = new Mock<FunctionContext>();
        context.SetupProperty(c => c.InstanceServices, serviceProvider);

        var request = new Mock<HttpRequestData>(context.Object);
        request.Setup(r => r.CreateResponse()).Returns(() =>
        {
            var response = new Mock<HttpResponseData>(context.Object);
            response.SetupProperty(r => r.Headers, new HttpHeadersCollection());
            response.SetupProperty(r => r.StatusCode);
            response.SetupProperty(r => r.Body, new MemoryStream());
            return response.Object;
        });

        var sutResult = await _sut.Run(request.Object);
        Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));
        Assert.Pass();
    }
    
    [Test]
    public void Given_GetCallDoesError_Then_ReturnBadRequestStatusCode()
    {
        var serviceCollection = new ServiceCollection();
        serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
        var serviceProvider = serviceCollection.BuildServiceProvider();

        var context = new Mock<FunctionContext>();
        context.SetupProperty(c => c.InstanceServices, serviceProvider);

        var request = new Mock<HttpRequestData>(context.Object);
        request.Setup(r => r.CreateResponse()).Throws<Exception>();

        Assert.ThrowsAsync<Exception>(async () => await _sut.Run(request.Object));
    }


}