﻿//RemoveSessionFunction

using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using TCC.Functions.Interfaces;
using TCC.Functions.Functions.AdminFunctions;
using System.Text;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Model;
using TCC.Functions.Functions.User;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Implementations;

namespace TCC.Functions.Tests.Functions
{
    public class RemoveSessionFunctionTests
    {
        private Mock<IUserService> _removeSessionServiceMock;
        private Mock<ILogger<RemoveSessionFunction>> _loggerMock;
        private RemoveSessionFunction _sut;
        private Mock<IHttpService> _httpService = null!;
        private Mock<IAzureADService> _azureAdService = null!;
        private Mock<IAuthUserService> _authUserService = null!;

        [SetUp]
        public void Setup()
        {
            _removeSessionServiceMock = new Mock<IUserService>();
            _loggerMock = new Mock<ILogger<RemoveSessionFunction>>();
            _httpService = new Mock<IHttpService>();
            _azureAdService = new Mock<IAzureADService>();
            _authUserService = new Mock<IAuthUserService>();
            _sut = new RemoveSessionFunction(_removeSessionServiceMock.Object, _loggerMock.Object, _httpService.Object, _azureAdService.Object, _authUserService.Object);
        }

        [Test]
        public async Task Run_WhenAuthorizationHeaderIsMissing_ReturnsUnauthorizedStatusCode()
        {
            UnitTestDetector.SetOverrideValue(false);

            // Arrange
            var contextMock = new Mock<FunctionContext>();
            var httpRequestDataMock = new Mock<HttpRequestData>(contextMock.Object);
            var headers = new HttpHeadersCollection();
            // Simulate missing "Authorization" header by not adding it to the collection
            httpRequestDataMock.Setup(r => r.Headers).Returns(headers);

            httpRequestDataMock.Setup(r => r.CreateResponse()).Returns(() =>
            {
                var httpResponseDataMock = new Mock<HttpResponseData>(contextMock.Object);
                httpResponseDataMock.SetupProperty(r => r.Headers, new HttpHeadersCollection());
                httpResponseDataMock.SetupProperty(r => r.StatusCode, HttpStatusCode.OK);
                httpResponseDataMock.SetupProperty(r => r.Body, new MemoryStream());
                return httpResponseDataMock.Object;
            });

            var response = await _sut.RunAsync(httpRequestDataMock.Object);

            // Assert that the response status code is Unauthorized due to missing Authorization header
            Assert.AreEqual(HttpStatusCode.Unauthorized, response.StatusCode);
            UnitTestDetector.SetOverrideValue(null);

        }

        [Test]
        public async Task RunAsync_ValidRequest_ReturnsOkResponse()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();
            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = "{\"Id\":\"3abc5b89-3c6e-49e1-990f-53f986e0ad37\",\"Title\":\"Open Talk  - Dot Net\",\"Description\":\"The moderators Lwin Maung &amp; Min Maung will share their experience, and bring various experts in different areas. Come join the community as we discuss with all of you on various development journeys. \\n<br><br><br>\\nWe will be covering topics below and more:<br>\\n- Evolution of Dot Net<br>\\n- Dot Net Core<br>\\n- Cross Platform use<br>\\n- Windows, Mac, Linux and Dot NET<br>\",\"UserId\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"IsKeynote\":false,\"VideoLink\":null,\"IsSelected\":true,\"IsWorkshop\":false,\"EventId\":\"01446bd5-464d-4c3c-a403-36f829d22a97\",\"VideoThumbnail\":null}";

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(System.Text.Encoding.UTF8.GetBytes(requestBody)));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(System.Text.Encoding.UTF8.GetBytes(requestBody)));
                return response.Object;
            });

            var sutResult = await _sut.RunAsync(request.Object);
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));

        }

        [Test]
        public async Task Given_PostEvent_RunAsync_NullRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var incompleteRequest = new Mock<HttpRequestData>(context.Object);
            incompleteRequest.Setup(req => req.Body).Returns((Stream)null);
            incompleteRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var incompleteResult = await _sut.RunAsync(incompleteRequest.Object);
            Assert.That(incompleteResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        }


        [Test]
        public async Task Given_PostCallDoesError_ThenReturnBadRequestStatuscode()
        {

            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var sessionDto = "{\"Id\":\"3abc5b89-3c6e-49e1-990f-53f986e0ad37\",\"Title\":\"Open Talk  - Dot Net\",\"Description\":\"The moderators Lwin Maung &amp; Min Maung will share their experience, and bring various experts in different areas. Come join the community as we discuss with all of you on various development journeys. \\n<br><br><br>\\nWe will be covering topics below and more:<br>\\n- Evolution of Dot Net<br>\\n- Dot Net Core<br>\\n- Cross Platform use<br>\\n- Windows, Mac, Linux and Dot NET<br>\",\"UserId\":\"25b2fd9c-2b51-472a-8e1a-695f74e8beb2\",\"IsKeynote\":false,\"VideoLink\":null,\"IsSelected\":true,\"IsWorkshop\":false,\"EventId\":\"01446bd5-464d-4c3c-a403-36f829d22a97\",\"VideoThumbnail\":null}";

            var requestBody = Encoding.UTF8.GetBytes(sessionDto);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
            Exception ex = new Exception("An error occurred while processing the request.");
            _removeSessionServiceMock.Setup(c => c.RemoveSession(It.IsAny<SessionDto>())).Throws(ex);
            var sutResult = await _sut.RunAsync(request.Object);

            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));

        }

    }
}