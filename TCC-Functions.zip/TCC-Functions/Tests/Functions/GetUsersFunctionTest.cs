﻿using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using TCC.Functions.Functions;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Implementations;
using System.Security;
using Azure;

namespace TCC.Functions.Tests.Functions;

public class GetUsersFunctionTest
{
    private Mock<ILogger<GetUserFunction>> _logger = null!;
    private Mock<IUserService> _userService = null!;
    private GetUserFunction _sut = null!;
    private Mock<IHttpService> _httpService = null!;
    private Mock<IAzureADService> _azureAdService = null!;
    private Mock<IAuthUserService> _authUserService = null!;
    [SetUp]
    public void Setup()
    {
        _logger = new Mock<ILogger<GetUserFunction>>();
        _userService = new Mock<IUserService>();
        _httpService = new Mock<IHttpService>();
        _azureAdService = new Mock<IAzureADService>();
        _authUserService = new Mock<IAuthUserService>();
        _sut = new GetUserFunction(_userService.Object, _logger.Object, _httpService.Object, _azureAdService.Object, _authUserService.Object);
    }

    [Test]
    public async Task Run_WhenAuthorizationHeaderIsMissing_ReturnsUnauthorizedStatusCode()
    {
        UnitTestDetector.SetOverrideValue(false);

        // Arrange
        var contextMock = new Mock<FunctionContext>();
        var httpRequestDataMock = new Mock<HttpRequestData>(contextMock.Object);
        var headers = new HttpHeadersCollection();
        // Simulate missing "Authorization" header by not adding it to the collection
        httpRequestDataMock.Setup(r => r.Headers).Returns(headers);

        httpRequestDataMock.Setup(r => r.CreateResponse()).Returns(() =>
        {
            var httpResponseDataMock = new Mock<HttpResponseData>(contextMock.Object);
            httpResponseDataMock.SetupProperty(r => r.Headers, new HttpHeadersCollection());
            httpResponseDataMock.SetupProperty(r => r.StatusCode, HttpStatusCode.OK);
            httpResponseDataMock.SetupProperty(r => r.Body, new MemoryStream());
            return httpResponseDataMock.Object;
        });

        var response = await _sut.Run(httpRequestDataMock.Object, "valid_user_id");

        // Assert that the response status code is Unauthorized due to missing Authorization header
        Assert.AreEqual(HttpStatusCode.Unauthorized, response.StatusCode);
        UnitTestDetector.SetOverrideValue(null);

    }

    [Test]
    public async Task Given_GetCallDoesNotError_Then_ReturnOkStatusCode()
    {
        var serviceCollection = new ServiceCollection();
        serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
        var serviceProvider = serviceCollection.BuildServiceProvider();

        var context = new Mock<FunctionContext>();
        context.SetupProperty(c => c.InstanceServices, serviceProvider);

        var request = new Mock<HttpRequestData>(context.Object);
        request.Setup(r => r.CreateResponse()).Returns(() =>
        {
            var response = new Mock<HttpResponseData>(context.Object);
            response.SetupProperty(r => r.Headers, new HttpHeadersCollection());
            response.SetupProperty(r => r.StatusCode);
            response.SetupProperty(r => r.Body, new MemoryStream());
            return response.Object;
        });

        var sutResult = await _sut.Run(request.Object, ValidUserId);
        Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));
    }

    [Test]
    public void Given_GetCallDoesError_Then_ReturnBadRequestStatusCode()
    {
        var serviceCollection = new ServiceCollection();
        serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
        var serviceProvider = serviceCollection.BuildServiceProvider();

        var context = new Mock<FunctionContext>();
        context.SetupProperty(c => c.InstanceServices, serviceProvider);

        var request = new Mock<HttpRequestData>(context.Object);
        request.Setup(r => r.CreateResponse()).Throws<Exception>();

        Assert.ThrowsAsync<Exception>(async () => await _sut.Run(request.Object, ValidUserId));
    }

    [Test]
    public async Task Given_GetCallDoesNotHaveId_Then_ReturnNoContentCode()
    {
        var serviceCollection = new ServiceCollection();
        serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
        var serviceProvider = serviceCollection.BuildServiceProvider();

        var context = new Mock<FunctionContext>();
        context.SetupProperty(c => c.InstanceServices, serviceProvider);

        var request = new Mock<HttpRequestData>(context.Object);
        request.Setup(r => r.CreateResponse()).Returns(() =>
        {
            var response = new Mock<HttpResponseData>(context.Object);
            response.SetupProperty(r => r.Headers, new HttpHeadersCollection());
            response.SetupProperty(r => r.StatusCode);
            response.SetupProperty(r => r.Body, new MemoryStream());
            return response.Object;
        });
        string id = null;
        var sutResult = await _sut.Run(request.Object, id);
        Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.NoContent));
    }
    #region TestData
    private const string ValidUserId = "25b2fd9c-2b51-472a-8e1a-695f74e8beb2";
    #endregion
}