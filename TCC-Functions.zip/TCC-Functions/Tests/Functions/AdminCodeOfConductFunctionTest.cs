﻿
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using TCC.Functions.Functions;
using TCC.Functions.Interfaces;
using System.Text;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Implementations;


namespace TCC.Functions.Tests
{
    public class AdminCodeOfConductFunctionTests
    {
        private Mock<IAdminService> _codeOfConductServiceMock;
        private Mock<ILogger<AdminCoCFunction>> _loggerMock;
        private AdminCoCFunction _sut;
        private Mock<IPublicDataService> _publicDataService;
        private Mock<IHttpService> _httpService = null!;
        private Mock<IAzureADService> _azureAdService = null!;
        private Mock<IAuthUserService> _authUserService = null!;

        [SetUp]
        public void Setup()
        {
            _codeOfConductServiceMock = new Mock<IAdminService>();
            _loggerMock = new Mock<ILogger<AdminCoCFunction>>();
            _publicDataService = new Mock<IPublicDataService>();
            _httpService = new Mock<IHttpService>();
            _azureAdService = new Mock<IAzureADService>();
            _authUserService = new Mock<IAuthUserService>();
            _sut = new AdminCoCFunction(_codeOfConductServiceMock.Object, _loggerMock.Object, _publicDataService.Object, _httpService.Object, _azureAdService.Object, _authUserService.Object);
        }

        [Test]
        public async Task Run_WhenAuthorizationHeaderIsMissing_ReturnsUnauthorizedStatusCode()
        {
            UnitTestDetector.SetOverrideValue(false);

            // Arrange
            var contextMock = new Mock<FunctionContext>();
            var httpRequestDataMock = new Mock<HttpRequestData>(contextMock.Object);
            var headers = new HttpHeadersCollection();
            // Simulate missing "Authorization" header by not adding it to the collection
            httpRequestDataMock.Setup(r => r.Headers).Returns(headers);

            httpRequestDataMock.Setup(r => r.CreateResponse()).Returns(() =>
            {
                var httpResponseDataMock = new Mock<HttpResponseData>(contextMock.Object);
                httpResponseDataMock.SetupProperty(r => r.Headers, new HttpHeadersCollection());
                httpResponseDataMock.SetupProperty(r => r.StatusCode, HttpStatusCode.OK);
                httpResponseDataMock.SetupProperty(r => r.Body, new MemoryStream());
                return httpResponseDataMock.Object;
            });

            var response = await _sut.RunAsync(httpRequestDataMock.Object);

            // Assert that the response status code is Unauthorized due to missing Authorization header
            Assert.AreEqual(HttpStatusCode.Unauthorized, response.StatusCode);
            UnitTestDetector.SetOverrideValue(null);

        }

        [Test]
        public async Task RunAsync_ValidRequest_ReturnsOkResponse()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();
            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = "{\"content\":\"Test Content\"}";
            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(System.Text.Encoding.UTF8.GetBytes(requestBody)));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(System.Text.Encoding.UTF8.GetBytes(requestBody)));
                return response.Object;
            });
            var sutResult = await _sut.RunAsync(request.Object);
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));

        }
        [Test]
        public void RunAsync_EmptyRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var emptyRequestBody = Encoding.UTF8.GetBytes("");
            var emptyRequest = new Mock<HttpRequestData>(context.Object);
            emptyRequest.Setup(req => req.Body).Returns(new MemoryStream(emptyRequestBody));
            emptyRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var ex = Assert.ThrowsAsync<Exception>(() => _sut.RunAsync(emptyRequest.Object));
            Assert.That(ex.Message, Is.EqualTo("Content not found"));

        }

    }
}