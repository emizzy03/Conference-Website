﻿using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using TCC.Functions.Interfaces;
using TCC.Functions.Functions.AdminFunctions;
using System.Text;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Model;
using TCC.Functions.Interfaces.Auth;
using TCC.Functions.Implementations;

namespace TCC.Functions.Tests.Functions
{
    public class RemoveEventFunctionTests
    {
        private Mock<IAdminService> _removeEventServiceMock;
        private Mock<ILogger<RemoveEventFunction>> _loggerMock;
        private RemoveEventFunction _sut;
        private Mock<IHttpService> _httpService = null!;
        private Mock<IAzureADService> _azureAdService = null!;
        private Mock<IAuthUserService> _authUserService = null!;

        [SetUp]
        public void Setup()
        {
            _removeEventServiceMock = new Mock<IAdminService>();
            _loggerMock = new Mock<ILogger<RemoveEventFunction>>();
            _httpService = new Mock<IHttpService>();
            _azureAdService = new Mock<IAzureADService>();
            _authUserService = new Mock<IAuthUserService>();
            _sut = new RemoveEventFunction(_removeEventServiceMock.Object, _loggerMock.Object, _httpService.Object, _azureAdService.Object, _authUserService.Object);
        }

        [Test]
        public async Task Run_WhenAuthorizationHeaderIsMissing_ReturnsUnauthorizedStatusCode()
        {
            UnitTestDetector.SetOverrideValue(false);

            // Arrange
            var contextMock = new Mock<FunctionContext>();
            var httpRequestDataMock = new Mock<HttpRequestData>(contextMock.Object);
            var headers = new HttpHeadersCollection();
            // Simulate missing "Authorization" header by not adding it to the collection
            httpRequestDataMock.Setup(r => r.Headers).Returns(headers);

            httpRequestDataMock.Setup(r => r.CreateResponse()).Returns(() =>
            {
                var httpResponseDataMock = new Mock<HttpResponseData>(contextMock.Object);
                httpResponseDataMock.SetupProperty(r => r.Headers, new HttpHeadersCollection());
                httpResponseDataMock.SetupProperty(r => r.StatusCode, HttpStatusCode.OK);
                httpResponseDataMock.SetupProperty(r => r.Body, new MemoryStream());
                return httpResponseDataMock.Object;
            });

            var response = await _sut.RunAsync(httpRequestDataMock.Object);

            // Assert that the response status code is Unauthorized due to missing Authorization header
            Assert.AreEqual(HttpStatusCode.Unauthorized, response.StatusCode);
            UnitTestDetector.SetOverrideValue(null);

        }

        [Test]
        public async Task RunAsync_ValidRequest_ReturnsOkResponse()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();
            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = "{\"Id\":\"bce217b0-dc67-40f1-a82f-ffd3cc119e10\",\"Name\":\"2019\",\"StartDate\":\"2019-05-11T07:00:00\",\"EndDate\":\"2019-05-11T07:00:00\",\"Status\":2,\"Address1\":\"7900 Division St\",\"Address2\":null,\"City\":\"River Forest\",\"State\":\"IL\",\"Zip\":\"60305\",\"LocationDescription\":\"Entrance to the main event\",\"Year\":2019}";
            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(System.Text.Encoding.UTF8.GetBytes(requestBody)));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(System.Text.Encoding.UTF8.GetBytes(requestBody)));
                return response.Object;
            });

            var sutResult = await _sut.RunAsync(request.Object);
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));

        }

        [Test]
        public async Task Given_PostEvent_RunAsync_NullRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var incompleteRequest = new Mock<HttpRequestData>(context.Object);
            incompleteRequest.Setup(req => req.Body).Returns((Stream)null);
            incompleteRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var incompleteResult = await _sut.RunAsync(incompleteRequest.Object);
            Assert.That(incompleteResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        }


        [Test]
        public async Task Given_PostCallDoesError_ThenReturnBadRequestStatuscode()
        {

            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var eventDto = "{\"Id\":\"bce217b0-dc67-40f1-a82f-ffd3cc11e10\",\"Name\":\"2019\",\"StartDate\":\"2019-05-11T07:00:00\",\"EndDate\":\"2019-05-11T07:00:00\",\"Status\":2,\"Address1\":\"7900 Division St\",\"Address2\":null,\"City\":\"River Forest\",\"State\":\"IL\",\"Zip\":\"60305\",\"LocationDescription\":\"Entrance to the main event\",\"Year\":2019}";

            var requestBody = Encoding.UTF8.GetBytes(eventDto);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
            Exception ex = new Exception("An error occurred while processing the request.");
            _removeEventServiceMock.Setup(c => c.RemoveEvent(It.IsAny<EventDto>())).Throws(ex);
            var sutResult = await _sut.RunAsync(request.Object);

            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            _removeEventServiceMock.Verify(service => service.RemoveEvent(It.IsAny<EventDto>()), Times.Never);


        }

    }
}