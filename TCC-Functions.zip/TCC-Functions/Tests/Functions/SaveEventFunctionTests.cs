﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using System.Net;
using System.Text;
using TCC.Functions.Functions.Event;
using TCC.Functions.Implementations;
using TCC.Functions.Implementations.DTO;
using TCC.Functions.Interfaces;
using TCC.Functions.Interfaces.Auth;

namespace TCC.Functions.Tests.Functions
{
    public class SaveEventFunctionTests
    {
        private Mock<ILogger<SaveEventFunction>> _logger = null!;
        private Mock<IEventService> _eventServicMock = null!;
        private SaveEventFunction _sut = null!;
        private Mock<IHttpService> _httpService = null!;
        private Mock<IAzureADService> _azureAdService = null!;
        private Mock<IAuthUserService> _authUserService = null!;

        [SetUp]
        public void Setup()
        {
            _logger = new Mock<ILogger<SaveEventFunction>>();
            _eventServicMock = new Mock<IEventService>();
            _httpService = new Mock<IHttpService>();
            _azureAdService = new Mock<IAzureADService>();
            _authUserService = new Mock<IAuthUserService>();
            _sut = new SaveEventFunction(_eventServicMock.Object, _logger.Object, _httpService.Object, _azureAdService.Object, _authUserService.Object);
        }

        [Test]
        public async Task Run_WhenAuthorizationHeaderIsMissing_ReturnsUnauthorizedStatusCode()
        {
            UnitTestDetector.SetOverrideValue(false);

            // Arrange
            var contextMock = new Mock<FunctionContext>();
            var httpRequestDataMock = new Mock<HttpRequestData>(contextMock.Object);
            var headers = new HttpHeadersCollection();
            // Simulate missing "Authorization" header by not adding it to the collection
            httpRequestDataMock.Setup(r => r.Headers).Returns(headers);

            httpRequestDataMock.Setup(r => r.CreateResponse()).Returns(() =>
            {
                var httpResponseDataMock = new Mock<HttpResponseData>(contextMock.Object);
                httpResponseDataMock.SetupProperty(r => r.Headers, new HttpHeadersCollection());
                httpResponseDataMock.SetupProperty(r => r.StatusCode, HttpStatusCode.OK);
                httpResponseDataMock.SetupProperty(r => r.Body, new MemoryStream());
                return httpResponseDataMock.Object;
            });

            var response = await _sut.RunAsync(httpRequestDataMock.Object);

            // Assert that the response status code is Unauthorized due to missing Authorization header
            Assert.AreEqual(HttpStatusCode.Unauthorized, response.StatusCode);
            UnitTestDetector.SetOverrideValue(null);

        }

        [Test]
        public async Task Given_PostEvent_ValidRequest_ReturnOKStatusCode()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = Encoding.UTF8.GetBytes(updateEventString);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });

            //Act
            var sutResult = await _sut.RunAsync(request.Object);
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            _eventServicMock.Verify(service => service.SaveEvent(It.IsAny<EventDto>(), Guid.Parse("bce217b0-dc67-40f1-a82f-ffd3cc119e10"), "saved"), Times.Once);
        }

        [Test]
        public async Task Given_PostEvent_ValidStatusTwoEvent_ReturnOKStatusCode()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = Encoding.UTF8.GetBytes(StatusTwoEventString);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });

            //Act
            var sutResult = await _sut.RunAsync(request.Object);
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            _eventServicMock.Verify(service => service.SaveEvent(It.IsAny<EventDto>(), Guid.Parse("bce217b0-dc67-40f1-a82f-ffd3cc119e10"), "saved"), Times.Once);
        }

        [Test]
        public async Task Given_PostEvent_ValidStatusThreeEvent_ReturnOKStatusCode()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = Encoding.UTF8.GetBytes(StatusThreeEventString);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });

            //Act
            var sutResult = await _sut.RunAsync(request.Object);
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));

            _eventServicMock.Verify(service => service.SaveEvent(It.IsAny<EventDto>(), Guid.Parse("bce217b0-dc67-40f1-a82f-ffd3cc119e10"), "saved"), Times.Once);
        }

        [Test]
        public async Task Given_PostNewEvent_ValidRequest_ReturnOKStatusCode()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();


            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = Encoding.UTF8.GetBytes(CreateNewEventString);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });

            //Act
            var sutResult = await _sut.RunAsync(request.Object);


            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            _eventServicMock.Verify(service => service.SaveEvent(It.IsAny<EventDto>(), It.IsAny<Guid>(), "created"), Times.Once);
        }


        [Test]
        public async Task Given_PostNewUser_ValidRequest_ReturnOKStatusCode()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();


            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = Encoding.UTF8.GetBytes(CreateNewEventString);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });

            //Act
            var sutResult = await _sut.RunAsync(request.Object);


            _eventServicMock.Verify(service => service.SaveEvent(It.IsAny<EventDto>(), It.IsAny<Guid>(), "created"), Times.Once);
            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.OK));

        }

        [Test]
        public async Task Given_PostEvent_RunAsync_InvalidRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var invalidRequestBody = "test"u8.ToArray();

            var invalidRequest = new Mock<HttpRequestData>(context.Object);
            invalidRequest.Setup(req => req.Body).Returns(new MemoryStream(invalidRequestBody));
            invalidRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var invalidResult = await _sut.RunAsync(invalidRequest.Object);
            Assert.That(invalidResult.StatusCode, Is.EqualTo(HttpStatusCode.UnprocessableContent));

        }

        [Test]
        public async Task Given_PostEvent_RunAsync_EmptyRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var emptyRequestBody = Encoding.UTF8.GetBytes("");

            var emptyRequest = new Mock<HttpRequestData>(context.Object);
            emptyRequest.Setup(req => req.Body).Returns(new MemoryStream(emptyRequestBody));
            emptyRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var emptyResult = await _sut.RunAsync(emptyRequest.Object);
            Assert.That(emptyResult.StatusCode, Is.EqualTo(HttpStatusCode.UnprocessableContent));

        }

        [Test]
        public async Task Given_PostEvent_RunAsync_NullRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var incompleteRequest = new Mock<HttpRequestData>(context.Object);
            incompleteRequest.Setup(req => req.Body).Returns((Stream)null);
            incompleteRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var incompleteResult = await _sut.RunAsync(incompleteRequest.Object);
            Assert.That(incompleteResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
        }


        [Test]
        public async Task Given_PostEvent_RunAsync_IncompleteRequest()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var incompleteRequestBody = Encoding.UTF8.GetBytes(incompleteEventString);

            var incompleteRequest = new Mock<HttpRequestData>(context.Object);
            incompleteRequest.Setup(req => req.Body).Returns(new MemoryStream(incompleteRequestBody));
            incompleteRequest.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream());
                return response.Object;
            });

            var incompleteResult = await _sut.RunAsync(incompleteRequest.Object);
            Assert.That(incompleteResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));

        }
        [Test]
        public async Task Given_PostEvent_RunAsync_InvalidData_ReturnsNoContent()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);

            var requestBody = Encoding.UTF8.GetBytes(InvalidEventString);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
            var sutResult = await _sut.RunAsync(request.Object);
            var id = Guid.NewGuid();

            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            _eventServicMock.Verify(service => service.SaveEvent(It.IsAny<EventDto>(), id, "Created"), Times.Never);

        }

        [Test]
        public async Task Given_PostCallDoesError_ThenReturnBadRequestStatuscode()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddScoped<ILoggerFactory, LoggerFactory>();
            var serviceProvider = serviceCollection.BuildServiceProvider();

            var context = new Mock<FunctionContext>();
            context.SetupProperty(c => c.InstanceServices, serviceProvider);


            var requestBody = Encoding.UTF8.GetBytes(updateEventString);

            var request = new Mock<HttpRequestData>(context.Object);
            request.Setup(req => req.Body).Returns(new MemoryStream(requestBody));
            request.Setup(req => req.CreateResponse()).Returns(() =>
            {
                var response = new Mock<HttpResponseData>(context.Object);
                response.SetupProperty(r => r.Headers, []);
                response.SetupProperty(r => r.StatusCode);
                response.SetupProperty(r => r.Body, new MemoryStream(requestBody));
                return response.Object;
            });
            Exception ex = new Exception("An error occurred while processing the request.");
            _eventServicMock.Setup(c => c.SaveEvent(It.IsAny<EventDto>(), It.IsAny<Guid>(), It.IsAny<string>())).Throws(ex);
            var sutResult = await _sut.RunAsync(request.Object);

            Assert.That(sutResult.StatusCode, Is.EqualTo(HttpStatusCode.BadRequest));
            _eventServicMock.Verify(service => service.SaveEvent(It.IsAny<EventDto>(), It.IsAny<Guid>(), It.IsAny<string>()), Times.Once);

        }

        #region Test Data

        private const string CreateNewEventString = "{\"Name\":\"2019\",\"StartDate\":\"2019-05-11T07:00:00\",\"EndDate\":\"2019-05-11T07:00:00\",\"Status\":1,\"Address1\":\"7900 Division St\",\"Address2\":null,\"City\":\"River Forest\",\"State\":\"IL\",\"Zip\":\"60305\",\"LocationDescription\":\"Entrance to the main event\",\"Year\":2019}";
        private static readonly string InvalidEventString = "{\"Id\":\"bce217b0-dc67-40f1-a82f-ffd3cc119e10\",\"Name\":\"\",\"StartDate\":\"2019-05-11T07:00:00\",\"EndDate\":\"2019-05-11T07:00:00\",\"Status\":0,\"Address1\":\"7900 Division St\",\"Address2\":null,\"City\":\"\",\"State\":\"IL\",\"Zip\":\"\",\"LocationDescription\":\"Entrance to the main event\",\"Year\":2019}";
        private static readonly string StatusTwoEventString = "{\"Id\":\"bce217b0-dc67-40f1-a82f-ffd3cc119e10\",\"Name\":\"2019\",\"StartDate\":\"2019-05-11T07:00:00\",\"EndDate\":\"2019-05-11T07:00:00\",\"Status\":2,\"Address1\":\"7900 Division St\",\"Address2\":null,\"City\":\"River Forest\",\"State\":\"IL\",\"Zip\":\"60305\",\"LocationDescription\":\"Entrance to the main event\",\"Year\":2019}";
        private static readonly string StatusThreeEventString = "{\"Id\":\"bce217b0-dc67-40f1-a82f-ffd3cc119e10\",\"Name\":\"2019\",\"StartDate\":\"2019-05-11T07:00:00\",\"EndDate\":\"2019-05-11T07:00:00\",\"Status\":3,\"Address1\":\"7900 Division St\",\"Address2\":null,\"City\":\"River Forest\",\"State\":\"IL\",\"Zip\":\"60305\",\"LocationDescription\":\"Entrance to the main event\",\"Year\":2019}";
        private static readonly string incompleteEventString = "{\"Id\":\"bce217b0-dc67-40f1-a82f-ffd3cc119e10\",\"Name\":\"\",\"StartDate\":\"2019-05-11T07:00:00\",\"EndDate\":\"2019-05-11T07:00:00\",\"Status\":2,\"Address1\":\"7900 Division St\",\"Address2\":null,\"City\":\"\",\"State\":\"IL\",\"Zip\":\"\",\"LocationDescription\":\"Entrance to the main event\",\"Year\":2019}";
        private static readonly string updateEventString = "{\"Id\":\"bce217b0-dc67-40f1-a82f-ffd3cc119e10\",\"Name\":\"2019\",\"StartDate\":\"2019-05-11T07:00:00\",\"EndDate\":\"2019-05-11T07:00:00\",\"Status\":2,\"Address1\":\"7900 Division St\",\"Address2\":null,\"City\":\"River Forest\",\"State\":\"IL\",\"Zip\":\"60305\",\"LocationDescription\":\"Entrance to the main event\",\"Year\":2019}";
        private static readonly EventDto? UpdatEventSTring = JsonConvert.DeserializeObject<EventDto>(updateEventString);
        #endregion
    }
}


