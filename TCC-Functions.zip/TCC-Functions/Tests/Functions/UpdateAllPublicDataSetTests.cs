using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Moq;
using TCC.Functions.Functions;
using TCC.Functions.Interfaces;

namespace TCC.Functions.Tests.Functions;

public class UpdateAllPublicDataSetTests
{
    private Mock<ILogger<UpdateAllPublicDataSet>> _logger = null!;
    private Mock<IPublicDataService> _publicEventDataService = null!;
    private Mock<IStorageService> _storageService = null!;
    private UpdateAllPublicDataSet _sut = null!;
    [SetUp]
    public void Setup()
    {
        _logger = new Mock<ILogger<UpdateAllPublicDataSet>>();
        _publicEventDataService = new Mock<IPublicDataService>();
        _storageService = new Mock<IStorageService>();
        _sut = new UpdateAllPublicDataSet(_publicEventDataService.Object, _logger.Object);
    }
    [Test]
    public async Task Given_RunSucceeds_WhenCalled_VerifyAllMethodsExecutions()
    {
        // Arrange
        var timerInfo = new TimerInfo
        {
            ScheduleStatus = new ScheduleStatus()
        };
        // Act
        await _sut.Run(timerInfo);
        // Assert
        _publicEventDataService.Verify(service => service.GetBlobItems(), Times.Once);
        _publicEventDataService.Verify(service => service.CreateConferenceInfo(), Times.Once);
        _publicEventDataService.Verify(service => service.CreateEvents(), Times.Once);
        _publicEventDataService.Verify(service => service.CreateSpeakersList(), Times.Once);
    }
    [Test]
    public void Given_RunFailsOnGetBlobItems_WhenCalled_LogAndThrowException()
    {
        // Arrange
        var timerInfo = new TimerInfo
        {
            ScheduleStatus = new ScheduleStatus()
        };
        _publicEventDataService.Setup(service => service.GetBlobItems()).Throws(new Exception());
        // Act
        Assert.ThrowsAsync<Exception>(async () => await _sut.Run(timerInfo));
        // Assert
        _publicEventDataService.Verify(service => service.GetBlobItems(), Times.Once);
        _publicEventDataService.Verify(service => service.CreateConferenceInfo(), Times.Never);
        _publicEventDataService.Verify(service => service.CreateEvents(), Times.Never);
        _publicEventDataService.Verify(service => service.CreateSpeakersList(), Times.Never);
        _logger.Verify(l=> l.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.IsAny<It.IsAnyType>(),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);
    }
    [Test]
    public void Given_RunFailsOnCreateConferenceInfo_WhenCalled_LogAndThrowException()
    {
        // Arrange
        var timerInfo = new TimerInfo
        {
            ScheduleStatus = new ScheduleStatus()
        };
        _publicEventDataService.Setup(service => service.CreateConferenceInfo()).Throws(new Exception());
        // Act
        Assert.ThrowsAsync<Exception>(async () => await _sut.Run(timerInfo));
        // Assert
        _publicEventDataService.Verify(service => service.GetBlobItems(), Times.Once);
        _publicEventDataService.Verify(service => service.CreateConferenceInfo(), Times.Once);
        _publicEventDataService.Verify(service => service.CreateEvents(), Times.Never);
        _publicEventDataService.Verify(service => service.CreateSpeakersList(), Times.Never);
        _logger.Verify(l=> l.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.IsAny<It.IsAnyType>(),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);
    }
    [Test]
    public void Given_RunFailsOnCreateEvents_WhenCalled_LogAndThrowException()
    {
        // Arrange
        var timerInfo = new TimerInfo
        {
            ScheduleStatus = new ScheduleStatus()
        };
        _publicEventDataService.Setup(service => service.CreateEvents()).Throws(new Exception());
        // Act
        Assert.ThrowsAsync<Exception>(async () => await _sut.Run(timerInfo));
        // Assert
        _publicEventDataService.Verify(service => service.GetBlobItems(), Times.Once);
        _publicEventDataService.Verify(service => service.CreateConferenceInfo(), Times.Once);
        _publicEventDataService.Verify(service => service.CreateEvents(), Times.Once);
        _publicEventDataService.Verify(service => service.CreateSpeakersList(), Times.Never);
        _logger.Verify(l=> l.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.IsAny<It.IsAnyType>(),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);
    }
    [Test]
    public void Given_RunFailsOnCreateSpeakersList_WhenCalled_LogAndThrowException()
    {
        // Arrange
        var timerInfo = new TimerInfo
        {
            ScheduleStatus = new ScheduleStatus()
        };
        _publicEventDataService.Setup(service => service.CreateSpeakersList()).Throws(new Exception());
        // Act
        Assert.ThrowsAsync<Exception>(async () => await _sut.Run(timerInfo));
        // Assert
        _publicEventDataService.Verify(service => service.GetBlobItems(), Times.Once);
        _publicEventDataService.Verify(service => service.CreateConferenceInfo(), Times.Once);
        _publicEventDataService.Verify(service => service.CreateEvents(), Times.Once);
        _publicEventDataService.Verify(service => service.CreateSpeakersList(), Times.Once);
        _logger.Verify(l=> l.Log(
                LogLevel.Error,
                It.IsAny<EventId>(),
                It.IsAny<It.IsAnyType>(),
                It.IsAny<Exception>(),
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);
    }
}